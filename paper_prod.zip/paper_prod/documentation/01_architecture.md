# Архитектура и связи модулей

Документ описывает логику работы системы, поток данных между модулями и контракты входов/выходов. Для подробного описания методов с примерами кода см. [02_modules.md](02_modules.md).

## Общий поток данных

```
                ┌────────────────┐
                │  market_data   │  ← биржевые WebSocket-фиды (Binance, OKX)
                └────────┬───────┘
                         │ MarketEvent (поток)
                         ▼
                ┌────────────────┐
                │    storage     │  ← запись на диск; в backtest — воспроизведение
                └────────┬───────┘
                         │ MarketEvent (поток)
                         ▼
                ┌────────────────┐
                │    features    │  ← инкрементальный расчёт признаков
                └────────┬───────┘
                         │ FeatureVector
                         ▼
                ┌────────────────┐      ┌────────────────┐
                │    labeling    │      │     regime     │
                │  (offline fit) │      │    (online)    │
                └────────┬───────┘      └────────┬───────┘
                         │ LabeledDataset        │ RegimeState
                         ▼                       │
                ┌────────────────┐               │
                │     models     │ ──────────────┤
                │ (fit + predict)│               │
                └────────┬───────┘               │
                         │ Prediction[]          │
                         ▼                       ▼
                ┌──────────────────────────────────┐
                │         meta_allocator           │  ← бандит выбирает модель
                └──────────────┬───────────────────┘
                               │ AggregatedSignal
                               ▼
                ┌──────────────────────────────────┐
                │           portfolio              │  ← HRP/Markowitz/RP
                └──────────────┬───────────────────┘
                               │ TargetWeights
                               ▼
                ┌──────────────────────────────────┐
                │             risk                 │  ← inline gate, kill switch
                └──────────────┬───────────────────┘
                               │ TargetWeights (одобренные)
                               ▼
                ┌──────────────────────────────────┐
                │          execution               │  ← TWAP/AC/Market + OMS
                └──────────────┬───────────────────┘
                               │ ChildOrder → биржа
                               │ Fill ← биржа
                               ▼
                ┌──────────────────────────────────┐
                │     обновление PortfolioState    │
                └──────────────────────────────────┘
```

В режиме `backtest` цикл оркеструется через `backtest.StrategyBacktest.run()`. В режимах `paper` и `live` — через `live.TradingApp`.

## Принципы межмодульного взаимодействия

1. **Замороженные схемы.** Каждый модуль публикует pydantic-модели с `frozen=True` в файле `io_schemas.py`. Это контракт. Модификация поля после создания объекта поднимает исключение.

2. **Протоколы вместо наследования.** Интерфейсы в `interface.py` объявлены через `typing.Protocol`, что позволяет реализациям не наследоваться от базового класса. Любой объект с подходящим набором методов удовлетворяет протоколу.

3. **Изоляция реализаций.** Все реализации лежат в подпакете `_internal/`. Импорт из `_internal` извне модуля запрещён конвенцией; публичный API экспортируется только через `__init__.py`.

4. **Единый источник событий.** `ExchangeConnector` (live) и `ReplayEngine` (backtest) реализуют один протокол и эмитируют один тип — `MarketEvent`. Нижестоящий код одинаков в обоих режимах.

5. **Паритет признаков.** `FeaturePipeline` поддерживает два метода — `update()` для потоковой обработки и `batch_compute()` для пакетной. Тест проверяет их побитовое равенство.

---

## 1. market_data

**Назначение:** подключение к публичным потокам бирж, нормализация событий.

| | Тип | Содержимое |
|---|---|---|
| **Вход** | подписка | список символов (`["BTCUSDT"]`) и каналов (`["bbo", "depth", "trade"]`) |
| **Выход** | `AsyncIterator[MarketEvent]` | поток размеченных событий с биржевой и локальной временной меткой |

**MarketEvent** — discriminated union:
- `BookSnapshot` — полный стакан до заданной глубины
- `BookDelta` — инкрементальное обновление одного уровня (`qty=0` → удалить)
- `Trade` — сделка с ценой, объёмом и инициирующей стороной
- `BBO` — лучшая цена покупки/продажи

Реализации: `BinanceConnector`, `OKXConnector`. Оба следуют протоколу `ExchangeConnector`: `connect() → subscribe() → stream() → close()`.

Вспомогательный объект `OrderBook` (протокол `OrderBookProtocol`) поддерживает локальную копию стакана: `apply(event)` обновляет состояние, `snapshot(depth)` возвращает текущий срез.

**Связи с соседями:**
- ↑ внешние WebSocket
- ↓ `storage` (для записи) и `features` (для расчёта признаков)

---

## 2. storage

**Назначение:** запись потока на диск; воспроизведение для обратного тестирования.

| | Тип | Содержимое |
|---|---|---|
| **Вход (запись)** | `MarketEvent` | поток событий из `market_data` |
| **Выход (запись)** | parquet-файлы | разбиты по `{date}/{symbol}/{type}.parquet` |
| **Вход (чтение)** | путь + диапазон | каталог, список символов, временной интервал |
| **Выход (чтение)** | `AsyncIterator[MarketEvent]` | побитово идентичный исходному поток |

Реализации: `TickWriter` (запись), `ParquetLoader` (загрузка батчем), `ReplayEngine` (потоковое воспроизведение, имитирует `ExchangeConnector`).

**Инвариант:** поток, прошедший через `TickWriter` → диск → `ReplayEngine`, побитово равен исходному. Подтверждается интеграционным тестом.

**Связи:**
- ↑ `market_data` (для записи)
- ↓ `features` (для воспроизведения в backtest)

---

## 3. features

**Назначение:** расчёт онлайн-признаков из потока событий.

| | Тип | Содержимое |
|---|---|---|
| **Вход** | `MarketEvent`, `OrderBook \| None` | очередное событие + текущий стакан (для микроструктурных признаков) |
| **Выход** | `FeatureVector` | вектор значений с временной меткой и именами признаков |

**FeatureVector:**
```python
ts_ns: int
symbol: str
values: dict[str, float]    # имя → значение
```

Реализации признаков (объекты с методами `update(event, book)` и `value() -> float`):
- **Ценовые:** `LogReturn`, `RealizedVol`
- **Импульс/осцилляторы:** `RSI`, `MACD`, `BollingerWidth`
- **Стакан:** `MicroPrice`, `Imbalance`
- **Поток сделок:** `OFI` (order flow imbalance)

Главный объект `FeaturePipeline` агрегирует набор фич и предоставляет два режима:
- `update(event, book)` — потоковая обработка по одному событию
- `batch_compute(events)` — пакетная обработка массива; результат гарантированно равен потоковому

**Связи:**
- ↑ `market_data` или `storage` (источник событий)
- ↓ `models` (фичи как вход модели), `meta_allocator` (фичи как контекст)

---

## 4. labeling

**Назначение:** разметка обучающих выборок и инструменты честной кросс-валидации.

| | Тип | Содержимое |
|---|---|---|
| **Вход** | временной ряд цен или признаков | `np.ndarray` цен + `TripleBarrierConfig` |
| **Выход** | `LabeledDataset` | `X`, `y ∈ {-1, 0, +1}`, веса, времена событий `t0` и закрытий `t1` |

Ключевые объекты:
- `TripleBarrierConfig` — параметры барьеров (верх/низ/время)
- `triple_barrier_labels(prices, config)` — функция разметки
- `sample_uniqueness_weights(t0, t1)` — веса для устранения дублирования
- `PurgedKFold` — k-fold с purging по перекрытию меток
- `CombinatorialPurgedCV` — CPCV (López de Prado)
- Метрики: `sharpe_ratio()`, `probabilistic_sharpe()`, `deflated_sharpe()`

**Связи:**
- ↑ `market_data`/`features` (источник цен и признаков)
- ↓ `models` (`LabeledDataset` подаётся в `fit()`)
- ↓ `backtest` (метрики используются для оценки результата)

---

## 5. models

**Назначение:** обучение и применение предиктивных моделей.

| | Тип | Содержимое |
|---|---|---|
| **Вход (fit)** | `LabeledDataset` | `X`, `y`, `sample_weights` |
| **Выход (fit)** | `FitReport` | `train_loss`, `val_loss`, `n_train`, `wall_sec` |
| **Вход (predict)** | `FeatureVector` или `np.ndarray` | вектор признаков последнего наблюдения |
| **Выход (predict)** | `Prediction` | `mu`, `sigma`, опц. `direction_proba`, идентификатор модели |

Реализации (протокол `PredictiveModel`):
- `RidgeModel` — гребневая регрессия (sklearn)
- `LightGBMModel` — градиентный бустинг
- `MLPModel` — многослойный перцептрон (PyTorch)
- `TCNModel` — временная свёрточная сеть (PyTorch)

Спецификация модели — `ModelSpec` (id, type, hyperparams) — позволяет конструировать модели из конфигурации без жёстко закодированных импортов.

**Связи:**
- ↑ `features` (вход для предсказания)
- ↑ `labeling` (источник обучающей выборки)
- ↓ `meta_allocator` (`Prediction` от каждой модели)

---

## 6. regime

**Назначение:** онлайн-детектирование смены рыночного режима.

| | Тип | Содержимое |
|---|---|---|
| **Вход** | `float` или `np.ndarray`, `ts_ns`, `symbol` | очередная доходность |
| **Выход** | `RegimeState` | `regime_id`, `probabilities`, `steps_in_regime`, `change_point_proba` |

Реализации (протокол `RegimeDetector`):
- `HMMDetector` — гауссовский HMM с онлайн-обновлением параметров
- `BOCPDDetector` — Bayesian Online Change-Point Detection с NIG-сопряжённой моделью
- `VolClusterDetector` — эвристика на скользящих квантилях волатильности

Метод `reset()` сбрасывает внутреннее состояние.

**Связи:**
- ↑ `features` (доходности как входы)
- ↓ `meta_allocator` (`regime_id` входит в контекст бандита)
- ↓ `backtest` (история режимов в отчёте)

---

## 7. meta_allocator

**Назначение:** адаптивный выбор активной модели из пула.

| | Тип | Содержимое |
|---|---|---|
| **Вход (select)** | `AllocatorContext` | список арм-id, прогнозы каждой армы, доп. фичи |
| **Выход (select)** | `AggregatedSignal` | выбранная арма + агрегированный сигнал |
| **Вход (update)** | `arm_id`, `reward: float` | результат периода после исполнения |

**AllocatorContext:**
```python
ts_ns: int
arms: list[str]
predictions: dict[str, Prediction]
features: dict[str, float] = {}    # для LinUCB: режим, vol, импульс
```

Реализации (общий программный интерфейс):
- `EpsilonGreedyAllocator(epsilon=0.1)`
- `UCB1Allocator(c=2.0)`
- `ThompsonSamplingAllocator(alpha0=1.0, beta0=1.0)` — по умолчанию
- `LinUCBAllocator(alpha=1.0, d=...)` — контекстный

**Связи:**
- ↑ `models` (прогнозы каждой армы)
- ↑ `regime` (`regime_id` как контекст)
- ↓ `portfolio` (`AggregatedSignal.mu` идёт как ожидаемая доходность)
- ↑ замыкание: `update(arm_id, reward)` после расчёта P&L

---

## 8. portfolio

**Назначение:** расчёт целевых весов из ожидаемых доходностей и ковариации.

| | Тип | Содержимое |
|---|---|---|
| **Вход** | `symbols`, `mu`, `cov`, `PortfolioConstraints` | список инструментов, ожидаемые доходности, ковариация, ограничения |
| **Выход** | `TargetWeights` | `weights: dict[str, float]`, ожидаемые показатели, статус решателя |

**PortfolioConstraints:**
- `max_weight_per_asset`, `min_weight_per_asset`
- `leverage_cap` (сумма абсолютных весов)
- `turnover_cap`, `transaction_cost_bps`

Реализации:
- `MarkowitzOptimizer(risk_aversion, shrinkage)` — mean-variance + Ledoit-Wolf shrinkage
- `RiskParityOptimizer(max_iter, tol)` — ERC, итеративный алгоритм
- `HRPOptimizer()` — иерархический паритет (по умолчанию)
- `LedoitWolfCovariance()` — отдельный оценщик ковариации

Все оптимизаторы возвращают веса, спроецированные на симплекс под ограничения.

**Связи:**
- ↑ `meta_allocator` (`mu` из агрегированного сигнала)
- ↑ исторические доходности → `cov`
- ↓ `risk` (валидация целевых весов)

---

## 9. risk

**Назначение:** inline-контроль перед отправкой приказов; портфельный мониторинг; offline-аналитика через `crypto_risk`.

| | Тип | Содержимое |
|---|---|---|
| **Вход** | `TargetWeights`, `current_drawdown_pct` | целевые веса + текущая просадка |
| **Выход** | `ValidationResult` | `is_valid: bool`, `violations: list[RiskViolation]`, `adjusted_weights` |

**RiskLimits:**
- `max_leverage`, `max_concentration_pct`, `max_drawdown_pct`
- `max_var_95`, `kill_switch_dd_pct`

Объекты:
- `RiskGate` — главный валидатор с методом `validate(weights, ...)`
- `PortfolioMonitor` — ведёт `PortfolioState`, считает P&L, просадку
- `KillSwitch` — состояние блокировки новых приказов
- Функции VaR: `historical_var()`, `historical_cvar()`, `parametric_var()`, `monte_carlo_var()`, `kupiec_pof_test()`
- `CryptoRiskAdapter` — мост к offline-пакету `crypto_risk` (9 методов VaR/ES, GARCH, EVT, копулы)

**Связи:**
- ↑ `portfolio` (валидация целевых весов)
- ↓ `execution` (только одобренные веса доходят до исполнения)
- ↔ `crypto_risk` (через адаптер; параллельно с runtime-слоем)

---

## 10. execution

**Назначение:** превращение целевых весов в детские приказы; имитация или реальное исполнение.

| | Тип | Содержимое |
|---|---|---|
| **Вход** | `TargetWeights`, текущий портфель, состояние стакана | целевые веса + позиции + стакан |
| **Выход** | `ChildOrder[]` | список приказов с `client_order_id`, типом, объёмом |
| **Обратная связь** | `OrderEvent` → `Fill` | подтверждения исполнения от биржи |

**Исполнительные агенты:**
- `MarketOrderAgent` — мгновенно весь объём по рынку
- `TWAPAgent(slices, interval_ns)` — равномерное расписание
- `AlmgrenChrissAgent(risk_aversion, eta)` — оптимальная траектория
- `RandomAgent` — для тестов

**OMS** (Order Management System) — конечный автомат состояний детского приказа: `NEW → PENDING → ACK → PARTIAL → FILLED` (или `CANCELED`/`REJECTED`). Валидирует переходы.

**Симуляторы для backtest:**
- `SimpleFillSimulator` — мгновенное исполнение по mid + spread/2 + slippage
- `QueueAwareFillSimulator` — проход по уровням стакана + square-root impact

**Связи:**
- ↑ `risk` (одобренные `TargetWeights`)
- ↓ биржа (через `ExchangeConnector` в live) или симулятор (в backtest)
- ↑ `Fill` → `PortfolioMonitor` (обновление позиций)

---

## 11. backtest

**Назначение:** оркестратор сквозного обратного тестирования.

| | Тип | Содержимое |
|---|---|---|
| **Вход** | `pd.DataFrame` цен + `StrategyConfig` | таблица цен (symbol × time) + конфигурация |
| **Выход** | `StrategyReport` | equity curve, история весов, прогнозы, режимы, выбор моделей, исполнения, метрики |

**StrategyConfig** объединяет все параметры:
- универсум (`symbols`), параметры обучения, частота пересмотра
- `model_specs` — пул моделей
- тип детектора режима, метастратегии, оптимизатора
- `PortfolioConstraints`, `RiskLimits`
- использование `crypto_risk`-адаптера

**StrategyReport:**
```python
equity_curve: pd.Series
weights_history: pd.DataFrame
predictions_history: pd.DataFrame
regime_history: pd.Series
arm_history: pd.Series
fills: list[Fill]
rejections: list[str]
drawdown_history: pd.Series
metrics: BacktestMetrics
deflated_sharpe: float
crypto_risk_report: dict | None
```

**Фабричная функция** `quick_strategy(prices, **overrides)` — создаёт стратегию с дефолтным конфигом, обучает, опционально подключает `crypto_risk`, запускает.

**Связи:**
- объединяет: `features`, `labeling`, `models`, `regime`, `meta_allocator`, `portfolio`, `risk`, `execution`

---

## 12. live

**Назначение:** единая точка входа для всех режимов работы.

| | Тип | Содержимое |
|---|---|---|
| **Вход** | конфигурация + режим (`backtest`/`paper`/`live`) | YAML-конфиг |
| **Выход** | работающий runtime | потоковая обработка событий, отправка приказов, метрики |

**TradingApp** — runtime, переключаемый между тремя режимами одним параметром:
- `backtest`: источник = `ReplayEngine`, исполнение = `SimpleFillSimulator`
- `paper`: источник = реальный `ExchangeConnector`, исполнение = подложный OMS
- `live`: источник = реальный `ExchangeConnector`, исполнение = реальный OMS

Остальная логика — `FeaturePipeline`, `RegimeDetector`, `Allocator`, `Optimizer`, `RiskGate` — одинакова. Это и есть техническая реализация принципа паритета.

**MetricsExporter** — Prometheus-формат, порт 9090. Метрики: события по типам, задержка, отклонения rist-гейтом, P&L, просадка.

**Связи:**
- объединяет всё, что делает `backtest`, плюс работа с реальным потоком и приказами

---

## Пакет crypto_risk

Лежит в корне проекта рядом с `src/`, не зависит от `src/`.

| Подмодуль | Назначение |
|---|---|
| `engine` | `RiskEngine` — оркестратор полного риск-отчёта |
| `var_es` | 9 методов VaR/ES |
| `volatility` | GARCH-модели (стандартный, асимметричный, экспоненциальный) |
| `evt` | Peaks-over-threshold с обобщённым распределением Парето |
| `dependence` | Гауссовская и t-копула |
| `covariance` | Оценщики ковариационной матрицы (sample, Ledoit-Wolf) |
| `portfolio` | Граница эффективности, max-Sharpe, оценка беты |
| `stress` | Исторические сценарии, реверсивный стресс-тест |
| `liquidity` | Liquidity-adjusted VaR |
| `controls` | Vol-target weights, Kelly weights, drawdown scaling |
| `backtesting` | Тесты Kupiec, Christoffersen, метод светофора |

**Связь с runtime:** через `src.risk.integration.CryptoRiskAdapter` — принимает `pd.DataFrame` доходностей, возвращает структурированный отчёт.

---

## Конфигурации

В каталоге `configs/` лежат YAML-файлы для каждого модуля (12 штук). Использует Hydra/OmegaConf. Структура каждого файла соответствует pydantic-конфигу модуля.

Пример `configs/portfolio.yaml`:
```yaml
optimizer: hrp
constraints:
  max_weight_per_asset: 0.35
  leverage_cap: 1.0
  transaction_cost_bps: 5.0
```

---

## Сквозной пример (backtest)

```python
import pandas as pd
from src.backtest.strategy import quick_strategy

# 1. Загрузить цены (731 день × 5 активов)
prices = pd.read_csv("data_cache/multi_5assets_2023-01-01_2024-12-31.csv",
                    index_col=0, parse_dates=True)

# 2. Запустить полный пайплайн с дефолтным конфигом
report = quick_strategy(prices, use_crypto_risk=False)

# 3. Достать результаты
print(f"Sharpe   : {report.metrics.sharpe:.3f}")
print(f"Return   : {report.metrics.total_return * 100:+.2f}%")
print(f"Max DD   : {report.metrics.max_drawdown * 100:.2f}%")
print(f"Trades   : {report.metrics.n_trades}")
print(f"DSR      : {report.deflated_sharpe:.3f}")

# 4. Визуализировать
report.equity_curve.plot()
report.drawdown_history.plot()
report.weights_history.plot.area()
```

Ожидаемый результат на тестовом наборе (BTC/ETH/BNB/SOL/XRP, 2023–2024, seed=42):
- Sharpe ≈ 1.95
- Total return ≈ +112.6%
- Max DD ≈ 19.92%
- Trades ≈ 404

Все 163 теста проходят за ~24 секунды.
