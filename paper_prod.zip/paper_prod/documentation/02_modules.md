# Подробная документация модулей и методов

Документ покрывает все продуктовые модули, их публичные классы и функции, с примерами использования. Сигнатуры приведены в формате Python-кода.

Структура каждой записи:
- **Класс/функция** — сигнатура
- **Параметры** — описание
- **Возвращает** — тип и смысл
- **Пример** — минимальный воспроизводимый фрагмент

---

## 1. market_data

### `MarketEvent` (pydantic schema, frozen)

Унифицированное событие рынка.

```python
class MarketEvent(BaseModel):
    exchange: Literal["binance", "okx"]
    symbol: str
    ts_exchange_ns: int     # биржевой timestamp
    ts_local_ns: int        # локальный момент приёма
    event_type: Literal["book_snapshot", "book_delta", "trade", "bbo"]
    seq: int | None = None
    payload: BookSnapshot | BookDelta | Trade | BBO
```

### `BinanceConnector`

```python
class BinanceConnector(ExchangeConnector):
    def __init__(self, base_url: str = "wss://stream.binance.com:9443/ws")
    async def connect(self) -> None
    async def subscribe(self, symbols: list[str], channels: list[str]) -> None
    def stream(self) -> AsyncIterator[MarketEvent]
    async def close(self) -> None
```

**Пример:**
```python
import asyncio
from src.market_data import BinanceConnector

async def main():
    conn = BinanceConnector()
    await conn.connect()
    await conn.subscribe(["BTCUSDT", "ETHUSDT"], ["bbo", "trade"])
    async for event in conn.stream():
        print(event.event_type, event.symbol, event.payload)
        if event.ts_local_ns > stop_ns:
            break
    await conn.close()

asyncio.run(main())
```

### `OKXConnector`

Аналогичный интерфейс для OKX (`wss://ws.okx.com:8443/ws/v5/public`).

### `OrderBook` (реализация `OrderBookProtocol`)

```python
class OrderBook:
    def __init__(self, max_depth: int = 50)
    def apply(self, event: MarketEvent) -> None
    def snapshot(self, depth: int = 10) -> BookSnapshot
    def best_bid_ask(self) -> tuple[float, float]
    def is_ready(self) -> bool
```

**Пример:**
```python
from src.market_data import OrderBook

book = OrderBook(max_depth=20)
async for event in conn.stream():
    if event.event_type in ("book_snapshot", "book_delta"):
        book.apply(event)
    if book.is_ready():
        bid, ask = book.best_bid_ask()
        print(f"spread = {(ask - bid) / ((ask + bid) / 2) * 1e4:.1f} bps")
```

---

## 2. storage

### `TickWriter`

```python
class TickWriter:
    def __init__(self, root: Path, partition_by: list[str] = ["date", "symbol"])
    def write(self, event: MarketEvent) -> None
    async def flush(self) -> None
    async def close(self) -> None
```

Записывает события в parquet-файлы с разбиением по дате и символу.

### `ReplayEngine`

```python
class ReplayEngine(ExchangeConnector):
    def __init__(
        self,
        root: Path,
        symbols: list[str],
        start_ns: int,
        end_ns: int,
        speed: float = 0.0,  # 0 = максимально быстро, 1.0 = в реальном времени
    )
    async def connect(self) -> None
    def stream(self) -> AsyncIterator[MarketEvent]
```

**Пример сквозного цикла запись → воспроизведение:**
```python
from src.storage import TickWriter, ReplayEngine

# запись
writer = TickWriter(root=Path("data/ticks"))
async for event in conn.stream():
    writer.write(event)
await writer.close()

# воспроизведение
replay = ReplayEngine(
    root=Path("data/ticks"),
    symbols=["BTCUSDT"],
    start_ns=t0, end_ns=t1,
)
await replay.connect()
async for event in replay.stream():
    # тот же MarketEvent, что и при записи (битово)
    process(event)
```

---

## 3. features

### `FeaturePipeline`

```python
class FeaturePipeline:
    def __init__(self, features: dict[str, Feature])
    def update(self, event: MarketEvent, book: OrderBookProtocol | None = None) -> FeatureVector
    def batch_compute(self, events: list[MarketEvent]) -> pl.DataFrame
    def feature_names(self) -> tuple[str, ...]
```

### Признаки

Все имеют интерфейс `Feature`:
```python
class Feature(Protocol):
    def update(self, event: MarketEvent, book: OrderBookProtocol | None) -> None: ...
    def value(self) -> float: ...
```

#### `LogReturn`
```python
class LogReturn:
    def __init__(self, window: int = 1)
```
Логарифмическая доходность за окно `window` шагов.

#### `RealizedVol`
```python
class RealizedVol:
    def __init__(self, window: int = 20)
```
Скользящее стандартное отклонение log-доходностей.

#### `MicroPrice`
Взвешенная по объёму на лучших уровнях справедливая цена:
$$
P_{\text{micro}} = \frac{P_{\text{bid}} \cdot Q_{\text{ask}} + P_{\text{ask}} \cdot Q_{\text{bid}}}{Q_{\text{bid}} + Q_{\text{ask}}}
$$

#### `Imbalance`
```python
class Imbalance:
    def __init__(self, levels: int = 5)
```
Дисбаланс между bid и ask объёмами на `levels` уровнях:
$$
I = \frac{\sum_i Q_{\text{bid}, i} - \sum_i Q_{\text{ask}, i}}{\sum_i Q_{\text{bid}, i} + \sum_i Q_{\text{ask}, i}}
$$

#### `OFI` (Order Flow Imbalance)
Разность объёмов активных покупок и активных продаж в скользящем окне.

#### `RSI`, `MACD`, `BollingerWidth`
Классические технические индикаторы.

**Пример полного пайплайна:**
```python
from src.features import FeaturePipeline
from src.features._internal.features import LogReturn, RealizedVol, MicroPrice, Imbalance

pipe = FeaturePipeline(features={
    "ret_1":   LogReturn(window=1),
    "ret_20":  LogReturn(window=20),
    "vol_60":  RealizedVol(window=60),
    "micro":   MicroPrice(),
    "imb_5":   Imbalance(levels=5),
})

book = OrderBook()
async for event in stream:
    book.apply(event)
    fv = pipe.update(event, book)
    print(fv.values)  # {"ret_1": ..., "vol_60": ..., ...}
```

---

## 4. labeling

### `TripleBarrierConfig`

```python
@dataclass
class TripleBarrierConfig:
    pt_mult: float = 2.0      # верхний барьер, кратно σ
    sl_mult: float = 2.0      # нижний барьер, кратно σ
    max_horizon: int = 20     # временной барьер в барах
    vol_span: int = 100       # окно для EWMA σ
    min_ret_filter: float = 0.0
```

### `triple_barrier_labels`

```python
def triple_barrier_labels(
    prices: np.ndarray,
    config: TripleBarrierConfig,
    timestamps: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Возвращает (labels, touch_indices).
    labels: ∈ {-1, 0, +1} — какой барьер был достигнут первым.
    touch_indices: индекс касания барьера (для t1 = touch_time).
    """
```

### `PurgedKFold`

```python
class PurgedKFold:
    def __init__(self, n_splits: int = 5, embargo: int = 0)
    def split(
        self, t0: np.ndarray, t1: np.ndarray
    ) -> Iterator[tuple[np.ndarray, np.ndarray]]:
        """Yield (train_indices, test_indices) для каждого фолда."""
```

### Метрики

```python
def sharpe_ratio(returns: np.ndarray, periods_per_year: float = 252) -> float
def probabilistic_sharpe(observed_sr: float, n: int, skew: float, kurt: float, sr_benchmark: float = 0.0) -> float
def deflated_sharpe(observed_sr: float, n: int, skew: float, kurt: float, n_trials: int, var_of_sr: float | None = None) -> float
def sample_stats(returns: np.ndarray) -> tuple[float, float]   # (skew, kurt)
```

**Пример:**
```python
from src.labeling import (
    TripleBarrierConfig, triple_barrier_labels,
    sample_uniqueness_weights, PurgedKFold,
    sharpe_ratio, deflated_sharpe, sample_stats,
)

prices = df["close"].values
cfg = TripleBarrierConfig(pt_mult=2.0, sl_mult=2.0, max_horizon=20)
y, touch_idx = triple_barrier_labels(prices, cfg)

t0 = np.arange(len(prices))
t1 = touch_idx
w = sample_uniqueness_weights(t0, t1)

cv = PurgedKFold(n_splits=5, embargo=10)
for train_idx, test_idx in cv.split(t0, t1):
    fit_model(X[train_idx], y[train_idx], w[train_idx])
    score(X[test_idx], y[test_idx])

# финальная оценка
returns = strategy_returns(prices, signals)
sr = sharpe_ratio(returns, periods_per_year=365)
skew, kurt = sample_stats(returns)
dsr = deflated_sharpe(sr, len(returns), skew, kurt, n_trials=20)
print(f"Sharpe = {sr:.3f}, Deflated Sharpe = {dsr:.3f}")
```

---

## 5. models

### Общий интерфейс `PredictiveModel`

```python
class PredictiveModel(Protocol):
    def fit(self, dataset: LabeledDataset) -> FitReport: ...
    def predict_one(self, x: FeatureVector | np.ndarray) -> Prediction: ...
    def predict_batch(self, X: np.ndarray) -> np.ndarray: ...
    def save(self, path: Path) -> None: ...
    @property
    def model_id(self) -> str: ...
```

### `RidgeModel`

```python
class RidgeModel:
    def __init__(self, model_id: str = "ridge", alpha: float = 1.0)
```

### `LightGBMModel`

```python
class LightGBMModel:
    def __init__(
        self,
        model_id: str = "lgbm",
        num_leaves: int = 31,
        n_estimators: int = 200,
        learning_rate: float = 0.05,
        min_data_in_leaf: int = 50,
    )
```

### `MLPModel`

```python
class MLPModel:
    def __init__(
        self,
        model_id: str = "mlp",
        hidden: tuple[int, ...] = (64, 32),
        dropout: float = 0.2,
        lr: float = 1e-3,
        max_epochs: int = 30,
        seed: int = 42,
    )
```

### `TCNModel`

```python
class TCNModel:
    def __init__(
        self,
        model_id: str = "tcn",
        window: int = 64,
        channels: tuple[int, ...] = (32, 32),
        kernel_size: int = 3,
        dropout: float = 0.1,
        lr: float = 1e-3,
        max_epochs: int = 30,
        seed: int = 42,
    )
```

**Пример:**
```python
from src.models import RidgeModel, LightGBMModel, MLPModel
from src.labeling import LabeledDataset

# подготовить датасет
ds = LabeledDataset(
    X=X_train, y=y_train, sample_weights=w_train,
    t0=t0, t1=t1, feature_names=feat_names,
)

# обучить три модели
ridge = RidgeModel(alpha=1.0)
report_r = ridge.fit(ds)
print(f"Ridge: train_loss={report_r.train_loss:.4f}, n={report_r.n_train}")

lgbm = LightGBMModel(num_leaves=15, n_estimators=100)
lgbm.fit(ds)

mlp = MLPModel(hidden=(64, 32), max_epochs=20)
mlp.fit(ds)

# предсказание (точечное)
pred = ridge.predict_one(x_last)
print(f"μ={pred.mu:.4f}, σ={pred.sigma:.4f}")

# пакетное
mu_array = ridge.predict_batch(X_test)
```

---

## 6. regime

### `HMMDetector`

```python
class HMMDetector:
    def __init__(
        self,
        n_regimes: int = 3,
        means: list[float] | None = None,
        stds: list[float] | None = None,
        trans: np.ndarray | None = None,
        learning_rate: float = 0.01,
    )
    def update(self, x: float | np.ndarray, ts_ns: int, symbol: str = "?") -> RegimeState
    def reset(self) -> None
```

Внутри: predict-шаг `prior = belief @ trans`, correct-шаг `posterior ∝ prior × N(x | μ, σ)`, лёгкое онлайн-обновление параметров доминирующего регима через EWMA.

### `BOCPDDetector`

```python
class BOCPDDetector:
    def __init__(
        self,
        hazard: float = 1 / 100,
        mu0: float = 0.0,
        kappa0: float = 0.1,
        alpha0: float = 2.0,
        beta0: float = 0.0001,
    )
```

NIG-сопряжённая модель с усечённым run-length распределением.

### `VolClusterDetector`

```python
class VolClusterDetector:
    def __init__(
        self,
        n_regimes: int = 3,
        window: int = 100,
        history: int = 1000,
    )
```

Скользящие квантили волатильности.

**Пример:**
```python
from src.regime import HMMDetector, BOCPDDetector, VolClusterDetector
import numpy as np

returns = np.diff(np.log(prices))

# три детектора параллельно
hmm = HMMDetector(n_regimes=3)
bocpd = BOCPDDetector(hazard=0.01)
vol = VolClusterDetector(n_regimes=3, window=50)

for i, r in enumerate(returns):
    s_hmm = hmm.update(r, ts_ns=i, symbol="BTC")
    s_bocpd = bocpd.update(r, ts_ns=i, symbol="BTC")
    s_vol = vol.update(r, ts_ns=i, symbol="BTC")

print(f"HMM    : regime={s_hmm.regime_id}, probs={s_hmm.probabilities}")
print(f"BOCPD  : P(change)={s_bocpd.change_point_proba:.4f}, run_len={s_bocpd.steps_in_regime}")
print(f"VolClus: regime={s_vol.regime_id}, steps_in={s_vol.steps_in_regime}")
```

---

## 7. meta_allocator

### `AllocatorContext`

```python
class AllocatorContext(BaseModel):
    ts_ns: int
    arms: list[str]
    predictions: dict[str, Prediction]
    features: dict[str, float] = {}
```

### `AggregatedSignal`

```python
class AggregatedSignal(BaseModel):
    ts_ns: int
    arm_id: str
    mu: float                # ожидаемая доходность активной модели
    confidence: float = 1.0
    metadata: dict = {}
```

### `EpsilonGreedyAllocator`

```python
class EpsilonGreedyAllocator:
    def __init__(self, epsilon: float = 0.1, seed: int = 0)
    def select(self, ctx: AllocatorContext) -> AggregatedSignal
    def update(self, arm_id: str, reward: float) -> None
```

### `UCB1Allocator`

```python
class UCB1Allocator:
    def __init__(self, c: float = 2.0)
```

Верхняя доверительная граница: $\text{UCB}_i = \bar{r}_i + c \sqrt{\frac{\ln n}{n_i}}$.

### `ThompsonSamplingAllocator`

```python
class ThompsonSamplingAllocator:
    def __init__(self, alpha0: float = 1.0, beta0: float = 1.0, seed: int = 0)
```

Поддерживает бета-распределение успехов/неудач для каждой армы; сэмплирует и выбирает argmax.

### `LinUCBAllocator`

```python
class LinUCBAllocator:
    def __init__(self, alpha: float = 1.0, d: int = 4)
    # d — размерность контекста
```

Контекстная политика: оценка $\hat{\theta}_i = A_i^{-1} b_i$, выбор по $\hat{\theta}_i^T x + \alpha \sqrt{x^T A_i^{-1} x}$.

**Пример:**
```python
from src.meta_allocator import (
    AllocatorContext, ThompsonSamplingAllocator,
)
from src.models import Prediction

allocator = ThompsonSamplingAllocator(seed=42)

# на каждом пересмотре
preds = {
    "ridge": Prediction(model_id="ridge", ts_ns=t, symbol="BTC", mu=0.002),
    "lgbm":  Prediction(model_id="lgbm",  ts_ns=t, symbol="BTC", mu=0.005),
    "mlp":   Prediction(model_id="mlp",   ts_ns=t, symbol="BTC", mu=-0.001),
}
ctx = AllocatorContext(ts_ns=t, arms=list(preds.keys()), predictions=preds)

signal = allocator.select(ctx)
print(f"chosen arm: {signal.arm_id}, mu = {signal.mu:.4f}")

# после расчёта реальной доходности
realized_return = compute_pnl(signal.arm_id, ...)
allocator.update(signal.arm_id, reward=realized_return)
```

---

## 8. portfolio

### `PortfolioConstraints`

```python
class PortfolioConstraints(BaseModel):
    max_weight_per_asset: float = 0.3
    min_weight_per_asset: float = 0.0
    leverage_cap: float = 1.0
    turnover_cap: float | None = None
    transaction_cost_bps: float = 5.0
```

### `MarkowitzOptimizer`

```python
class MarkowitzOptimizer:
    def __init__(self, risk_aversion: float = 5.0, shrinkage: float = 0.1)
    def optimize(
        self,
        symbols: list[str],
        mu: np.ndarray,
        cov: np.ndarray,
        constraints: PortfolioConstraints,
        ts_ns: int = 0,
    ) -> TargetWeights
```

Замкнутая формула: $w^* \propto \Sigma_{\text{shrunk}}^{-1} \mu / \lambda$, далее проекция на симплекс.

### `RiskParityOptimizer`

```python
class RiskParityOptimizer:
    def __init__(self, max_iter: int = 200, tol: float = 1e-7)
```

Итеративно выравнивает вклады в риск $w_i \cdot (\Sigma w)_i$.

### `HRPOptimizer`

```python
class HRPOptimizer:
    def __init__(self)
```

Иерархическая кластеризация → quasi-diagonalization → рекурсивная бисекция.

### `LedoitWolfCovariance`

```python
class LedoitWolfCovariance:
    def estimate(self, returns: np.ndarray) -> np.ndarray
```

Опциональный pre-step перед оптимизацией.

**Пример сравнения трёх оптимизаторов:**
```python
from src.portfolio import (
    PortfolioConstraints, MarkowitzOptimizer,
    RiskParityOptimizer, HRPOptimizer, LedoitWolfCovariance,
)
import numpy as np

symbols = ["BTC", "ETH", "BNB", "SOL", "XRP"]
returns = log_returns_df.values     # (T, 5)
mu = returns.mean(axis=0) * 252
cov_raw = np.cov(returns.T) * 252

# опционально: сжать ковариацию
cov = LedoitWolfCovariance().estimate(returns)

constraints = PortfolioConstraints(
    max_weight_per_asset=0.4, leverage_cap=1.0,
)

for opt in [MarkowitzOptimizer(risk_aversion=5), RiskParityOptimizer(), HRPOptimizer()]:
    tw = opt.optimize(symbols, mu, cov, constraints, ts_ns=0)
    print(f"{tw.optimizer_id}: {tw.weights}")
```

---

## 9. risk

### `RiskLimits`

```python
@dataclass
class RiskLimits:
    max_leverage: float = 1.0
    max_concentration_pct: float = 0.4
    max_drawdown_pct: float = 0.3
    max_var_95: float = 0.1
    kill_switch_dd_pct: float | None = None
```

### `RiskGate`

```python
class RiskGate:
    def __init__(self, limits: RiskLimits)
    def validate(
        self,
        target: TargetWeights,
        current_drawdown_pct: float = 0.0,
    ) -> ValidationResult
```

**ValidationResult:**
```python
class ValidationResult(BaseModel):
    is_valid: bool
    violations: list[RiskViolation] = []
    adjusted_weights: dict[str, float] | None = None
```

### `PortfolioMonitor`

```python
class PortfolioMonitor:
    def __init__(self, initial_equity: float = 100_000.0)
    def update_from_fills(self, fills: list[Fill], prices: dict[str, float]) -> None
    def update_marks(self, prices: dict[str, float]) -> None
    def state(self, ts_ns: int) -> PortfolioState
    @property
    def drawdown_current(self) -> float
```

### `KillSwitch`

```python
class KillSwitch:
    def __init__(self)
    def trip(self, reason: str) -> None
    def reset(self) -> None
    @property
    def is_active(self) -> bool
```

### Функции VaR/ES

```python
def historical_var(returns: np.ndarray, confidence: float = 0.95) -> float
def historical_cvar(returns: np.ndarray, confidence: float = 0.95) -> float
def parametric_var(returns: np.ndarray, confidence: float = 0.95) -> float
def monte_carlo_var(returns: np.ndarray, confidence: float = 0.95, n_sim: int = 10_000, seed: int = 0) -> float
def kupiec_pof_test(violations: int, n: int, confidence: float = 0.95) -> tuple[float, float]
```

### `CryptoRiskAdapter`

```python
class CryptoRiskAdapter:
    def __init__(self, config: CryptoRiskAdapterConfig)
    def attach(self, returns: pd.DataFrame) -> None
    def report(self, weights: dict[str, float]) -> dict
```

**Пример:**
```python
from src.risk import (
    RiskGate, RiskLimits, PortfolioMonitor, KillSwitch,
    historical_var, historical_cvar, parametric_var, monte_carlo_var,
)
from src.portfolio.io_schemas import TargetWeights

# inline gate
gate = RiskGate(RiskLimits(
    max_leverage=1.0,
    max_concentration_pct=0.4,
    max_drawdown_pct=0.3,
))

target = TargetWeights(ts_ns=t, weights={"BTC": 0.5, "ETH": 0.3, "SOL": 0.2})
result = gate.validate(target, current_drawdown_pct=0.05)

if not result.is_valid:
    for v in result.violations:
        print(f"VIOLATION: {v.code} — {v.message}")

# монитор
monitor = PortfolioMonitor(initial_equity=100_000)
monitor.update_from_fills(fills, prices={"BTC": 60_000, "ETH": 3_500})
state = monitor.state(ts_ns=t)
print(f"equity={state.equity}, dd={state.drawdown_current:.3%}")

# VaR
returns = strategy_returns(...)
var_95 = historical_var(returns, confidence=0.95)
es_95  = historical_cvar(returns, confidence=0.95)
print(f"VaR(95%)={var_95:.3%}, ES(95%)={es_95:.3%}")

# проверка покрытия
violations = (returns < -var_95).sum()
lr_stat, p_value = kupiec_pof_test(violations, n=len(returns))
print(f"Kupiec p-value = {p_value:.3f}")
```

---

## 10. execution

### `ChildOrder`

```python
class ChildOrder(BaseModel):
    client_order_id: str
    exchange: str
    symbol: str
    side: Literal["buy", "sell"]
    order_type: Literal["market", "limit", "do_nothing"]
    quantity: float
    price: float | None = None
    ttl_ns: int | None = None
```

### Исполнительные агенты

```python
class MarketOrderAgent:
    def schedule(self, parent: dict, ts_ns: int) -> list[ChildOrder]

class TWAPAgent:
    def __init__(self, slices: int = 10, interval_ns: int = 10**9)

class AlmgrenChrissAgent:
    def __init__(self, risk_aversion: float = 1.0, eta: float = 1e-6, sigma: float = 0.01)

class RandomAgent:
    def __init__(self, seed: int = 0)
```

### `OMS` (Order Management System)

```python
class OMS:
    def __init__(self)
    def submit(self, order: ChildOrder) -> None
    def apply(self, event: OrderEvent) -> None
    def state(self, client_order_id: str) -> OrderState
    def open_orders(self) -> list[OrderState]
```

Переходы состояний валидируются. Любой недопустимый переход (`FILLED → SUBMITTED`, `NEW → FILLED` напрямую) поднимает исключение.

### Симуляторы

```python
class SimpleFillSimulator:
    def __init__(self, spread_bps: float = 5.0, slippage_bps: float = 1.0)
    def simulate(self, order: ChildOrder, book: BookSnapshot, ts_ns: int) -> Fill | None

class QueueAwareFillSimulator:
    def __init__(self, impact_c: float = 0.3)
    def simulate(self, order: ChildOrder, book: BookSnapshot, ts_ns: int) -> Fill | None
```

**Пример:**
```python
from src.execution import (
    ChildOrder, TWAPAgent, OMS, OrderEvent,
)
from src.execution._internal.fill_sim import QueueAwareFillSimulator

agent = TWAPAgent(slices=5, interval_ns=int(60e9))
parent = {"symbol": "BTCUSDT", "side": "buy", "quantity": 10.0}
children = agent.schedule(parent, ts_ns=t_now)

oms = OMS()
sim = QueueAwareFillSimulator()
for order in children:
    oms.submit(order)
    fill = sim.simulate(order, book=current_book, ts_ns=t_now)
    if fill:
        oms.apply(OrderEvent(
            ts_ns=fill.ts_ns,
            client_order_id=order.client_order_id,
            event="fill",
            fill_quantity=fill.quantity,
            fill_price=fill.price,
        ))

for state in oms.open_orders():
    print(state.client_order_id, state.status, state.filled_quantity)
```

---

## 11. backtest

### `StrategyConfig`

```python
@dataclass
class StrategyConfig:
    symbols: tuple[str, ...]
    lookback_days: int = 60
    train_fraction: float = 0.4
    rebalance_every_days: int = 5
    model_specs: tuple[ModelSpec, ...] = (
        ModelSpec(id="ridge", type="Ridge"),
        ModelSpec(id="lgbm",  type="LightGBM"),
        ModelSpec(id="mlp",   type="MLP"),
    )
    target_horizon_days: int = 5
    regime_detector: Literal["vol_cluster", "hmm", "bocpd"] = "vol_cluster"
    allocator: Literal["eps_greedy", "ucb1", "thompson", "linucb"] = "thompson"
    optimizer: Literal["hrp", "risk_parity", "markowitz"] = "hrp"
    constraints: PortfolioConstraints = ...
    risk_limits: RiskLimits = ...
    use_crypto_risk_adapter: bool = True
    initial_capital: float = 100_000.0
    spread_bps: float = 5.0
```

### `StrategyBacktest`

```python
class StrategyBacktest:
    def __init__(self, config: StrategyConfig)
    def fit(self, prices: pd.DataFrame) -> None
    def attach_crypto_risk(self, returns: pd.DataFrame) -> None
    def run(self, prices: pd.DataFrame) -> StrategyReport
```

### `quick_strategy`

```python
def quick_strategy(
    prices: pd.DataFrame,
    *,
    symbols: tuple[str, ...] | None = None,
    use_crypto_risk: bool = True,
    **overrides: Any,
) -> StrategyReport
```

Полный пайплайн в одной строке: создаёт конфиг, обучает, опционально подключает `crypto_risk`, запускает.

### `StrategyReport`

```python
@dataclass
class StrategyReport:
    equity_curve: pd.Series
    weights_history: pd.DataFrame
    predictions_history: pd.DataFrame
    regime_history: pd.Series
    arm_history: pd.Series
    fills: list[Fill]
    rejections: list[str]
    drawdown_history: pd.Series
    metrics: BacktestMetrics
    deflated_sharpe: float
    crypto_risk_report: dict | None = None
```

### `BacktestMetrics`

```python
class BacktestMetrics(BaseModel):
    total_return: float
    annualized_return: float
    annualized_vol: float
    sharpe: float
    sortino: float
    calmar: float
    max_drawdown: float
    deflated_sharpe: float
    turnover_annual: float
    hit_rate: float
    n_trades: int
```

**Пример полного запуска:**
```python
import pandas as pd
from src.backtest.strategy import quick_strategy, StrategyBacktest, StrategyConfig

prices = pd.read_csv("data_cache/multi_5assets_2023-01-01_2024-12-31.csv",
                    index_col=0, parse_dates=True)

# минимальный запуск
report = quick_strategy(prices, use_crypto_risk=False)
print(f"Sharpe   = {report.metrics.sharpe:.3f}")
print(f"Return   = {report.metrics.total_return * 100:+.2f}%")
print(f"Max DD   = {report.metrics.max_drawdown * 100:.2f}%")
print(f"Trades   = {report.metrics.n_trades}")

# с кастомной конфигурацией
cfg = StrategyConfig(
    symbols=("BTC", "ETH", "SOL"),
    rebalance_every_days=3,
    optimizer="hrp",
    allocator="linucb",
    regime_detector="hmm",
)
bt = StrategyBacktest(cfg)
bt.fit(prices)
report = bt.run(prices)
```

---

## 12. live

### `TradingApp`

```python
class TradingApp:
    def __init__(self, config_path: Path)
    async def run(self, mode: Literal["backtest", "paper", "live"]) -> None
    def stop(self) -> None
```

Единая точка входа. Конфигурация — YAML, разбирается через OmegaConf.

### `MetricsExporter`

```python
class MetricsExporter:
    def __init__(self, port: int = 9090)
    def start(self) -> None
    # метрики обновляются через приватные методы из TradingApp
```

**Пример запуска (live):**
```python
import asyncio
from pathlib import Path
from src.live import TradingApp

app = TradingApp(config_path=Path("configs/live.yaml"))
asyncio.run(app.run(mode="paper"))
# или через Docker: docker compose --profile paper up paper
```

---

## Пакет crypto_risk

### `RiskEngine`

```python
class RiskEngine:
    def __init__(self, config: RiskConfig | None = None, data_mode: str = "auto")
    def load_data(self, start: str = "2021-01-01", end: str = "2025-01-01", timeframe: str = "1d") -> "RiskEngine"
    def set_returns(self, returns: pd.DataFrame) -> "RiskEngine"
    def garch(self, asset: str, vol: str = "GJR", dist: str = "t", horizon: int = 10)
    def portfolio_returns(self, weights=None) -> pd.Series
    def risk_report(
        self,
        weights=None,
        methods=("historical", "garch", "fhs"),
        use_copula: bool = True,
    ) -> RiskReport
```

### `RiskReport`

```python
@dataclass
class RiskReport:
    asset_risk: pd.DataFrame          # VaR/ES по каждому активу
    portfolio_risk: pd.DataFrame      # VaR/ES портфеля разными методами
    lvar: dict                        # liquidity-adjusted VaR
    diversification_ratio: float
    annualized_vol: float
    weights: dict
    horizons: tuple[int, ...]
```

### Девять методов оценки риска (`var_es`)

```python
def historical_var_es(returns, var_alpha, es_alpha, horizon) -> RiskEstimate
def parametric_var_es(mu, sigma, var_alpha, es_alpha, horizon, dist="t", nu=5) -> RiskEstimate
def garch_var_es(garch_result, var_alpha, es_alpha, horizon, mu) -> RiskEstimate
def fhs_var_es(returns, garch_result, var_alpha, es_alpha, horizon) -> RiskEstimate
def cornish_fisher_var_es(returns, var_alpha, es_alpha, horizon) -> RiskEstimate
# ... evt-based, copula-based и т.д.
```

### EVT

```python
def pot_var_es(
    returns: np.ndarray | pd.Series,
    var_alpha: float = 0.99,
    es_alpha: float = 0.975,
    threshold_q: float = 0.90,
    method: str = "mle",
) -> RiskEstimate
```

### Копулы

```python
class StudentTCopula:
    @classmethod
    def fit(cls, returns: pd.DataFrame) -> "StudentTCopula"
    def sample(self, n: int, seed: int = 0) -> np.ndarray
```

### Оптимизаторы (offline)

```python
class PortfolioOptimizer:
    def __init__(self, mu: np.ndarray, cov: np.ndarray, rf: float = 0.0)
    def min_variance(self) -> FrontierPoint
    def max_sharpe(self, constraint: str = "long_only", short_limit: float = 0.25, min_w: float = 0.02) -> FrontierPoint
    def efficient_frontier(self, n_points: int = 50, constraint: str = "long_only", ...) -> list[FrontierPoint]
```

**Пример полного риск-отчёта:**
```python
import pandas as pd
from crypto_risk.engine import RiskEngine
from crypto_risk.config import RiskConfig

# 1. подать готовые доходности
returns = pd.read_csv("data_cache/multi_5assets_2023-01-01_2024-12-31.csv",
                     index_col=0, parse_dates=True).pct_change().dropna()

engine = RiskEngine(RiskConfig()).set_returns(returns)

# 2. полный отчёт по равновзвешенному портфелю
weights = {c: 0.2 for c in returns.columns}
report = engine.risk_report(weights=weights, methods=("historical", "garch", "fhs"))

print("Asset risk:")
print(report.asset_risk)
print("\nPortfolio risk:")
print(report.portfolio_risk)
print(f"\nDiversification ratio: {report.diversification_ratio:.3f}")
print(f"Annualized vol: {report.annualized_vol:.3%}")

# 3. EVT отдельно
from crypto_risk.evt import pot_var_es
losses = -returns["BTC"].values
evt_est = pot_var_es(losses, var_alpha=0.99, threshold_q=0.9)
print(f"EVT VaR(99%) = {evt_est.var:.3%}, ES = {evt_est.es:.3%}")
print(f"  xi={evt_est.extra['xi']:.3f}, beta={evt_est.extra['beta']:.5f}")

# 4. касательный портфель
from crypto_risk.portfolio import PortfolioOptimizer, mean_cov
mu, cov = mean_cov(returns)
opt = PortfolioOptimizer(mu, cov)
tangent = opt.max_sharpe()
print(f"Max-Sharpe weights: {dict(zip(returns.columns, tangent.weights))}")
print(f"  expected return = {tangent.ret:.3%}, vol = {tangent.vol:.3%}")
```

---

## Точки входа (скрипты)

### `scripts/fetch_historical_data.py`

Загрузка дневной истории через CryptoCompare.

```bash
python scripts/fetch_historical_data.py \
    --universe BTC,ETH,BNB,SOL,XRP \
    --start 2023-01-01 --end 2024-12-31 \
    --output data_cache/multi_5assets_2023-01-01_2024-12-31.csv
```

### `scripts/smoke_live_binance.py`

Smoke-тест подключения к публичному потоку Binance.

```bash
python scripts/smoke_live_binance.py
# выводит: bbo=1378, book_delta=97, trade=597 (за 10 секунд)
```

### `scripts/smoke_live_okx.py`

Аналог для OKX.

---

## Запуск тестов

```bash
# полный suite (163 теста)
pytest -q

# отдельный модуль
pytest src/regime/tests -v

# интеграционные
pytest tests/test_cross_module_integration.py -v
```
