"""глобальная конфигурация модуля риск-менеджмента.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

# воспроизводимость
RANDOM_SEED: int = 42

# пути
PACKAGE_ROOT: Path = Path(__file__).resolve().parent
PROJECT_ROOT: Path = PACKAGE_ROOT.parent
DATA_CACHE: Path = PROJECT_ROOT / "data_cache"
DATA_CACHE.mkdir(exist_ok=True)

# криптовселенная.
# # В отличие от исходного проекта на российских акциях, базовый актив котировки —
# стейблкоин USDT (квази-доллар). BTC играет роль рыночного индекса (аналог
# индекса МосБиржи) для расчёта бета-коэффициентов и однофакторной модели.
QUOTE_ASSET: str = "USDT"
MARKET_PROXY: str = "BTC"          # рыночный индекс крипторынка для CAPM/бет

DEFAULT_UNIVERSE: tuple[str, ...] = (
    "BTC", "ETH", "BNB", "SOL", "XRP",
    "ADA", "DOGE", "AVAX", "LINK", "LTC",
)

def to_symbol(base: str, quote: str = QUOTE_ASSET) -> str:
    """'BTC' -> 'BTC/USDT' (формат ccxt)."""
    return f"{base}/{quote}"

# календарь / аннуализация.
# # Криптовалюты торгуются 24/7 без выходных => 365 торговых дней в году
# (для акций было бы 252). Это принципиально влияет на аннуализацию волатильности
# и масштабирование VaR по правилу sqrt(T).
TRADING_DAYS_YEAR: int = 365
SECONDS_YEAR: int = 365 * 24 * 3600

# меры риска (как в техническом задании по рыночному риску)
VAR_CONFIDENCE: float = 0.99       # Value-at-Risk на уровне 99%
ES_CONFIDENCE: float = 0.975       # Expected Shortfall на уровне 97.5%
RISK_HORIZONS: tuple[int, ...] = (1, 10)   # горизонты оценки риска (в днях)

# параметры моделей волатильности
EWMA_LAMBDA: float = 0.94          # RiskMetrics для дневных данных
ROLLING_WINDOW: int = 252          # окно исторической оценки по умолчанию

# параметры ликвидности / микроструктуры (для HFT-контекста)
# множитель худшего спреда для exogenous LVaR по Bangia et al. (1999).
# для тяжёлых хвостов крипты берётся 3 (вместо 2.33 при нормальности).
LIQUIDITY_SPREAD_MULT: float = 3.0
DEFAULT_MAKER_FEE: float = 0.0002  # 2 б.п. (Binance VIP-уровни)
DEFAULT_TAKER_FEE: float = 0.0005  # 5 б.п.


@dataclass
class RiskConfig:
    """конфигурация, передаваемая в RiskEngine. Все значения имеют дефолты
    из модуля config, но могут быть переопределены пользователем."""

    universe: tuple[str, ...] = DEFAULT_UNIVERSE
    quote: str = QUOTE_ASSET
    market_proxy: str = MARKET_PROXY
    var_confidence: float = VAR_CONFIDENCE
    es_confidence: float = ES_CONFIDENCE
    horizons: tuple[int, ...] = RISK_HORIZONS
    ewma_lambda: float = EWMA_LAMBDA
    rolling_window: int = ROLLING_WINDOW
    trading_days_year: int = TRADING_DAYS_YEAR
    seed: int = RANDOM_SEED
    maker_fee: float = DEFAULT_MAKER_FEE
    taker_fee: float = DEFAULT_TAKER_FEE
    spread_mult: float = LIQUIDITY_SPREAD_MULT
    # капитал портфеля, USDT
    capital: float = 1_000_000.0
    extra: dict = field(default_factory=dict)
