"""crypto_risk — модуль риск-менеджмента высокоскоростной торговой системы для
управления и оптимизации криптовалютного портфеля на основе глубокого обучения
и адаптивных стратегий.
"""
from .config import RiskConfig
from .engine import RiskEngine

__version__ = "1.0.0"
__all__ = ["RiskEngine", "RiskConfig"]
