"""cross-module integration tests.
"""

from __future__ import annotations

import asyncio
import warnings
from collections.abc import AsyncIterator
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

warnings.filterwarnings("ignore")


# 1. Schema consumability across module boundaries


def test_all_top_level_imports() -> None:
    """every module top-level package imports cleanly."""
    import crypto_risk  # noqa: F401
    import src.backtest  # noqa: F401
    import src.execution  # noqa: F401
    import src.features  # noqa: F401
    import src.labeling  # noqa: F401
    import src.live  # noqa: F401
    import src.market_data  # noqa: F401
    import src.meta_allocator  # noqa: F401
    import src.models  # noqa: F401
    import src.portfolio  # noqa: F401
    import src.regime  # noqa: F401
    import src.risk  # noqa: F401
    import src.storage  # noqa: F401


def test_market_event_flows_into_features() -> None:
    """module 01 → Module 03: MarketEvent + OrderBook produce a FeatureVector."""
    from src.features import FeaturePipeline, FeaturesConfig, FeatureSpec
    from src.market_data import SortedBook, random_walk_deltas

    book = SortedBook("BTCUSDT")
    pipe = FeaturePipeline(
        FeaturesConfig(
            features=[
                FeatureSpec(type="MicroPrice"),
                FeatureSpec(type="Imbalance", levels=1),
                FeatureSpec(type="LogReturn", lag=1),
                FeatureSpec(type="RealizedVol", window=20),
            ]
        )
    )
    emitted = 0
    for ev in random_walk_deltas(seed=1, n=300):
        book.apply(ev)
        fv = pipe.update(ev, book)
        if fv is not None:
            emitted += 1
    assert emitted > 0


def test_labeling_to_models_pipeline() -> None:
    """module 04 → Module 05: LabeledDataset trains a model."""
    from src.labeling import LabeledDataset, PurgedKFold
    from src.models import LightGBMModel

    rng = np.random.default_rng(0)
    n = 500
    X = rng.normal(size=(n, 6))
    y = (X.sum(axis=1) + rng.normal(0, 0.5, n)).astype(np.float64)
    ds = LabeledDataset(
        X=X,
        y=y,
        sample_weights=np.ones(n),
        t0=np.arange(n, dtype=np.int64),
        t1=np.arange(n, dtype=np.int64) + 5,
        feature_names=tuple(f"f{i}" for i in range(6)),
    )
    cv = PurgedKFold(n_splits=4)
    splits = list(cv.split(ds))
    assert len(splits) == 4
    model = LightGBMModel(model_id="lgbm", n_estimators=50)
    report = model.fit(ds)
    assert report.train_loss < ds.y.var()


def test_predictions_to_allocator_to_portfolio() -> None:
    """module 05 → 07 → 08: pred → bandit → optimizer chain."""
    from src.meta_allocator import (
        AllocatorContext,
        ThompsonSamplingAllocator,
    )
    from src.models.io_schemas import Prediction
    from src.portfolio import HRPOptimizer, PortfolioConstraints
    from src.regime.io_schemas import RegimeState

    arms = ["m1", "m2", "m3"]
    alloc = ThompsonSamplingAllocator(arms, seed=42)
    preds = [
        Prediction(model_id=a, ts_ns=0, symbol="BTC", mu=mu)
        for a, mu in zip(arms, [0.01, -0.005, 0.02])
    ]
    ctx = AllocatorContext(
        ts_ns=0,
        regime_state=RegimeState(
            ts_ns=0, symbol="BTC", regime_id=0, probabilities=np.array([1.0, 0.0])
        ),
    )
    sw = alloc.allocate(preds, context=ctx)
    assert sum(sw.weights.values()) == pytest.approx(1.0)

    syms = ["BTC", "ETH", "SOL"]
    mu = np.array([0.01, 0.005, 0.008])
    cov = np.diag([0.04, 0.06, 0.09])
    opt = HRPOptimizer()
    tw = opt.optimize(
        syms, mu, cov, PortfolioConstraints(max_weight_per_asset=0.6, leverage_cap=1.0)
    )
    assert abs(sum(tw.weights.values()) - 1.0) < 1e-6


def test_target_weights_through_risk_gate_then_execution() -> None:
    """module 08 → 10 → 09: TargetWeights → RiskGate → OMS."""
    from src.execution import OMS, ChildOrder
    from src.portfolio.io_schemas import TargetWeights
    from src.risk import RiskGate, RiskLimits

    tw = TargetWeights(ts_ns=1, weights={"BTC": 0.3, "ETH": 0.3, "SOL": 0.4})
    gate = RiskGate(RiskLimits(max_leverage=1.0, max_concentration_pct=0.5))
    result = gate.validate(tw)
    assert result.approved

    oms = OMS()
    oms.place(
        ChildOrder(
            client_order_id="x1",
            exchange="sim",
            symbol="BTC",
            side="buy",
            order_type="market",
            quantity=1.0,
        )
    )
    assert oms.get("x1").status == "PENDING"


def test_storage_replay_is_drop_in_for_live_connector() -> None:
    """module 02 ReplayEngine implements the same Protocol as Module 01 connectors."""
    from src.market_data import random_walk_deltas
    from src.market_data.interface import ExchangeConnector
    from src.storage import (
        ParquetTickWriter,
        ReplayConfig,
        ReplayEngine,
        StorageConfig,
    )

    tmp = Path("/tmp/xmod_test")
    if tmp.exists():
        import shutil

        shutil.rmtree(tmp)
    cfg = StorageConfig(root_path=tmp, flush_max_events=10**9)
    writer = ParquetTickWriter(cfg)
    events = list(random_walk_deltas(seed=2, n=100))
    for ev in events:
        writer.write(ev)
    asyncio.run(writer.close())

    engine = ReplayEngine(
        storage=cfg,
        replay=ReplayConfig(speed="max"),
        from_ns=min(e.ts_exchange_ns for e in events),
        to_ns=max(e.ts_exchange_ns for e in events),
        sources=[("binance", "BTCUSDT")],
    )
    assert isinstance(engine, ExchangeConnector)


# 2. Strategy backtest with all 12 modules


def test_strategy_backtest_uses_all_modules() -> None:
    """end-to-end: features → models → regime → allocator → portfolio → risk → execution."""
    from src.backtest import quick_strategy
    from src.models import ModelSpec

    rng = np.random.default_rng(0)
    n = 400
    prices = pd.DataFrame(
        {
            "BTC": 100 * np.exp(np.cumsum(rng.normal(0.0005, 0.02, n))),
            "ETH": 100 * np.exp(np.cumsum(rng.normal(0.0003, 0.025, n))),
            "SOL": 100 * np.exp(np.cumsum(rng.normal(0.0002, 0.03, n))),
        },
        index=pd.date_range("2022-01-01", periods=n, freq="D"),
    )
    rep = quick_strategy(
        prices,
        use_crypto_risk=False,
        rebalance_every_days=10,
        model_specs=(
            ModelSpec(id="ridge", type="Ridge"),
            ModelSpec(id="lgbm", type="LightGBM"),
        ),
    )
    assert rep.metrics.n_trades > 0
    assert len(rep.equity_curve) > 0
    assert len(rep.regime_history) > 0
    assert len(rep.arm_history) > 0


def test_strategy_backtest_with_crypto_risk() -> None:
    """end-to-end strategy with the crypto_risk analytics adapter wired in."""
    from src.backtest import quick_strategy
    from src.models import ModelSpec

    rng = np.random.default_rng(1)
    n = 350
    prices = pd.DataFrame(
        {
            "BTC": 100 * np.exp(np.cumsum(rng.normal(0.0005, 0.02, n))),
            "ETH": 100 * np.exp(np.cumsum(rng.normal(0.0003, 0.025, n))),
            "BNB": 100 * np.exp(np.cumsum(rng.normal(0.0001, 0.022, n))),
        },
        index=pd.date_range("2022-01-01", periods=n, freq="D"),
    )
    rep = quick_strategy(
        prices,
        use_crypto_risk=True,
        rebalance_every_days=10,
        model_specs=(ModelSpec(id="ridge", type="Ridge"),),
    )
    assert len(rep.equity_curve) > 0
    # crypto_risk report may or may not be attached depending on final weights
    if rep.crypto_risk_report is not None:
        assert rep.crypto_risk_report["annualized_vol"] > 0


# 3. TradingApp end-to-end with replay


@pytest.mark.asyncio
async def test_trading_app_with_replay_engine() -> None:
    """TradingApp consumes a ReplayEngine just like a live connector."""
    import shutil

    from src.live import TradingApp, TradingAppConfig
    from src.market_data import random_walk_deltas
    from src.storage import (
        ParquetTickWriter,
        ReplayConfig,
        ReplayEngine,
        StorageConfig,
    )

    tmp = Path("/tmp/xmod_app_test")
    if tmp.exists():
        shutil.rmtree(tmp)
    cfg = StorageConfig(root_path=tmp, flush_max_events=10**9)
    writer = ParquetTickWriter(cfg)
    events = list(random_walk_deltas(seed=3, n=200))
    for ev in events:
        writer.write(ev)
    await writer.close()

    engine = ReplayEngine(
        storage=cfg,
        replay=ReplayConfig(speed="max"),
        from_ns=min(e.ts_exchange_ns for e in events),
        to_ns=max(e.ts_exchange_ns for e in events),
        sources=[("binance", "BTCUSDT")],
    )
    app = TradingApp(TradingAppConfig(mode="backtest"), connector=engine)
    n = await app.run_until_done(max_events=200)
    assert n == 200


# 4. Schema invariants across modules


def test_all_schemas_are_pydantic_v2_models() -> None:
    """every public schema is a Pydantic BaseModel (so JSON round-trip works)."""
    from pydantic import BaseModel

    from src.execution import ChildOrder, Fill, OrderEvent
    from src.features import FeatureVector
    from src.market_data import BBO, BookDelta, BookSnapshot, MarketEvent, Trade
    from src.meta_allocator import AggregatedSignal, StrategyWeights
    from src.models.io_schemas import Prediction
    from src.portfolio.io_schemas import PortfolioConstraints, TargetWeights
    from src.regime.io_schemas import RegimeState
    from src.risk import PortfolioState, ValidationResult

    for cls in [
        MarketEvent,
        BookDelta,
        BookSnapshot,
        BBO,
        Trade,
        FeatureVector,
        Prediction,
        RegimeState,
        AggregatedSignal,
        StrategyWeights,
        TargetWeights,
        PortfolioConstraints,
        ChildOrder,
        OrderEvent,
        Fill,
        PortfolioState,
        ValidationResult,
    ]:
        assert issubclass(cls, BaseModel)


def test_time_is_int64_ns_everywhere() -> None:
    """project-wide invariant: every ts field is int (ns), not datetime."""
    from src.execution import Fill
    from src.market_data import BookDelta, MarketEvent
    from src.models.io_schemas import Prediction

    ev = MarketEvent(
        exchange="binance",
        symbol="BTCUSDT",
        ts_exchange_ns=1_000_000_000_000_000_000,
        ts_local_ns=1_000_000_000_000_000_000,
        event_type="book_delta",
        payload=BookDelta(),
    )
    assert isinstance(ev.ts_exchange_ns, int)
    p = Prediction(model_id="x", ts_ns=42, symbol="BTC", mu=0.0)
    assert isinstance(p.ts_ns, int)
    f = Fill(ts_ns=1, symbol="X", side="buy", quantity=1, price=1)
    assert isinstance(f.ts_ns, int)
