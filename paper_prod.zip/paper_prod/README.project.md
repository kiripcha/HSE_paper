### crypto Trading System (Thesis Project)

высокоскоростная торговая система для управления и оптимизации криптовалютного портфеля на основе глубокого обучения и адаптивных стратегий.

### структура проекта

```
paper/
├── promts/                  # Промты для LLM-агентов по каждому модулю
├── notebooks/               # Исследовательские ноутбуки (NN_<module>.ipynb)
├── src/                     # Production-код модулей
│   ├── market_data/         # 01. WebSocket + Order Book
│   ├── storage/             # 02. Historical storage + replay
│   ├── features/            # 03. Feature engineering
│   ├── labeling/            # 04. Labeling & CV
│   ├── models/              # 05. Predictive models
│   ├── regime/              # 06. Regime detection
│   ├── meta_allocator/      # 07. Adaptive meta-allocator
│   ├── portfolio/           # 08. Portfolio optimization
│   ├── execution/           # 09. DRL execution + OMS/EMS
│   ├── risk/                # 10. Runtime risk + adapter к crypto_risk
│   ├── backtest/            # 11. Event-driven backtester
│   └── live/                # 12. Live trading orchestration
├── crypto_risk/             # 10a. Глубокая аналитика (VaR/ES/EVT/copulas/stress)
├── risk_managment_inner/    # Документация и оригинал crypto_risk (reference)
├── configs/                 # Hydra-конфиги
├── tests/                   # Integration tests
└── data/                    # Локальные данные (gitignored)
```

### два слоя риск-менеджмента

- `src/risk/` — event-loop runtime: `RiskGate`, `PortfolioMonitor`,
  `KillSwitch`. Срабатывает на каждом тике / Fill.
- `crypto_risk/` — offline-/batch-аналитика: 9 методов VaR/ES, EVT (POT/GPD),
  GARCH-family, copulas, стресс-тесты, оптимизатор портфеля.
- `src/risk.CryptoRiskAdapter` — мост. Опционально подключается в
  `TradingApp` и даёт детальный pre-trade check + полный risk-отчёт:

```python
from src.risk import CryptoRiskAdapter
adapter = CryptoRiskAdapter.from_returns(returns_df)
app = TradingApp(cfg, connector=conn, crypto_risk_adapter=adapter)
res = app.validate_target_weights(target)  # gate + crypto_risk
```

### setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
```

### тесты модуля

```bash
pytest src/market_data/tests -v
```

### запуск приложения

```bash
python -m src.live run --config configs/paper.yaml
```

### статус реализации

- [x] 01. market_data — WS-коннекторы Binance/OKX + OrderBook (2 реализации) + ResyncManager
- [x] 02. storage_replay — Parquet partitioning + ReplayEngine с контрактной совместимостью к live
- [x] 03. features — 8 инкрементальных фич + train/serve parity
- [x] 04. labeling_cv — triple-barrier + purged k-fold + CPCV + deflated Sharpe
- [x] 05. predictive_models — Ridge / LightGBM / MLP / TCN + MC-dropout uncertainty
- [x] 06. regime_detection — HMM / BOCPD / VolCluster (strictly online)
- [x] 07. meta_allocator — ε-greedy / UCB1 / Thompson / LinUCB
- [x] 08. portfolio_optimization — Markowitz / Risk Parity / HRP + Ledoit-Wolf
- [x] 09. drl_execution — OMS + TWAP / Almgren-Chriss / market / random agents
- [x] 10. risk_management — RiskGate + PortfolioMonitor + KillSwitch + VaR/CVaR + Kupiec
- [x] 10a. crypto_risk integration — adapter в src/risk/integration.py, VaR/ES/EVT/copulas/stress через `CryptoRiskAdapter`
- [x] 11. backtest — event-driven с queue-aware fill simulator + StrategyBacktest (объединяет модули 03-10)
- [x] 12. live_monitoring — TradingApp (3 mode runtime) + MetricsExporter

тесты: 163 passed (`pytest`) — module unit tests + cross-module integration + strategy backtest.

### полный strategy-backtest

[src/backtest/strategy.py](src/backtest/strategy.py) собирает все модули 03-10
в единый `StrategyBacktest`. Использование:

```python
from src.backtest import quick_strategy
from src.models import ModelSpec

rep = quick_strategy(
    prices_df,                    # DataFrame [date × symbol]
    rebalance_every_days=5,
    model_specs=(
        ModelSpec(id='ridge', type='Ridge'),
        ModelSpec(id='lgbm',  type='LightGBM'),
        ModelSpec(id='mlp',   type='MLP'),
    ),
    regime_detector='vol_cluster',     # vol_cluster | hmm | bocpd
    allocator='thompson',              # eps_greedy | ucb1 | thompson | linucb
    optimizer='hrp',                   # hrp | risk_parity | markowitz
    use_crypto_risk=True,
)
print(rep.metrics, rep.deflated_sharpe)
rep.equity_curve.plot()
```

полная демонстрация со всеми визуализациями —
[notebooks/13_full_strategy_backtest.ipynb](notebooks/13_full_strategy_backtest.ipynb):
live-WS smoke, реальные исторические данные, equity vs benchmark, heatmap
весов, выбор моделей бандитом, режимы рынка, fill analysis, sweep по
конфигурациям, CPCV распределение Sharpe, отчёт `crypto_risk` (VaR/ES/LVaR).

### подключение к биржам

public market data (без аккаунта):

```bash
PYTHONPATH=. .venv/bin/python scripts/smoke_live_binance.py   # ~150 ev/s, Binance public WS
PYTHONPATH=. .venv/bin/python scripts/smoke_live_okx.py       # ~20  ev/s, OKX public WS
```

загрузка реальной истории через мультисурсовый парсер (CryptoCompare → Yahoo →
coinGecko → Binance → synthetic fallback):

```bash
PYTHONPATH=. .venv/bin/python scripts/fetch_historical_data.py \
    --start 2022-01-01 --end 2024-12-31 \
    --universe BTC,ETH,BNB,SOL,XRP,ADA,DOGE,LINK
# результат: data/historical/...parquet
```

для размещения реальных ордеров (live trading, а не чтение публичных данных
для backtest) понадобятся API-ключи — это пока не подключено; для всех задач
диплома (backtest + paper trading через FillSimulator) достаточно публичных
эндпоинтов и аккаунт не нужен.

### документация

- [documentation/PROJECT_OVERVIEW.md](documentation/PROJECT_OVERVIEW.md) — архитектура, поток данных, модуль-за-модулем.
- [documentation/METHODOLOGY.md](documentation/METHODOLOGY.md) — формулы → код для каждого алгоритма.
- [documentation/AGENT_CONTEXT.md](documentation/AGENT_CONTEXT.md) — самодостаточный брифинг для LLM-агента (конвенции, API, рецепты, pitfalls).
- [promts/](promts/) — детальные промты по каждому из 12 модулей.
- [risk_managment_inner/documentation/](risk_managment_inner/documentation/) — собственная документация пакета `crypto_risk`.
