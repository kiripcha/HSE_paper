"""pydantic schemas — the frozen contract between modules.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

Exchange = Literal["binance", "okx"]
Side = Literal["buy", "sell"]
EventType = Literal["book_snapshot", "book_delta", "trade", "bbo"]


class BookLevel(BaseModel):
    model_config = ConfigDict(frozen=True)

    price: float
    quantity: float  # quantity == 0 in a delta means "remove this level"


class BookDelta(BaseModel):
    model_config = ConfigDict(frozen=True)

    bids: tuple[BookLevel, ...] = Field(default=())
    asks: tuple[BookLevel, ...] = Field(default=())
    first_update_id: int | None = None
    last_update_id: int | None = None


class BookSnapshot(BaseModel):
    model_config = ConfigDict(frozen=True)

    bids: tuple[BookLevel, ...] = Field(default=())
    asks: tuple[BookLevel, ...] = Field(default=())
    last_update_id: int | None = None


class Trade(BaseModel):
    model_config = ConfigDict(frozen=True)

    price: float
    quantity: float
    side: Side
    trade_id: int | None = None


class BBO(BaseModel):
    model_config = ConfigDict(frozen=True)

    bid_price: float
    bid_qty: float
    ask_price: float
    ask_qty: float


Payload = BookDelta | BookSnapshot | Trade | BBO


_PAYLOAD_BY_EVENT: dict[str, type[BaseModel]] = {
    "book_snapshot": BookSnapshot,
    "book_delta": BookDelta,
    "trade": Trade,
    "bbo": BBO,
}


class MarketEvent(BaseModel):
    """unified event across all exchanges and channels."""

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    exchange: Exchange
    symbol: str
    ts_exchange_ns: int
    ts_local_ns: int
    event_type: EventType
    seq: int | None = None
    payload: Payload

    @model_validator(mode="before")
    @classmethod
    def _coerce_payload(cls, data: Any) -> Any:
        """pick the right payload class based on event_type."""
        if isinstance(data, dict):
            evt = data.get("event_type")
            payload = data.get("payload")
            if isinstance(payload, dict) and evt in _PAYLOAD_BY_EVENT:
                data = dict(data)
                data["payload"] = _PAYLOAD_BY_EVENT[evt].model_validate(payload)
        return data


def derive_mid(snapshot: BookSnapshot) -> float | None:
    """mid-price from L1 of a snapshot. Returns None if either side is empty."""
    if not snapshot.bids or not snapshot.asks:
        return None
    return (snapshot.bids[0].price + snapshot.asks[0].price) / 2.0


def derive_micro_price(snapshot: BookSnapshot) -> float | None:
    """stoikov micro-price: p_b * q_a/(q_a+q_b) + p_a * q_b/(q_a+q_b)."""
    if not snapshot.bids or not snapshot.asks:
        return None
    bid = snapshot.bids[0]
    ask = snapshot.asks[0]
    total = bid.quantity + ask.quantity
    if total <= 0:
        return None
    return bid.price * ask.quantity / total + ask.price * bid.quantity / total


def derive_imbalance(snapshot: BookSnapshot, levels: int = 1) -> float | None:
    """volume imbalance over top-N levels: (bid_vol - ask_vol) / (bid_vol + ask_vol)."""
    if not snapshot.bids or not snapshot.asks:
        return None
    bid_vol = sum(b.quantity for b in snapshot.bids[:levels])
    ask_vol = sum(a.quantity for a in snapshot.asks[:levels])
    total = bid_vol + ask_vol
    if total <= 0:
        return None
    return (bid_vol - ask_vol) / total
