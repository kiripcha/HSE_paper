"""pydantic config models for market_data."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

OrderBookImpl = Literal["array", "sorted"]


class ReconnectConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    initial_backoff_ms: int = 100
    max_backoff_ms: int = 30_000
    max_attempts: int = -1  # -1 = infinite


class ExchangeSpec(BaseModel):
    model_config = ConfigDict(frozen=True)

    enabled: bool = True
    ws_url: str
    rest_url: str
    api_key: str | None = None
    symbols: list[str] = Field(default_factory=list)
    channels: list[str] = Field(default_factory=lambda: ["depth", "trade", "bbo"])


class OrderBookConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    implementation: OrderBookImpl = "sorted"
    max_depth: int = 100


class MarketDataConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    exchanges: dict[str, ExchangeSpec]
    order_book: OrderBookConfig = OrderBookConfig()
    reconnect: ReconnectConfig = ReconnectConfig()


DEFAULT_BINANCE_SPEC = ExchangeSpec(
    ws_url="wss://stream.binance.com:9443/ws",
    rest_url="https://api.binance.com",
    symbols=["BTCUSDT", "ETHUSDT"],
    channels=["depth", "trade", "bookTicker"],
)

DEFAULT_OKX_SPEC = ExchangeSpec(
    ws_url="wss://ws.okx.com:8443/ws/v5/public",
    rest_url="https://www.okx.com",
    symbols=["BTC-USDT", "ETH-USDT"],
    channels=["books", "trades", "bbo-tbt"],
)
