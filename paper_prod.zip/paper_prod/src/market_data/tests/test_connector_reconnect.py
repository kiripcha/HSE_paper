"""reconnect logic against a mock WebSocket server.
"""

from __future__ import annotations

import asyncio
import contextlib

import orjson
import pytest
import websockets

from src.market_data import BinanceConnector, ReconnectConfig


async def _binance_server_handler(ws: websockets.WebSocketServerProtocol) -> None:
    """send one valid trade per second, then close after 2 messages."""
    sent = 0
    try:
        while sent < 2:
            msg = orjson.dumps(
                {
                    "e": "trade",
                    "E": 1000 + sent,
                    "s": "BTCUSDT",
                    "t": 1000 + sent,
                    "p": "50000",
                    "q": "0.1",
                    "T": 1000 + sent,
                    "m": False,
                }
            ).decode()
            await ws.send(msg)
            await asyncio.sleep(0.05)
            sent += 1
        # disconnect by closing the server-side socket
        await ws.close()
    except websockets.ConnectionClosed:
        return


@pytest.mark.asyncio
async def test_reconnect_after_server_drop() -> None:
    """connector should reconnect and keep streaming after the server drops."""
    server = await websockets.serve(_binance_server_handler, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]
    ws_url = f"ws://127.0.0.1:{port}"

    conn = BinanceConnector(
        ws_url=ws_url,
        symbols=["BTCUSDT"],
        channels=["trade"],
        reconnect=ReconnectConfig(initial_backoff_ms=50, max_backoff_ms=200, max_attempts=3),
    )

    received = []

    async def consume() -> None:
        async for ev in conn.stream():
            received.append(ev)
            if len(received) >= 3:
                break

    await conn.connect()
    try:
        await asyncio.wait_for(consume(), timeout=5.0)
    finally:
        await conn.close()
        server.close()
        await server.wait_closed()

    # the handler closes after 2 events, then the connector reconnects and gets 2 more.
    assert len(received) >= 3
    assert all(ev.event_type == "trade" for ev in received)
    assert received[0].symbol == "BTCUSDT"


@pytest.mark.asyncio
async def test_close_stops_streaming() -> None:
    """calling close() should release the stream() consumer."""

    async def handler(ws: websockets.WebSocketServerProtocol) -> None:
        with contextlib.suppress(websockets.ConnectionClosed):
            while True:
                await ws.send(
                    orjson.dumps(
                        {
                            "e": "trade",
                            "E": 1,
                            "s": "BTCUSDT",
                            "t": 1,
                            "p": "1",
                            "q": "1",
                            "T": 1,
                            "m": False,
                        }
                    ).decode()
                )
                await asyncio.sleep(0.01)

    server = await websockets.serve(handler, "127.0.0.1", 0)
    port = server.sockets[0].getsockname()[1]

    conn = BinanceConnector(
        ws_url=f"ws://127.0.0.1:{port}",
        symbols=["BTCUSDT"],
        channels=["trade"],
        reconnect=ReconnectConfig(max_attempts=0),
    )
    await conn.connect()

    received = 0

    async def consume() -> None:
        nonlocal received
        async for _ev in conn.stream():
            received += 1
            if received >= 1:
                break

    await asyncio.wait_for(consume(), timeout=2.0)
    await conn.close()
    server.close()
    await server.wait_closed()
    assert received >= 1
