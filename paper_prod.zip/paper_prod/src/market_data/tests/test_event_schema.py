"""round-trip tests for the MarketEvent schema."""

from __future__ import annotations

import pytest

from src.market_data import (
    BBO,
    BookDelta,
    BookLevel,
    BookSnapshot,
    MarketEvent,
    Trade,
    synthetic_bbo,
    synthetic_snapshot,
)


def test_book_snapshot_event_round_trip() -> None:
    ev = synthetic_snapshot()
    raw = ev.model_dump_json()
    restored = MarketEvent.model_validate_json(raw)
    assert restored == ev


def test_bbo_event_round_trip() -> None:
    ev = synthetic_bbo()
    raw = ev.model_dump_json()
    restored = MarketEvent.model_validate_json(raw)
    assert restored == ev


def test_trade_event_construction() -> None:
    ev = MarketEvent(
        exchange="binance",
        symbol="BTCUSDT",
        ts_exchange_ns=1,
        ts_local_ns=2,
        event_type="trade",
        seq=42,
        payload=Trade(price=50_000.0, quantity=0.1, side="buy", trade_id=1),
    )
    assert ev.event_type == "trade"
    assert isinstance(ev.payload, Trade)


def test_immutability() -> None:
    ev = synthetic_snapshot()
    with pytest.raises((ValueError, TypeError)):
        ev.symbol = "ETHUSDT"  # type: ignore[misc]


def test_book_delta_zero_quantity_marker() -> None:
    delta = BookDelta(
        bids=(BookLevel(price=100.0, quantity=0.0),),  # delete level
        asks=(BookLevel(price=101.0, quantity=1.5),),
    )
    assert delta.bids[0].quantity == 0.0
    assert delta.asks[0].quantity == 1.5


def test_bbo_construction() -> None:
    bbo = BBO(bid_price=99.5, bid_qty=1.0, ask_price=100.5, ask_qty=2.0)
    assert bbo.bid_price < bbo.ask_price


def test_snapshot_with_no_bids_no_asks() -> None:
    snap = BookSnapshot()
    assert len(snap.bids) == 0
    assert len(snap.asks) == 0
