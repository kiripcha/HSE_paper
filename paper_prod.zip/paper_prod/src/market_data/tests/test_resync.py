"""ResyncManager — gap detection tests."""

from __future__ import annotations

from src.market_data import (
    BookDelta,
    MarketEvent,
    ResyncManager,
    random_walk_deltas,
)


def _make_delta_event(seq: int, symbol: str = "BTCUSDT") -> MarketEvent:
    return MarketEvent(
        exchange="binance",
        symbol=symbol,
        ts_exchange_ns=seq,
        ts_local_ns=seq,
        event_type="book_delta",
        seq=seq,
        payload=BookDelta(),
    )


def test_no_gap_in_monotonic_sequence() -> None:
    rm = ResyncManager()
    for s in range(1, 50):
        assert rm.observe(_make_delta_event(s)) is False
    assert rm.gap_rate("binance", "BTCUSDT") == 0.0


def test_gap_detected_when_seq_jumps() -> None:
    rm = ResyncManager()
    assert rm.observe(_make_delta_event(1)) is False
    assert rm.observe(_make_delta_event(2)) is False
    # jump from 2 to 10 — gap of 7
    assert rm.observe(_make_delta_event(10)) is True
    assert rm.gap_rate("binance", "BTCUSDT") > 0


def test_out_of_order_seq_does_not_raise() -> None:
    rm = ResyncManager()
    rm.observe(_make_delta_event(5))
    # older delta shouldn't trigger
    assert rm.observe(_make_delta_event(3)) is False


def test_reset_clears_state() -> None:
    rm = ResyncManager()
    rm.observe(_make_delta_event(1))
    rm.observe(_make_delta_event(10))  # gap
    rm.reset("binance", "BTCUSDT")
    assert rm.gap_rate("binance", "BTCUSDT") == 0.0


def test_random_walk_has_no_gaps() -> None:
    rm = ResyncManager()
    for ev in random_walk_deltas(seed=1, n=200):
        rm.observe(ev)
    # synthetic generator never skips sequences
    assert rm.gap_rate("binance", "BTCUSDT") == 0.0
