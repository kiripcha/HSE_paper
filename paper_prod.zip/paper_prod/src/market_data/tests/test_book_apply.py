"""order book apply/snapshot tests, including property-based checks."""

from __future__ import annotations

import numpy as np
import pytest
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st

from src.market_data import (
    ArrayBook,
    BookDelta,
    BookLevel,
    MarketEvent,
    SortedBook,
    derive_imbalance,
    derive_micro_price,
    derive_mid,
    random_walk_deltas,
    synthetic_snapshot,
)


# ---- basic apply/snapshot ----


def test_sorted_book_apply_snapshot() -> None:
    book = SortedBook("BTCUSDT")
    ev = synthetic_snapshot(depth=5, mid=100.0, spread=2.0)
    book.apply(ev)
    assert book.is_ready
    bid, ask = book.best_bid_ask
    assert bid == 99.0
    assert ask == 101.0
    snap = book.snapshot(5)
    assert len(snap.bids) == 5
    assert len(snap.asks) == 5
    assert snap.bids[0].price > snap.bids[-1].price
    assert snap.asks[0].price < snap.asks[-1].price


def test_array_book_apply_snapshot() -> None:
    book = ArrayBook("BTCUSDT", max_depth=10)
    ev = synthetic_snapshot(depth=5, mid=100.0, spread=2.0)
    book.apply(ev)
    assert book.is_ready
    bid, ask = book.best_bid_ask
    assert bid == 99.0
    assert ask == 101.0


def test_book_delta_updates_top() -> None:
    book = SortedBook("BTCUSDT")
    book.apply(synthetic_snapshot(depth=5, mid=100.0, spread=2.0))
    delta = MarketEvent(
        exchange="binance",
        symbol="BTCUSDT",
        ts_exchange_ns=1,
        ts_local_ns=1,
        event_type="book_delta",
        seq=2,
        payload=BookDelta(
            bids=(BookLevel(price=99.5, quantity=3.0),),
            asks=(BookLevel(price=100.5, quantity=4.0),),
        ),
    )
    book.apply(delta)
    bid, ask = book.best_bid_ask
    assert bid == 99.5  # new best bid
    assert ask == 100.5  # new best ask


def test_zero_quantity_removes_level() -> None:
    book = SortedBook("BTCUSDT")
    book.apply(synthetic_snapshot(depth=5, mid=100.0, spread=2.0))
    # remove current best bid 99.0
    delta = MarketEvent(
        exchange="binance",
        symbol="BTCUSDT",
        ts_exchange_ns=1,
        ts_local_ns=1,
        event_type="book_delta",
        seq=2,
        payload=BookDelta(bids=(BookLevel(price=99.0, quantity=0.0),)),
    )
    book.apply(delta)
    bid, _ = book.best_bid_ask
    assert bid == 98.0  # next-best now best


# ---- derived metrics ----


def test_derived_metrics_on_synthetic_snapshot() -> None:
    book = SortedBook("BTCUSDT")
    book.apply(synthetic_snapshot(depth=5, mid=100.0, spread=2.0))
    snap = book.snapshot(5)
    mid = derive_mid(snap)
    assert mid is not None
    assert mid == pytest.approx(100.0)
    micro = derive_micro_price(snap)
    assert micro is not None
    assert 99.0 <= micro <= 101.0
    imb = derive_imbalance(snap, levels=5)
    assert imb is not None
    assert -1.0 <= imb <= 1.0


def test_micro_price_responds_to_imbalance() -> None:
    """larger ask qty should pull micro-price toward bid (Stoikov)."""
    book = SortedBook("BTCUSDT")
    book.apply(
        MarketEvent(
            exchange="binance",
            symbol="BTCUSDT",
            ts_exchange_ns=1,
            ts_local_ns=1,
            event_type="book_snapshot",
            seq=1,
            payload=synthetic_snapshot(mid=100.0, spread=2.0, qty=1.0).payload,
        )
    )
    # add imbalanced level via delta — make ask very thick
    delta = BookDelta(
        bids=(BookLevel(price=99.0, quantity=1.0),),
        asks=(BookLevel(price=101.0, quantity=100.0),),
    )
    ev = MarketEvent(
        exchange="binance",
        symbol="BTCUSDT",
        ts_exchange_ns=2,
        ts_local_ns=2,
        event_type="book_delta",
        seq=2,
        payload=delta,
    )
    book.apply(ev)
    snap = book.snapshot(1)
    micro = derive_micro_price(snap)
    assert micro is not None
    # ask thick => micro is pulled toward bid
    assert micro < 100.0


# ---- property-based ----


@given(seed=st.integers(min_value=0, max_value=10_000), n=st.integers(min_value=10, max_value=200))
@settings(suppress_health_check=[HealthCheck.too_slow], deadline=None, max_examples=30)
def test_random_walk_book_invariants(seed: int, n: int) -> None:
    """after applying N random events from the synthetic generator:
    best_bid < best_ask and no zero-quantity levels remain."""
    book = SortedBook("BTCUSDT")
    for ev in random_walk_deltas(seed=seed, n=n):
        book.apply(ev)
    if book.is_ready:
        bid, ask = book.best_bid_ask
        assert bid < ask, f"crossed book: bid={bid} ask={ask} seed={seed}"
        snap = book.snapshot(10)
        for lvl in snap.bids:
            assert lvl.quantity > 0
        for lvl in snap.asks:
            assert lvl.quantity > 0


def test_two_books_converge() -> None:
    """sorted and Array books should report the same top-10 after the same events."""
    sb = SortedBook("BTCUSDT")
    ab = ArrayBook("BTCUSDT", max_depth=100)
    for ev in random_walk_deltas(seed=7, n=300):
        sb.apply(ev)
        ab.apply(ev)
    sb_snap = sb.snapshot(10)
    ab_snap = ab.snapshot(10)
    sb_bids = [(round(b.price, 4), round(b.quantity, 6)) for b in sb_snap.bids]
    ab_bids = [(round(b.price, 4), round(b.quantity, 6)) for b in ab_snap.bids]
    assert sb_bids == ab_bids


def test_array_book_to_arrays_shape() -> None:
    book = ArrayBook("BTCUSDT", max_depth=10)
    book.apply(synthetic_snapshot(depth=10))
    bids, asks = book.to_arrays(depth=10)
    assert bids.shape == (10, 2)
    assert asks.shape == (10, 2)
    assert not np.isnan(bids).all()
