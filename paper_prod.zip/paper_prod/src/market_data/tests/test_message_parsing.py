"""verify message parsing against real-world Binance and OKX WS payloads.
"""

from __future__ import annotations

import orjson

from src.market_data._internal.connectors import (
    _parse_binance_message,
    _parse_okx_message,
)
from src.market_data.io_schemas import BBO, BookDelta, BookSnapshot, Trade


# ---------- Binance ----------


def test_parse_binance_depth_update() -> None:
    raw = orjson.dumps(
        {
            "e": "depthUpdate",
            "E": 1577_000_123_456,
            "s": "BTCUSDT",
            "U": 157,
            "u": 160,
            "b": [["50000.00", "1.5"], ["49999.50", "0.0"]],
            "a": [["50001.00", "0.3"]],
        }
    )
    ev = _parse_binance_message(raw, ts_local_ns=42)
    assert ev is not None
    assert ev.exchange == "binance"
    assert ev.symbol == "BTCUSDT"
    assert ev.event_type == "book_delta"
    assert ev.seq == 160
    assert ev.ts_exchange_ns == 1577_000_123_456 * 1_000_000
    assert ev.ts_local_ns == 42
    assert isinstance(ev.payload, BookDelta)
    assert ev.payload.first_update_id == 157
    assert ev.payload.last_update_id == 160
    assert ev.payload.bids[0].price == 50000.0
    assert ev.payload.bids[1].quantity == 0.0  # deletion marker
    assert ev.payload.asks[0].price == 50001.0


def test_parse_binance_trade() -> None:
    raw = orjson.dumps(
        {
            "e": "trade",
            "E": 1577_000_123_456,
            "s": "BTCUSDT",
            "t": 12345,
            "p": "50000.50",
            "q": "0.1",
            "T": 1577_000_123_455,
            "m": True,  # buyer is market maker => trade direction is sell
            "M": True,
        }
    )
    ev = _parse_binance_message(raw, ts_local_ns=100)
    assert ev is not None
    assert ev.event_type == "trade"
    assert isinstance(ev.payload, Trade)
    assert ev.payload.price == 50000.5
    assert ev.payload.quantity == 0.1
    assert ev.payload.side == "sell"
    assert ev.payload.trade_id == 12345


def test_parse_binance_book_ticker() -> None:
    # note: bookTicker stream has no "e" field, but has u, s, b, B, a, A.
    raw = orjson.dumps(
        {
            "u": 400_900_217,
            "s": "BTCUSDT",
            "b": "50000.00",
            "B": "1.5",
            "a": "50001.00",
            "A": "2.5",
        }
    )
    ev = _parse_binance_message(raw, ts_local_ns=200)
    assert ev is not None
    assert ev.event_type == "bbo"
    assert isinstance(ev.payload, BBO)
    assert ev.payload.bid_price == 50000.0
    assert ev.payload.bid_qty == 1.5
    assert ev.payload.ask_price == 50001.0
    assert ev.payload.ask_qty == 2.5


def test_parse_binance_combined_stream_wrapper() -> None:
    # combined streams wrap payload in {"stream": ..., "data": {...}}
    raw = orjson.dumps(
        {
            "stream": "btcusdt@depth",
            "data": {
                "e": "depthUpdate",
                "E": 1,
                "s": "BTCUSDT",
                "U": 1,
                "u": 2,
                "b": [["50000", "1"]],
                "a": [["50001", "1"]],
            },
        }
    )
    ev = _parse_binance_message(raw, ts_local_ns=0)
    assert ev is not None
    assert ev.symbol == "BTCUSDT"
    assert ev.event_type == "book_delta"


def test_parse_binance_unknown_message_returns_none() -> None:
    # subscription ack / pong / keepalive
    raw = orjson.dumps({"result": None, "id": 1})
    ev = _parse_binance_message(raw, ts_local_ns=0)
    assert ev is None


# ---------- OKX ----------


def test_parse_okx_books_snapshot() -> None:
    raw = orjson.dumps(
        {
            "arg": {"channel": "books", "instId": "BTC-USDT"},
            "action": "snapshot",
            "data": [
                {
                    "asks": [["50001.0", "0.6", "0", "1"], ["50002.0", "1.0", "0", "1"]],
                    "bids": [["50000.0", "0.3", "0", "2"]],
                    "ts": "1629966436396",
                    "seqId": 123,
                }
            ],
        }
    )
    ev = _parse_okx_message(raw, ts_local_ns=0)
    assert ev is not None
    assert ev.exchange == "okx"
    assert ev.symbol == "BTC-USDT"
    assert ev.event_type == "book_snapshot"
    assert ev.seq == 123
    assert ev.ts_exchange_ns == 1629966436396 * 1_000_000
    assert isinstance(ev.payload, BookSnapshot)
    assert ev.payload.bids[0].price == 50000.0
    assert ev.payload.asks[0].price == 50001.0
    assert ev.payload.asks[1].quantity == 1.0


def test_parse_okx_books_update_is_delta() -> None:
    raw = orjson.dumps(
        {
            "arg": {"channel": "books", "instId": "BTC-USDT"},
            "action": "update",
            "data": [
                {
                    "asks": [["50001.0", "0.7", "0", "1"]],
                    "bids": [["50000.0", "0.0", "0", "0"]],  # remove
                    "ts": "1629966437000",
                    "seqId": 124,
                }
            ],
        }
    )
    ev = _parse_okx_message(raw, ts_local_ns=0)
    assert ev is not None
    assert ev.event_type == "book_delta"
    assert isinstance(ev.payload, BookDelta)
    assert ev.payload.bids[0].quantity == 0.0


def test_parse_okx_books5_is_always_snapshot() -> None:
    raw = orjson.dumps(
        {
            "arg": {"channel": "books5", "instId": "BTC-USDT"},
            "data": [
                {
                    "asks": [["50001", "0.6", "0", "1"]],
                    "bids": [["50000", "0.3", "0", "2"]],
                    "ts": "1629966436396",
                    "seqId": 999,
                }
            ],
        }
    )
    ev = _parse_okx_message(raw, ts_local_ns=0)
    assert ev is not None
    assert ev.event_type == "book_snapshot"


def test_parse_okx_trades() -> None:
    raw = orjson.dumps(
        {
            "arg": {"channel": "trades", "instId": "BTC-USDT"},
            "data": [
                {
                    "instId": "BTC-USDT",
                    "tradeId": "9",
                    "px": "50100.5",
                    "sz": "0.05",
                    "side": "buy",
                    "ts": "1597026383085",
                }
            ],
        }
    )
    ev = _parse_okx_message(raw, ts_local_ns=0)
    assert ev is not None
    assert ev.event_type == "trade"
    assert isinstance(ev.payload, Trade)
    assert ev.payload.price == 50100.5
    assert ev.payload.quantity == 0.05
    assert ev.payload.side == "buy"
    assert ev.payload.trade_id == 9


def test_parse_okx_subscription_ack_returns_none() -> None:
    raw = orjson.dumps(
        {"event": "subscribe", "arg": {"channel": "books", "instId": "BTC-USDT"}}
    )
    ev = _parse_okx_message(raw, ts_local_ns=0)
    assert ev is None


# ---------- Cross-exchange invariants ----------


def test_event_type_payload_consistency() -> None:
    """after parsing, payload class must match event_type."""
    binance_depth = orjson.dumps(
        {"e": "depthUpdate", "E": 1, "s": "BTCUSDT", "U": 1, "u": 2, "b": [], "a": []}
    )
    ev = _parse_binance_message(binance_depth, 0)
    assert ev is not None
    assert ev.event_type == "book_delta"
    assert isinstance(ev.payload, BookDelta)

    okx_snap = orjson.dumps(
        {
            "arg": {"channel": "books", "instId": "BTC-USDT"},
            "action": "snapshot",
            "data": [{"asks": [], "bids": [], "ts": "1", "seqId": 1}],
        }
    )
    ev = _parse_okx_message(okx_snap, 0)
    assert ev is not None
    assert ev.event_type == "book_snapshot"
    assert isinstance(ev.payload, BookSnapshot)
