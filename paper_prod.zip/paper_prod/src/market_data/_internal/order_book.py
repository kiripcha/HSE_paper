"""order book implementations.
"""

from __future__ import annotations

import numpy as np
from sortedcontainers import SortedDict

from ..interface import AbstractOrderBook
from ..io_schemas import BookDelta, BookLevel, BookSnapshot, MarketEvent


class SortedBook(AbstractOrderBook):
    """order book using SortedDict for bids/asks."""

    def __init__(self, symbol: str) -> None:
        self.symbol = symbol
        self._bids: SortedDict[float, float] = SortedDict()  # -price -> qty
        self._asks: SortedDict[float, float] = SortedDict()  # price -> qty
        self._last_update_id: int | None = None
        self._initialized = False

    @property
    def is_ready(self) -> bool:
        return self._initialized and bool(self._bids) and bool(self._asks)

    @property
    def best_bid_ask(self) -> tuple[float, float]:
        if not self._bids or not self._asks:
            raise RuntimeError(f"book {self.symbol} empty")
        bid = -next(iter(self._bids))
        ask = next(iter(self._asks))
        return bid, ask

    def apply(self, event: MarketEvent) -> None:
        if event.event_type == "book_snapshot":
            self._apply_snapshot(event.payload)  # type: ignore[arg-type]
        elif event.event_type == "book_delta":
            self._apply_delta(event.payload)  # type: ignore[arg-type]
        # other event types ignored at book level

    def _apply_snapshot(self, snap: BookSnapshot) -> None:
        self._bids.clear()
        self._asks.clear()
        for lvl in snap.bids:
            if lvl.quantity > 0:
                self._bids[-lvl.price] = lvl.quantity
        for lvl in snap.asks:
            if lvl.quantity > 0:
                self._asks[lvl.price] = lvl.quantity
        self._last_update_id = snap.last_update_id
        self._initialized = True

    def _apply_delta(self, delta: BookDelta) -> None:
        if not self._initialized:
            # apply as snapshot if no prior state
            self._initialized = True
        for lvl in delta.bids:
            key = -lvl.price
            if lvl.quantity == 0.0:
                self._bids.pop(key, None)
            else:
                self._bids[key] = lvl.quantity
        for lvl in delta.asks:
            if lvl.quantity == 0.0:
                self._asks.pop(lvl.price, None)
            else:
                self._asks[lvl.price] = lvl.quantity
        if delta.last_update_id is not None:
            self._last_update_id = delta.last_update_id

    def snapshot(self, depth: int = 10) -> BookSnapshot:
        bids = tuple(
            BookLevel(price=-k, quantity=v)
            for k, v in list(self._bids.items())[:depth]
        )
        asks = tuple(
            BookLevel(price=k, quantity=v)
            for k, v in list(self._asks.items())[:depth]
        )
        return BookSnapshot(bids=bids, asks=asks, last_update_id=self._last_update_id)

    def __len__(self) -> int:
        return len(self._bids) + len(self._asks)


class ArrayBook(AbstractOrderBook):
    """order book backed by two numpy arrays of fixed depth."""

    def __init__(self, symbol: str, max_depth: int = 100) -> None:
        self.symbol = symbol
        self.max_depth = max_depth
        # sorted dicts under the hood but materialized on snapshot.
        # we keep the dict variant because random-price updates are common.
        # the benefit of ArrayBook is the snapshot path returning numpy.
        self._bids: SortedDict[float, float] = SortedDict()
        self._asks: SortedDict[float, float] = SortedDict()
        self._last_update_id: int | None = None
        self._initialized = False

    @property
    def is_ready(self) -> bool:
        return self._initialized and bool(self._bids) and bool(self._asks)

    @property
    def best_bid_ask(self) -> tuple[float, float]:
        if not self._bids or not self._asks:
            raise RuntimeError(f"book {self.symbol} empty")
        return -next(iter(self._bids)), next(iter(self._asks))

    def apply(self, event: MarketEvent) -> None:
        if event.event_type == "book_snapshot":
            payload: BookSnapshot = event.payload  # type: ignore[assignment]
            self._bids.clear()
            self._asks.clear()
            for lvl in payload.bids[: self.max_depth]:
                if lvl.quantity > 0:
                    self._bids[-lvl.price] = lvl.quantity
            for lvl in payload.asks[: self.max_depth]:
                if lvl.quantity > 0:
                    self._asks[lvl.price] = lvl.quantity
            self._last_update_id = payload.last_update_id
            self._initialized = True
        elif event.event_type == "book_delta":
            delta: BookDelta = event.payload  # type: ignore[assignment]
            if not self._initialized:
                self._initialized = True
            for lvl in delta.bids:
                key = -lvl.price
                if lvl.quantity == 0.0:
                    self._bids.pop(key, None)
                else:
                    self._bids[key] = lvl.quantity
            for lvl in delta.asks:
                if lvl.quantity == 0.0:
                    self._asks.pop(lvl.price, None)
                else:
                    self._asks[lvl.price] = lvl.quantity
            if len(self._bids) > self.max_depth:
                # truncate worst bids (largest negative key)
                keys = list(self._bids.keys())[self.max_depth :]
                for k in keys:
                    del self._bids[k]
            if len(self._asks) > self.max_depth:
                keys = list(self._asks.keys())[self.max_depth :]
                for k in keys:
                    del self._asks[k]
            if delta.last_update_id is not None:
                self._last_update_id = delta.last_update_id

    def snapshot(self, depth: int = 10) -> BookSnapshot:
        depth = min(depth, self.max_depth)
        bid_items = list(self._bids.items())[:depth]
        ask_items = list(self._asks.items())[:depth]
        bids = tuple(BookLevel(price=-k, quantity=v) for k, v in bid_items)
        asks = tuple(BookLevel(price=k, quantity=v) for k, v in ask_items)
        return BookSnapshot(bids=bids, asks=asks, last_update_id=self._last_update_id)

    def to_arrays(self, depth: int = 10) -> tuple[np.ndarray, np.ndarray]:
        """return (bids, asks) as (depth, 2) arrays of [price, qty]."""
        depth = min(depth, self.max_depth)
        out_bids = np.full((depth, 2), np.nan, dtype=np.float64)
        out_asks = np.full((depth, 2), np.nan, dtype=np.float64)
        for i, (k, v) in enumerate(list(self._bids.items())[:depth]):
            out_bids[i] = (-k, v)
        for i, (k, v) in enumerate(list(self._asks.items())[:depth]):
            out_asks[i] = (k, v)
        return out_bids, out_asks


def make_order_book(symbol: str, implementation: str, max_depth: int) -> AbstractOrderBook:
    if implementation == "sorted":
        return SortedBook(symbol)
    if implementation == "array":
        return ArrayBook(symbol, max_depth=max_depth)
    raise ValueError(f"unknown order book implementation: {implementation}")
