"""WebSocket connectors for Binance and OKX, with reconnect/backoff.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import AsyncIterator
from typing import Any

from typing import Any as _Any

import orjson
import structlog
import websockets

from ..config import ReconnectConfig
from ..io_schemas import (
    BBO,
    BookDelta,
    BookLevel,
    BookSnapshot,
    MarketEvent,
    Trade,
)

log = structlog.get_logger(__name__)


def _binance_topic(symbol: str, channel: str) -> str:
    s = symbol.lower()
    if channel == "depth":
        return f"{s}@depth@100ms"
    if channel == "trade":
        return f"{s}@trade"
    if channel == "bookTicker":
        return f"{s}@bookTicker"
    raise ValueError(f"unknown binance channel: {channel}")


def _parse_binance_message(raw: bytes, ts_local_ns: int) -> MarketEvent | None:
    """parse a Binance combined stream message into a MarketEvent."""
    msg: dict[str, Any] = orjson.loads(raw)
    data = msg.get("data", msg)
    stream = msg.get("stream", "")
    event = data.get("e")
    if event == "depthUpdate":
        symbol = data["s"]
        bids = tuple(
            BookLevel(price=float(p), quantity=float(q)) for p, q in data.get("b", [])
        )
        asks = tuple(
            BookLevel(price=float(p), quantity=float(q)) for p, q in data.get("a", [])
        )
        return MarketEvent(
            exchange="binance",
            symbol=symbol,
            ts_exchange_ns=int(data["E"]) * 1_000_000,
            ts_local_ns=ts_local_ns,
            event_type="book_delta",
            seq=int(data.get("u", 0)),
            payload=BookDelta(
                bids=bids,
                asks=asks,
                first_update_id=int(data.get("U", 0)),
                last_update_id=int(data.get("u", 0)),
            ),
        )
    if event == "trade":
        return MarketEvent(
            exchange="binance",
            symbol=data["s"],
            ts_exchange_ns=int(data["E"]) * 1_000_000,
            ts_local_ns=ts_local_ns,
            event_type="trade",
            seq=int(data.get("t", 0)),
            payload=Trade(
                price=float(data["p"]),
                quantity=float(data["q"]),
                side="sell" if data.get("m") else "buy",  # m=true ⇒ buyer is market maker
                trade_id=int(data["t"]),
            ),
        )
    if "bookTicker" in stream or "u" in data and "b" in data and "a" in data and "B" in data:
        return MarketEvent(
            exchange="binance",
            symbol=data["s"],
            ts_exchange_ns=int(data.get("E", time.time_ns() // 1_000_000)) * 1_000_000,
            ts_local_ns=ts_local_ns,
            event_type="bbo",
            seq=int(data.get("u", 0)),
            payload=BBO(
                bid_price=float(data["b"]),
                bid_qty=float(data["B"]),
                ask_price=float(data["a"]),
                ask_qty=float(data["A"]),
            ),
        )
    return None


def _parse_okx_message(raw: bytes, ts_local_ns: int) -> MarketEvent | None:
    """parse an OKX V5 message into a MarketEvent."""
    msg: dict[str, Any] = orjson.loads(raw)
    arg = msg.get("arg", {})
    channel = arg.get("channel")
    data_arr = msg.get("data")
    if not channel or not data_arr:
        return None
    symbol = arg.get("instId", "")
    item = data_arr[0]
    ts_exchange_ns = int(item.get("ts", "0")) * 1_000_000

    if channel in ("books", "books5", "bbo-tbt"):
        bids = tuple(
            BookLevel(price=float(p), quantity=float(q))
            for p, q, *_ in item.get("bids", [])
        )
        asks = tuple(
            BookLevel(price=float(p), quantity=float(q))
            for p, q, *_ in item.get("asks", [])
        )
        action = msg.get("action", "snapshot")
        if action == "snapshot" or channel in ("books5", "bbo-tbt"):
            return MarketEvent(
                exchange="okx",
                symbol=symbol,
                ts_exchange_ns=ts_exchange_ns,
                ts_local_ns=ts_local_ns,
                event_type="book_snapshot",
                seq=int(item.get("seqId", 0)),
                payload=BookSnapshot(
                    bids=bids,
                    asks=asks,
                    last_update_id=int(item.get("seqId", 0)),
                ),
            )
        return MarketEvent(
            exchange="okx",
            symbol=symbol,
            ts_exchange_ns=ts_exchange_ns,
            ts_local_ns=ts_local_ns,
            event_type="book_delta",
            seq=int(item.get("seqId", 0)),
            payload=BookDelta(
                bids=bids,
                asks=asks,
                last_update_id=int(item.get("seqId", 0)),
            ),
        )
    if channel == "trades":
        return MarketEvent(
            exchange="okx",
            symbol=symbol,
            ts_exchange_ns=ts_exchange_ns,
            ts_local_ns=ts_local_ns,
            event_type="trade",
            seq=int(item.get("tradeId", 0)),
            payload=Trade(
                price=float(item["px"]),
                quantity=float(item["sz"]),
                side="buy" if item.get("side") == "buy" else "sell",
                trade_id=int(item.get("tradeId", 0)),
            ),
        )
    return None


class _BaseWSConnector:
    """shared async websocket client with exponential backoff reconnect."""

    exchange: str  # set by subclass

    def __init__(
        self,
        ws_url: str,
        symbols: list[str],
        channels: list[str],
        reconnect: ReconnectConfig | None = None,
    ) -> None:
        self.ws_url = ws_url
        self.symbols = symbols
        self.channels = channels
        self.reconnect = reconnect or ReconnectConfig()
        self._ws: _Any = None  # websockets ClientConnection (typed as Any to bridge API churn)
        self._queue: asyncio.Queue[MarketEvent] = asyncio.Queue(maxsize=100_000)
        self._consumer_task: asyncio.Task[None] | None = None
        self._closed = False
        self._connected_evt = asyncio.Event()

    async def connect(self) -> None:
        if self._consumer_task is None:
            self._consumer_task = asyncio.create_task(self._run_with_reconnect())
        await self._connected_evt.wait()

    async def subscribe(
        self, symbols: list[str], channels: list[str]
    ) -> None:
        self.symbols = symbols
        self.channels = channels
        if self._ws is not None and not getattr(self._ws, "closed", True):
            await self._send_subscribe(self._ws)

    async def close(self) -> None:
        self._closed = True
        if self._ws is not None:
            await self._ws.close()
        if self._consumer_task is not None:
            self._consumer_task.cancel()
            try:
                await self._consumer_task
            except (asyncio.CancelledError, Exception):
                pass

    async def stream(self) -> AsyncIterator[MarketEvent]:  # type: ignore[override]
        while not (self._closed and self._queue.empty()):
            try:
                ev = await asyncio.wait_for(self._queue.get(), timeout=1.0)
                yield ev
            except asyncio.TimeoutError:
                continue

    async def _run_with_reconnect(self) -> None:
        attempt = 0
        backoff = self.reconnect.initial_backoff_ms / 1000.0
        while not self._closed:
            try:
                async with websockets.connect(self.ws_url) as ws:
                    self._ws = ws
                    attempt = 0
                    backoff = self.reconnect.initial_backoff_ms / 1000.0
                    await self._send_subscribe(ws)
                    self._connected_evt.set()
                    async for raw in ws:
                        if self._closed:
                            break
                        ts_local = time.time_ns()
                        ev = self._parse(raw, ts_local)
                        if ev is not None:
                            await self._queue.put(ev)
            except (websockets.ConnectionClosed, OSError) as e:
                log.warning(
                    "ws_disconnect", exchange=self.exchange, error=str(e), attempt=attempt
                )
                self._connected_evt.clear()
                if self.reconnect.max_attempts >= 0 and attempt >= self.reconnect.max_attempts:
                    return
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, self.reconnect.max_backoff_ms / 1000.0)
                attempt += 1

    # to override
    async def _send_subscribe(self, ws: _Any) -> None:
        raise NotImplementedError

    def _parse(self, raw: bytes | str, ts_local_ns: int) -> MarketEvent | None:
        raise NotImplementedError


class BinanceConnector(_BaseWSConnector):
    exchange = "binance"

    async def _send_subscribe(self, ws: _Any) -> None:
        params = []
        for sym in self.symbols:
            for ch in self.channels:
                params.append(_binance_topic(sym, ch))
        msg = {"method": "SUBSCRIBE", "params": params, "id": int(time.time())}
        await ws.send(orjson.dumps(msg).decode())

    def _parse(self, raw: bytes | str, ts_local_ns: int) -> MarketEvent | None:
        if isinstance(raw, str):
            raw = raw.encode()
        return _parse_binance_message(raw, ts_local_ns)


class OkxConnector(_BaseWSConnector):
    exchange = "okx"

    async def _send_subscribe(self, ws: _Any) -> None:
        args = []
        for sym in self.symbols:
            for ch in self.channels:
                args.append({"channel": ch, "instId": sym})
        await ws.send(orjson.dumps({"op": "subscribe", "args": args}).decode())

    def _parse(self, raw: bytes | str, ts_local_ns: int) -> MarketEvent | None:
        if isinstance(raw, str):
            raw = raw.encode()
        return _parse_okx_message(raw, ts_local_ns)
