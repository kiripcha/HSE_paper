"""ResyncManager — detects sequence gaps and signals a snapshot resync."""

from __future__ import annotations

from dataclasses import dataclass, field

import structlog

from ..io_schemas import MarketEvent

log = structlog.get_logger(__name__)


@dataclass
class ResyncState:
    last_seq: int | None = None
    gap_detected: bool = False
    gap_count: int = 0
    events_seen: int = 0


@dataclass
class ResyncManager:
    """per-symbol sequence-gap detector."""

    states: dict[str, ResyncState] = field(default_factory=dict)

    def observe(self, event: MarketEvent) -> bool:
        """update state with event. Return True iff a resync is needed."""
        if event.seq is None:
            return False
        key = f"{event.exchange}:{event.symbol}"
        st = self.states.setdefault(key, ResyncState())
        st.events_seen += 1
        if st.last_seq is None:
            st.last_seq = event.seq
            return False
        # allow non-monotonic snapshots
        if event.event_type == "book_snapshot":
            st.last_seq = event.seq
            st.gap_detected = False
            return False
        # for deltas — expect strict +1 (we relax: ≥ last)
        expected = st.last_seq + 1
        if event.seq < st.last_seq:
            # out-of-order, ignore — could be a re-delivery
            return False
        if event.seq > expected:
            st.gap_detected = True
            st.gap_count += 1
            log.warning(
                "sequence_gap",
                key=key,
                expected=expected,
                got=event.seq,
                gap_size=event.seq - expected,
            )
            st.last_seq = event.seq
            return True
        st.last_seq = event.seq
        return False

    def reset(self, exchange: str, symbol: str) -> None:
        key = f"{exchange}:{symbol}"
        self.states[key] = ResyncState()

    def gap_rate(self, exchange: str, symbol: str) -> float:
        key = f"{exchange}:{symbol}"
        st = self.states.get(key)
        if st is None or st.events_seen == 0:
            return 0.0
        return st.gap_count / st.events_seen
