"""synthetic market data generators for tests and notebook experiments."""

from __future__ import annotations

import time
from collections.abc import Iterator

import numpy as np

from ..io_schemas import (
    BBO,
    BookDelta,
    BookLevel,
    BookSnapshot,
    MarketEvent,
    Trade,
)


def synthetic_snapshot(
    exchange: str = "binance",
    symbol: str = "BTCUSDT",
    mid: float = 50_000.0,
    spread: float = 1.0,
    depth: int = 10,
    qty: float = 1.0,
    ts_ns: int | None = None,
) -> MarketEvent:
    """build a synthetic L2 snapshot centered around `mid`."""
    if ts_ns is None:
        ts_ns = time.time_ns()
    bid_top = mid - spread / 2
    ask_top = mid + spread / 2
    bids = tuple(
        BookLevel(price=bid_top - i, quantity=qty * (1 + i * 0.1)) for i in range(depth)
    )
    asks = tuple(
        BookLevel(price=ask_top + i, quantity=qty * (1 + i * 0.1)) for i in range(depth)
    )
    return MarketEvent(
        exchange=exchange,  # type: ignore[arg-type]
        symbol=symbol,
        ts_exchange_ns=ts_ns,
        ts_local_ns=ts_ns,
        event_type="book_snapshot",
        seq=1,
        payload=BookSnapshot(bids=bids, asks=asks, last_update_id=1),
    )


def random_walk_deltas(
    seed: int = 42,
    n: int = 1000,
    start_mid: float = 50_000.0,
    sigma: float = 0.5,
    symbol: str = "BTCUSDT",
    exchange: str = "binance",
    start_ts_ns: int | None = None,
    inter_arrival_ns: int = 100_000_000,  # 100ms
    tick_size: float = 0.5,
    emit_initial_snapshot: bool = True,
) -> Iterator[MarketEvent]:
    """yield a non-crossing stream of book deltas plus occasional trades."""
    rng = np.random.default_rng(seed)
    mid = start_mid
    ts_ns = start_ts_ns if start_ts_ns is not None else time.time_ns()
    last_seq = 1
    initial_spread = max(tick_size, tick_size * 2)
    prev_bid: float | None = round((mid - initial_spread / 2.0) / tick_size) * tick_size
    prev_ask: float | None = round((mid + initial_spread / 2.0) / tick_size) * tick_size
    if emit_initial_snapshot:
        yield MarketEvent(
            exchange=exchange,  # type: ignore[arg-type]
            symbol=symbol,
            ts_exchange_ns=ts_ns,
            ts_local_ns=ts_ns,
            event_type="book_snapshot",
            seq=last_seq,
            payload=BookSnapshot(
                bids=(BookLevel(price=prev_bid, quantity=1.0),),
                asks=(BookLevel(price=prev_ask, quantity=1.0),),
                last_update_id=last_seq,
            ),
        )
    for _ in range(n):
        # mid step bounded so the walk doesn't drift unrealistically fast
        step = float(np.clip(rng.normal(0.0, sigma), -3 * sigma, 3 * sigma))
        mid = float(mid + step)
        spread = max(tick_size, tick_size * (1.0 + abs(rng.normal(0.0, 0.5))))
        bid_price = round((mid - spread / 2.0) / tick_size) * tick_size
        ask_price = bid_price + max(tick_size, round(spread / tick_size) * tick_size)
        bid_qty = float(abs(rng.normal(1.0, 0.3)) + 0.1)
        ask_qty = float(abs(rng.normal(1.0, 0.3)) + 0.1)
        bid_levels: list[BookLevel] = []
        ask_levels: list[BookLevel] = []
        if prev_bid is not None and prev_bid != bid_price:
            bid_levels.append(BookLevel(price=prev_bid, quantity=0.0))
        if prev_ask is not None and prev_ask != ask_price:
            ask_levels.append(BookLevel(price=prev_ask, quantity=0.0))
        bid_levels.append(BookLevel(price=bid_price, quantity=bid_qty))
        ask_levels.append(BookLevel(price=ask_price, quantity=ask_qty))
        prev_bid, prev_ask = bid_price, ask_price
        last_seq += 1
        yield MarketEvent(
            exchange=exchange,  # type: ignore[arg-type]
            symbol=symbol,
            ts_exchange_ns=ts_ns,
            ts_local_ns=ts_ns,
            event_type="book_delta",
            seq=last_seq,
            payload=BookDelta(
                bids=tuple(bid_levels),
                asks=tuple(ask_levels),
                last_update_id=last_seq,
            ),
        )
        if rng.random() < 0.1:
            last_seq += 1
            yield MarketEvent(
                exchange=exchange,  # type: ignore[arg-type]
                symbol=symbol,
                ts_exchange_ns=ts_ns,
                ts_local_ns=ts_ns,
                event_type="trade",
                seq=last_seq,
                payload=Trade(
                    price=bid_price if rng.random() < 0.5 else ask_price,
                    quantity=float(abs(rng.normal(0.3, 0.1)) + 0.01),
                    side="buy" if rng.random() < 0.5 else "sell",
                    trade_id=last_seq,
                ),
            )
        ts_ns += inter_arrival_ns


def synthetic_bbo(
    exchange: str = "binance",
    symbol: str = "BTCUSDT",
    mid: float = 50_000.0,
    spread: float = 1.0,
    ts_ns: int | None = None,
) -> MarketEvent:
    if ts_ns is None:
        ts_ns = time.time_ns()
    return MarketEvent(
        exchange=exchange,  # type: ignore[arg-type]
        symbol=symbol,
        ts_exchange_ns=ts_ns,
        ts_local_ns=ts_ns,
        event_type="bbo",
        seq=1,
        payload=BBO(
            bid_price=mid - spread / 2,
            bid_qty=1.0,
            ask_price=mid + spread / 2,
            ask_qty=1.0,
        ),
    )
