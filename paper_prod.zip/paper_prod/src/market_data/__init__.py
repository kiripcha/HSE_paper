"""market_data — exchange ingestion and order book engine.
"""

from ._internal.connectors import BinanceConnector, OkxConnector
from ._internal.order_book import ArrayBook, SortedBook, make_order_book
from ._internal.resync import ResyncManager
from ._internal.synthetic import (
    random_walk_deltas,
    synthetic_bbo,
    synthetic_snapshot,
)
from .config import (
    DEFAULT_BINANCE_SPEC,
    DEFAULT_OKX_SPEC,
    ExchangeSpec,
    MarketDataConfig,
    OrderBookConfig,
    ReconnectConfig,
)
from .interface import AbstractOrderBook, ExchangeConnector, OrderBookProtocol
from .io_schemas import (
    BBO,
    BookDelta,
    BookLevel,
    BookSnapshot,
    MarketEvent,
    Trade,
    derive_imbalance,
    derive_micro_price,
    derive_mid,
)

__all__ = [
    "MarketEvent",
    "BookDelta",
    "BookSnapshot",
    "BookLevel",
    "Trade",
    "BBO",
    "ExchangeConnector",
    "OrderBookProtocol",
    "AbstractOrderBook",
    "BinanceConnector",
    "OkxConnector",
    "SortedBook",
    "ArrayBook",
    "make_order_book",
    "ResyncManager",
    "MarketDataConfig",
    "ExchangeSpec",
    "OrderBookConfig",
    "ReconnectConfig",
    "DEFAULT_BINANCE_SPEC",
    "DEFAULT_OKX_SPEC",
    "derive_mid",
    "derive_micro_price",
    "derive_imbalance",
    "synthetic_snapshot",
    "synthetic_bbo",
    "random_walk_deltas",
]
