"""public protocols (contracts) of the market_data module."""

from __future__ import annotations

from abc import abstractmethod
from typing import AsyncIterator, Protocol, runtime_checkable

from .io_schemas import BookSnapshot, MarketEvent


@runtime_checkable
class ExchangeConnector(Protocol):
    """live exchange connector. Storage replay engine implements the same protocol."""

    exchange: str

    async def connect(self) -> None: ...

    async def subscribe(
        self, symbols: list[str], channels: list[str]
    ) -> None: ...

    def stream(self) -> AsyncIterator[MarketEvent]: ...

    async def close(self) -> None: ...


@runtime_checkable
class OrderBookProtocol(Protocol):
    """in-memory limit order book state for a single symbol."""

    symbol: str

    def apply(self, event: MarketEvent) -> None: ...

    def snapshot(self, depth: int = 10) -> BookSnapshot: ...

    @property
    def best_bid_ask(self) -> tuple[float, float]: ...

    @property
    def is_ready(self) -> bool: ...


class AbstractOrderBook:
    """convenience ABC for concrete order book implementations."""

    symbol: str

    @abstractmethod
    def apply(self, event: MarketEvent) -> None: ...

    @abstractmethod
    def snapshot(self, depth: int = 10) -> BookSnapshot: ...

    @property
    @abstractmethod
    def best_bid_ask(self) -> tuple[float, float]: ...

    @property
    @abstractmethod
    def is_ready(self) -> bool: ...
