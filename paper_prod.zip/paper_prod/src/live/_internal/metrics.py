"""prometheus-style metrics exporter (with graceful fallback if prometheus_client is missing)."""

from __future__ import annotations

from collections import defaultdict
from typing import Any


class MetricsExporter:
    """lightweight metrics collector."""

    def __init__(self, port: int = 9090, registry: Any = None) -> None:
        self.port = port
        self._counters: dict[str, float] = defaultdict(float)
        self._gauges: dict[str, float] = {}
        self._histograms: dict[str, list[float]] = defaultdict(list)
        try:
            from prometheus_client import (
                CollectorRegistry,
                Counter,
                Gauge,
                Histogram,
                start_http_server,
            )

            self._registry = registry or CollectorRegistry()
            self._Counter = Counter
            self._Gauge = Gauge
            self._Histogram = Histogram
            self._start = start_http_server
            self._prom_counters: dict[str, Any] = {}
            self._prom_gauges: dict[str, Any] = {}
            self._prom_histograms: dict[str, Any] = {}
            self._prometheus_available = True
        except ImportError:
            self._prometheus_available = False

    def start_server(self) -> None:
        if self._prometheus_available:
            self._start(self.port, registry=self._registry)

    def incr(self, name: str, value: float = 1.0) -> None:
        self._counters[name] += value
        if self._prometheus_available:
            c = self._prom_counters.setdefault(
                name, self._Counter(name, name, registry=self._registry)
            )
            c.inc(value)

    def set_gauge(self, name: str, value: float) -> None:
        self._gauges[name] = value
        if self._prometheus_available:
            g = self._prom_gauges.setdefault(
                name, self._Gauge(name, name, registry=self._registry)
            )
            g.set(value)

    def observe(self, name: str, value: float) -> None:
        self._histograms[name].append(value)
        if self._prometheus_available:
            h = self._prom_histograms.setdefault(
                name, self._Histogram(name, name, registry=self._registry)
            )
            h.observe(value)

    def snapshot(self) -> dict[str, Any]:
        return {
            "counters": dict(self._counters),
            "gauges": dict(self._gauges),
            "histograms": {k: list(v) for k, v in self._histograms.items()},
        }
