"""TradingApp — composes all 11 modules into one runtime.
"""

from __future__ import annotations

import asyncio
import time

import structlog

from src.execution import OMS
from src.market_data.interface import ExchangeConnector
from src.market_data.io_schemas import MarketEvent
from src.portfolio.io_schemas import TargetWeights
from src.risk import (
    CryptoRiskAdapter,
    KillSwitch,
    PortfolioMonitor,
    RiskGate,
    ValidationResult,
)

from ..config import TradingAppConfig
from .metrics import MetricsExporter

log = structlog.get_logger(__name__)


class TradingApp:
    """live/paper/backtest runtime."""

    def __init__(
        self,
        config: TradingAppConfig,
        connector: ExchangeConnector,
        risk_gate: RiskGate | None = None,
        crypto_risk_adapter: CryptoRiskAdapter | None = None,
    ) -> None:
        self.config = config
        self.connector = connector
        self.oms = OMS()
        self.portfolio = PortfolioMonitor(starting_cash=100_000.0)
        self.kill_switch = KillSwitch()
        self.risk_gate = risk_gate or RiskGate()
        # heavy analytics adapter — wired in optionally; per-tick code path
        # is unaffected when it is None.
        self.crypto_risk = crypto_risk_adapter
        self.metrics = MetricsExporter(port=config.monitoring.prometheus_port)
        self._running = False
        self._stop_evt: asyncio.Event = asyncio.Event()

    def validate_target_weights(
        self, target: TargetWeights, current_dd: float = 0.0
    ) -> ValidationResult:
        """run both risk layers on a candidate set of target weights."""
        # 1) runtime gate
        self.risk_gate.kill_switch_active = self.kill_switch.is_active()
        result = self.risk_gate.validate(target, current_drawdown_pct=current_dd)
        if not result.approved:
            return result
        # 2) crypto_risk analytics
        if self.crypto_risk is not None:
            adj = self.crypto_risk.validate_target(target, current_drawdown=current_dd)
            if not adj.approved or adj.violations:
                return adj
            if adj.adjusted_weights is not None:
                return adj
        return result

    async def start(self) -> None:
        log.info("trading_app_start", mode=self.config.mode, symbols=self.config.symbols)
        self.metrics.start_server()
        await self.connector.connect()
        self._running = True

    async def run_until_done(self, max_events: int | None = None) -> int:
        """main event loop. Returns the number of events processed."""
        if not self._running:
            await self.start()
        n_events = 0
        async for ev in self.connector.stream():
            if self.kill_switch.is_active():
                log.warning("kill_switch_triggered", reason=self.kill_switch.reason)
                break
            await self._handle_event(ev)
            n_events += 1
            if max_events is not None and n_events >= max_events:
                break
            if self._stop_evt.is_set():
                break
        await self.stop()
        return n_events

    async def _handle_event(self, ev: MarketEvent) -> None:
        t0 = time.perf_counter_ns()
        self.metrics.incr(f"events_total_{ev.event_type}")
        # downstream modules would be wired in here:
        # features.update(ev) → models.predict → allocator.allocate → portfolio.optimize → risk.validate → execution.send
        # for diploma we keep this lean — full chain is exercised in backtest module 11.
        latency_us = (time.perf_counter_ns() - t0) / 1000
        self.metrics.observe("handle_event_latency_us", latency_us)

    async def stop(self) -> None:
        self._stop_evt.set()
        self._running = False
        await self.connector.close()
        log.info("trading_app_stop")

    def metrics_snapshot(self) -> dict:
        return self.metrics.snapshot()
