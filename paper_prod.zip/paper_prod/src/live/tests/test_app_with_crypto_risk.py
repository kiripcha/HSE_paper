"""TradingApp integration with the crypto_risk adapter."""

from __future__ import annotations

from collections.abc import AsyncIterator

import numpy as np
import pandas as pd
import pytest

from src.live import TradingApp, TradingAppConfig
from src.market_data import random_walk_deltas
from src.market_data.io_schemas import MarketEvent
from src.portfolio.io_schemas import TargetWeights
from src.risk import CryptoRiskAdapter


class _FakeConnector:
    exchange = "fake"

    def __init__(self, events: list[MarketEvent]) -> None:
        self._events = events
        self._closed = False

    async def connect(self) -> None: ...
    async def subscribe(self, symbols, channels) -> None: ...

    async def stream(self) -> AsyncIterator[MarketEvent]:
        for ev in self._events:
            if self._closed:
                break
            yield ev

    async def close(self) -> None:
        self._closed = True


@pytest.fixture(scope="module")
def adapter() -> CryptoRiskAdapter:
    from crypto_risk.data import MultiSourceCryptoLoader

    universe = ("BTC", "ETH", "BNB", "SOL", "ADA")
    ld = MultiSourceCryptoLoader(universe, mode="synthetic")
    prices = ld.load_close_panel("2022-01-01", "2024-01-01")
    rets = np.log(prices / prices.shift(1)).dropna()
    return CryptoRiskAdapter.from_returns(rets)


@pytest.mark.asyncio
async def test_app_runs_with_crypto_risk_attached(adapter: CryptoRiskAdapter) -> None:
    """the runtime loop works the same with or without the analytics adapter."""
    events = list(random_walk_deltas(seed=1, n=50))
    app = TradingApp(
        TradingAppConfig(mode="paper"),
        connector=_FakeConnector(events),
        crypto_risk_adapter=adapter,
    )
    n = await app.run_until_done(max_events=50)
    assert n == 50


def test_validate_target_weights_uses_both_layers(adapter: CryptoRiskAdapter) -> None:
    """the composed validator must check both RiskGate and crypto_risk."""
    app = TradingApp(
        TradingAppConfig(mode="paper"),
        connector=_FakeConnector([]),
        crypto_risk_adapter=adapter,
    )
    # over-concentrated → RiskGate (runtime) catches it before crypto_risk runs
    target_concentrated = TargetWeights(ts_ns=1, weights={"BTC": 0.95, "ETH": 0.05})
    res = app.validate_target_weights(target_concentrated, current_dd=0.0)
    assert not res.approved
    assert any(v.code == "POSITION_CONCENTRATION" for v in res.violations)

    # well diversified → runtime gate approves; crypto_risk inspects VaR
    target_diversified = TargetWeights(
        ts_ns=2, weights={"BTC": 0.20, "ETH": 0.20, "BNB": 0.20, "SOL": 0.20, "ADA": 0.20}
    )
    res = app.validate_target_weights(target_diversified, current_dd=0.0)
    # either approved or flagged by crypto_risk's VaR check — both behaviours are valid
    # under default tight risk budgets; we only assert no exception was raised.
    assert isinstance(res.approved, bool)


def test_kill_switch_short_circuits_validation(adapter: CryptoRiskAdapter) -> None:
    """when the runtime kill switch is set, crypto_risk is not consulted at all."""
    app = TradingApp(
        TradingAppConfig(mode="paper"),
        connector=_FakeConnector([]),
        crypto_risk_adapter=adapter,
    )
    app.kill_switch.trigger("test")
    target = TargetWeights(ts_ns=1, weights={"BTC": 0.5, "ETH": 0.5})
    res = app.validate_target_weights(target)
    assert not res.approved
    assert any(v.code == "KILL_SWITCH_ACTIVE" for v in res.violations)
