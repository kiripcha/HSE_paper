"""tests for the TradingApp event loop and mode-switching contract."""

from __future__ import annotations

from collections.abc import AsyncIterator
from pathlib import Path

import pytest

from src.live import MetricsExporter, TradingApp, TradingAppConfig
from src.market_data import random_walk_deltas
from src.market_data.io_schemas import MarketEvent
from src.storage import ParquetTickWriter, ReplayConfig, ReplayEngine, StorageConfig


class _FakeConnector:
    exchange = "fake"

    def __init__(self, events: list[MarketEvent]) -> None:
        self._events = events
        self._closed = False

    async def connect(self) -> None:
        return

    async def subscribe(self, symbols, channels) -> None:
        return

    async def stream(self) -> AsyncIterator[MarketEvent]:
        for ev in self._events:
            if self._closed:
                break
            yield ev

    async def close(self) -> None:
        self._closed = True


@pytest.mark.asyncio
async def test_app_processes_events() -> None:
    events = list(random_walk_deltas(seed=1, n=100))
    app = TradingApp(TradingAppConfig(mode="paper"), connector=_FakeConnector(events))
    n = await app.run_until_done(max_events=100)
    assert n == 100
    snap = app.metrics_snapshot()
    # counters per event_type
    assert sum(v for k, v in snap["counters"].items() if k.startswith("events_total_")) == 100


@pytest.mark.asyncio
async def test_app_works_with_replay_engine(tmp_path: Path) -> None:
    """same TradingApp accepts a ReplayEngine (storage) interchangeably with live."""
    cfg = StorageConfig(root_path=tmp_path / "ticks", flush_max_events=10**9)
    writer = ParquetTickWriter(cfg)
    events = list(random_walk_deltas(seed=2, n=200))
    for ev in events:
        writer.write(ev)
    await writer.close()
    engine = ReplayEngine(
        storage=cfg, replay=ReplayConfig(speed="max"),
        from_ns=min(e.ts_exchange_ns for e in events),
        to_ns=max(e.ts_exchange_ns for e in events),
        sources=[("binance", "BTCUSDT")],
    )
    app = TradingApp(TradingAppConfig(mode="backtest"), connector=engine)
    n = await app.run_until_done(max_events=200)
    assert n == 200


def test_metrics_exporter_no_prom_dependency() -> None:
    m = MetricsExporter()
    m.incr("foo")
    m.incr("foo", 2.0)
    m.set_gauge("bar", 42.0)
    m.observe("hist", 1.5)
    snap = m.snapshot()
    assert snap["counters"]["foo"] == 3.0
    assert snap["gauges"]["bar"] == 42.0
    assert snap["histograms"]["hist"] == [1.5]


@pytest.mark.asyncio
async def test_kill_switch_stops_loop() -> None:
    events = list(random_walk_deltas(seed=3, n=500))
    app = TradingApp(TradingAppConfig(mode="paper"), connector=_FakeConnector(events))
    # trigger kill switch after the loop starts
    app.kill_switch.trigger("manual")
    n = await app.run_until_done(max_events=500)
    # processed zero events because kill switch was set before stream consumption
    assert n == 0
