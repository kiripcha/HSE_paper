"""TradingApp config schema."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

TradingMode = Literal["backtest", "paper", "live"]


class MonitoringConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    prometheus_port: int = 9090
    health_port: int = 8080
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"


class AlertRule(BaseModel):
    model_config = ConfigDict(frozen=True)

    name: str
    condition: str
    severity: Literal["info", "warning", "critical"] = "warning"


class AlertsConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    enabled: bool = True
    rules: list[AlertRule] = Field(default_factory=list)


class TradingAppConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    mode: TradingMode = "paper"
    symbols: list[str] = Field(default_factory=lambda: ["BTCUSDT"])
    warmup_duration_sec: float = 60.0
    shutdown_grace_sec: float = 10.0
    monitoring: MonitoringConfig = MonitoringConfig()
    alerts: AlertsConfig = AlertsConfig()
