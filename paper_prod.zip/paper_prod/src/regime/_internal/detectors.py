"""regime detectors: online HMM, Bayesian Online Change-Point Detection.
"""

from __future__ import annotations

import math

import numpy as np

from ..io_schemas import RegimeState


class HMMDetector:
    """online Gaussian HMM with EM-style update."""

    def __init__(
        self,
        n_regimes: int = 3,
        means: list[float] | None = None,
        stds: list[float] | None = None,
        trans: np.ndarray | None = None,
        learning_rate: float = 0.01,
    ) -> None:
        self.n_regimes = n_regimes
        self.means = np.array(
            means if means is not None else [-0.001, 0.0, 0.001], dtype=np.float64
        )[:n_regimes]
        self.stds = np.array(
            stds if stds is not None else [0.02, 0.005, 0.02], dtype=np.float64
        )[:n_regimes]
        if trans is None:
            self.trans = np.full((n_regimes, n_regimes), 0.05)
            np.fill_diagonal(self.trans, 1.0 - 0.05 * (n_regimes - 1))
        else:
            self.trans = trans
        self.lr = learning_rate
        self.belief = np.full(n_regimes, 1.0 / n_regimes)
        self._prev_argmax = 0
        self._steps_in_regime = 0

    def reset(self) -> None:
        self.belief = np.full(self.n_regimes, 1.0 / self.n_regimes)
        self._prev_argmax = 0
        self._steps_in_regime = 0

    def update(self, x: float | np.ndarray, ts_ns: int, symbol: str = "?") -> RegimeState:
        val = float(x if not isinstance(x, np.ndarray) else x.item())
        # 1) predict step: prior = belief @ trans
        prior = self.belief @ self.trans
        # 2) likelihood per regime
        lik = np.exp(-0.5 * ((val - self.means) / self.stds) ** 2) / (
            self.stds * math.sqrt(2 * math.pi)
        )
        posterior = prior * lik
        s = posterior.sum()
        if s <= 0:
            posterior = np.full(self.n_regimes, 1.0 / self.n_regimes)
        else:
            posterior /= s
        self.belief = posterior
        # 3) light online parameter update — moves mean/std toward observed
        argmax = int(np.argmax(self.belief))
        self.means[argmax] = (1 - self.lr) * self.means[argmax] + self.lr * val
        self.stds[argmax] = math.sqrt(
            max(
                1e-8,
                (1 - self.lr) * self.stds[argmax] ** 2
                + self.lr * (val - self.means[argmax]) ** 2,
            )
        )
        if argmax == self._prev_argmax:
            self._steps_in_regime += 1
        else:
            self._steps_in_regime = 0
            self._prev_argmax = argmax
        return RegimeState(
            ts_ns=ts_ns,
            symbol=symbol,
            regime_id=argmax,
            probabilities=self.belief.copy(),
            steps_in_regime=self._steps_in_regime,
            change_point_proba=0.0,
        )


class BOCPDDetector:
    """bayesian Online Change-Point Detection."""

    n_regimes = 1

    def __init__(
        self, hazard: float = 1 / 100, mu0: float = 0.0, kappa0: float = 0.1,
        alpha0: float = 2.0, beta0: float = 0.0001,
    ) -> None:
        """informative-by-default prior: encodes ~ N(0, 0.01) per-observation noise."""
        self.hazard = hazard
        self.mu0 = mu0
        self.kappa0 = kappa0
        self.alpha0 = alpha0
        self.beta0 = beta0
        # truncated run-length distribution
        self._run_length_proba = np.array([1.0], dtype=np.float64)
        self._mu = np.array([mu0], dtype=np.float64)
        self._kappa = np.array([kappa0], dtype=np.float64)
        self._alpha = np.array([alpha0], dtype=np.float64)
        self._beta = np.array([beta0], dtype=np.float64)
        self._max_rl = 500
        self._n_seen = 0

    def reset(self) -> None:
        self._run_length_proba = np.array([1.0], dtype=np.float64)
        self._mu = np.array([self.mu0], dtype=np.float64)
        self._kappa = np.array([self.kappa0], dtype=np.float64)
        self._alpha = np.array([self.alpha0], dtype=np.float64)
        self._beta = np.array([self.beta0], dtype=np.float64)
        self._n_seen = 0

    def _predictive_logpdf(self, x: float) -> np.ndarray:
        # student-t predictive of NIG conjugate model
        scale = np.sqrt(self._beta * (self._kappa + 1.0) / (self._alpha * self._kappa))
        df = 2 * self._alpha
        z = (x - self._mu) / scale
        # log pdf of student-t with df degrees of freedom
        from scipy import stats
        return stats.t.logpdf(z, df) - np.log(scale)

    def update(self, x: float | np.ndarray, ts_ns: int, symbol: str = "?") -> RegimeState:
        self._n_seen += 1
        v = float(x if not isinstance(x, np.ndarray) else x.item())
        log_pred = self._predictive_logpdf(v)
        # use relative likelihoods (do NOT normalize across run-lengths —
        # likelihoods are densities, not probabilities. Scale by max for stability.
        pred = np.exp(log_pred - log_pred.max())
        # growth / change probabilities
        growth = self._run_length_proba * pred * (1 - self.hazard)
        change = (self._run_length_proba * pred * self.hazard).sum()
        new_rl = np.concatenate(([change], growth))
        new_rl = new_rl / new_rl.sum()
        # update sufficient statistics
        new_mu0 = np.array([self.mu0])
        new_kappa0 = np.array([self.kappa0])
        new_alpha0 = np.array([self.alpha0])
        new_beta0 = np.array([self.beta0])
        new_mu = np.concatenate(
            [new_mu0, (self._kappa * self._mu + v) / (self._kappa + 1.0)]
        )
        new_kappa = np.concatenate([new_kappa0, self._kappa + 1.0])
        new_alpha = np.concatenate([new_alpha0, self._alpha + 0.5])
        new_beta = np.concatenate(
            [
                new_beta0,
                self._beta
                + (self._kappa * (v - self._mu) ** 2) / (2.0 * (self._kappa + 1.0)),
            ]
        )
        # truncate
        if len(new_rl) > self._max_rl:
            new_rl = new_rl[: self._max_rl]
            new_mu = new_mu[: self._max_rl]
            new_kappa = new_kappa[: self._max_rl]
            new_alpha = new_alpha[: self._max_rl]
            new_beta = new_beta[: self._max_rl]
            new_rl = new_rl / new_rl.sum()
        self._run_length_proba = new_rl
        self._mu = new_mu
        self._kappa = new_kappa
        self._alpha = new_alpha
        self._beta = new_beta

        argmax_rl = int(np.argmax(self._run_length_proba))
        return RegimeState(
            ts_ns=ts_ns,
            symbol=symbol,
            regime_id=0,
            probabilities=np.array([1.0]),
            steps_in_regime=argmax_rl,
            change_point_proba=float(self._run_length_proba[0]),
        )


class VolClusterDetector:
    """simple volatility-based regime detector."""

    def __init__(self, n_regimes: int = 3, window: int = 100, history: int = 1000) -> None:
        self.n_regimes = n_regimes
        self.window = window
        self.history = history
        self._returns: list[float] = []
        self._vols_history: list[float] = []
        self._prev_argmax = 0
        self._steps_in_regime = 0

    def reset(self) -> None:
        self._returns.clear()
        self._vols_history.clear()
        self._prev_argmax = 0
        self._steps_in_regime = 0

    def update(self, x: float | np.ndarray, ts_ns: int, symbol: str = "?") -> RegimeState:
        v = float(x if not isinstance(x, np.ndarray) else x.item())
        self._returns.append(v)
        if len(self._returns) > self.window:
            self._returns.pop(0)
        if len(self._returns) < 5:
            probs = np.full(self.n_regimes, 1.0 / self.n_regimes)
            return RegimeState(
                ts_ns=ts_ns, symbol=symbol, regime_id=0, probabilities=probs, steps_in_regime=0,
            )
        vol = float(np.std(self._returns, ddof=1))
        self._vols_history.append(vol)
        if len(self._vols_history) > self.history:
            self._vols_history.pop(0)
        thresholds = np.quantile(
            self._vols_history, np.linspace(0, 1, self.n_regimes + 1)[1:-1]
        )
        regime = int(np.searchsorted(thresholds, vol))
        probs = np.zeros(self.n_regimes)
        probs[regime] = 1.0
        if regime == self._prev_argmax:
            self._steps_in_regime += 1
        else:
            self._steps_in_regime = 0
            self._prev_argmax = regime
        return RegimeState(
            ts_ns=ts_ns,
            symbol=symbol,
            regime_id=regime,
            probabilities=probs,
            steps_in_regime=self._steps_in_regime,
            metadata={"vol": vol},
        )
