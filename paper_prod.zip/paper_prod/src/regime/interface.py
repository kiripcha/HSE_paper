"""public protocol for regime detectors."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

import numpy as np

from .io_schemas import RegimeState


@runtime_checkable
class RegimeDetector(Protocol):
    n_regimes: int

    def update(self, x: float | np.ndarray, ts_ns: int, symbol: str = "?") -> RegimeState: ...

    def reset(self) -> None: ...
