"""tests for online regime detectors."""

from __future__ import annotations

import numpy as np
import pytest

from src.regime import BOCPDDetector, HMMDetector, VolClusterDetector


def _two_regime_series(n: int = 500, seed: int = 0) -> tuple[np.ndarray, np.ndarray]:
    """return (returns, true_regime). First half low-vol, second half high-vol."""
    rng = np.random.default_rng(seed)
    a = rng.normal(0.0, 0.005, n // 2)
    b = rng.normal(0.0, 0.05, n // 2)
    return np.concatenate([a, b]), np.array([0] * (n // 2) + [1] * (n // 2))


def test_hmm_probabilities_sum_to_one() -> None:
    det = HMMDetector(n_regimes=3)
    rng = np.random.default_rng(0)
    for v in rng.normal(0.001, 0.01, 100):
        st = det.update(v, ts_ns=int(v * 1e9), symbol="X")
        assert abs(st.probabilities.sum() - 1.0) < 1e-9


def test_vol_cluster_detects_regime_shift() -> None:
    det = VolClusterDetector(n_regimes=3, window=50, history=500)
    rets, true_r = _two_regime_series(n=600, seed=1)
    states = [det.update(v, ts_ns=i, symbol="X") for i, v in enumerate(rets)]
    # last 100 points should be in higher-vol regime than first 100 (after burn-in)
    early = np.array([s.regime_id for s in states[100:200]])
    late = np.array([s.regime_id for s in states[-100:]])
    assert late.mean() > early.mean()


def test_bocpd_signals_change_point() -> None:
    """the argmax run-length (steps_in_regime) should drop dramatically near a change."""
    det = BOCPDDetector(hazard=0.01)
    rets, _ = _two_regime_series(n=400, seed=2)
    states = [det.update(v, ts_ns=i, symbol="X") for i, v in enumerate(rets)]
    run_lengths = np.array([s.steps_in_regime for s in states])
    pre_change_peak = run_lengths[150:200].max()
    post_change_min = run_lengths[200:250].min()
    # mode of run length should drop by at least 50% across the change point
    assert post_change_min < pre_change_peak / 2


def test_strict_online_no_revision() -> None:
    """running the detector twice on the same prefix yields identical states."""
    rets, _ = _two_regime_series(n=300, seed=3)
    det1 = HMMDetector(n_regimes=3)
    det2 = HMMDetector(n_regimes=3)
    states1 = [det1.update(v, ts_ns=i, symbol="X") for i, v in enumerate(rets)]
    states2 = [det2.update(v, ts_ns=i, symbol="X") for i, v in enumerate(rets)]
    for s1, s2 in zip(states1, states2, strict=True):
        assert s1.regime_id == s2.regime_id
        assert np.allclose(s1.probabilities, s2.probabilities)


def test_steps_in_regime_increments() -> None:
    det = VolClusterDetector(n_regimes=3, window=30, history=200)
    rng = np.random.default_rng(5)
    # constant noise — once it picks a regime, steps_in_regime should grow
    rets = rng.normal(0.0, 0.01, 200)
    states = [det.update(v, ts_ns=i, symbol="X") for i, v in enumerate(rets)]
    final_steps = states[-1].steps_in_regime
    assert final_steps >= 0


@pytest.mark.parametrize("det_cls", [HMMDetector, VolClusterDetector])
def test_reset_clears_state(det_cls) -> None:
    det = det_cls()
    for v in np.random.default_rng(0).normal(0, 0.01, 100):
        det.update(v, ts_ns=int(v * 1e9), symbol="X")
    det.reset()
    st = det.update(0.0, ts_ns=0, symbol="X")
    assert st.steps_in_regime == 0
