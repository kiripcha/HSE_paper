"""schemas for the regime detection module."""

from __future__ import annotations

import numpy as np
from pydantic import BaseModel, ConfigDict, Field


class RegimeState(BaseModel):
    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    ts_ns: int
    symbol: str
    regime_id: int
    probabilities: np.ndarray
    steps_in_regime: int = 0
    change_point_proba: float = 0.0
    metadata: dict[str, float] = Field(default_factory=dict)
