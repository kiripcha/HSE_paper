"""regime — online regime detection.
"""

from ._internal.detectors import BOCPDDetector, HMMDetector, VolClusterDetector
from .interface import RegimeDetector
from .io_schemas import RegimeState

__all__ = [
    "RegimeState",
    "RegimeDetector",
    "HMMDetector",
    "BOCPDDetector",
    "VolClusterDetector",
]
