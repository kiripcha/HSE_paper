"""schemas for execution (OMS/EMS) layer."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

OrderType = Literal["market", "limit", "do_nothing"]
OrderStatus = Literal[
    "NEW", "PENDING", "ACK", "PARTIAL", "FILLED", "CANCELED", "REJECTED"
]
Side = Literal["buy", "sell"]


class ChildOrder(BaseModel):
    model_config = ConfigDict(frozen=True)

    client_order_id: str
    exchange: str
    symbol: str
    side: Side
    order_type: OrderType
    quantity: float
    price: float | None = None
    ttl_ns: int | None = None


class OrderEvent(BaseModel):
    model_config = ConfigDict(frozen=True)

    ts_ns: int
    client_order_id: str
    event: Literal["ack", "partial_fill", "fill", "cancel", "reject"]
    fill_quantity: float | None = None
    fill_price: float | None = None
    metadata: dict[str, float] = Field(default_factory=dict)


class OrderState(BaseModel):
    model_config = ConfigDict(frozen=False)

    client_order_id: str
    symbol: str
    side: Side
    requested_quantity: float
    status: OrderStatus = "NEW"
    filled_quantity: float = 0.0
    avg_fill_price: float | None = None
    last_update_ns: int = 0


class Fill(BaseModel):
    model_config = ConfigDict(frozen=True)

    ts_ns: int
    symbol: str
    side: Side
    quantity: float
    price: float
    fee: float = 0.0
    client_order_id: str = ""


class ExecutionState(BaseModel):
    """snapshot fed to an ExecutionAgent."""

    model_config = ConfigDict(frozen=True)

    inventory_remaining: float
    time_remaining_ns: int
    mid_price: float
    spread: float
    recent_volume: float = 0.0


class ExecutionAction(BaseModel):
    model_config = ConfigDict(frozen=True)

    order_type: OrderType
    side: Side
    quantity: float
    price_offset_bps: float | None = None
