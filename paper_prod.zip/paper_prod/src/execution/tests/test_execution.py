"""tests for OMS state machine and execution agents."""

from __future__ import annotations

import pytest

from src.execution import (
    OMS,
    AlmgrenChrissAgent,
    ChildOrder,
    ExecutionState,
    MarketOrderAgent,
    OrderEvent,
    TWAPAgent,
)


def _order(coid: str = "1", qty: float = 1.0) -> ChildOrder:
    return ChildOrder(
        client_order_id=coid,
        exchange="binance",
        symbol="BTCUSDT",
        side="buy",
        order_type="limit",
        quantity=qty,
        price=50_000.0,
    )


def test_oms_basic_lifecycle() -> None:
    oms = OMS()
    o = _order(qty=2.0)
    st = oms.place(o)
    assert st.status == "PENDING"
    # partial fill
    oms.on_event(OrderEvent(
        ts_ns=1, client_order_id="1", event="partial_fill",
        fill_quantity=0.5, fill_price=50_000.0,
    ))
    assert oms.get("1").status == "PARTIAL"
    assert oms.get("1").filled_quantity == 0.5
    # complete fill
    oms.on_event(OrderEvent(
        ts_ns=2, client_order_id="1", event="partial_fill",
        fill_quantity=1.5, fill_price=50_100.0,
    ))
    assert oms.get("1").status == "FILLED"
    # avg price weighted
    expected_avg = (50_000.0 * 0.5 + 50_100.0 * 1.5) / 2.0
    assert oms.get("1").avg_fill_price == pytest.approx(expected_avg)


def test_oms_idempotent_place() -> None:
    oms = OMS()
    s1 = oms.place(_order())
    s2 = oms.place(_order())  # same coid
    assert s1 is s2
    assert len(oms.open_orders()) == 1


def test_oms_cancel() -> None:
    oms = OMS()
    oms.place(_order())
    oms.on_event(OrderEvent(ts_ns=1, client_order_id="1", event="cancel"))
    assert oms.get("1").status == "CANCELED"
    assert oms.open_orders() == []


def test_oms_reject() -> None:
    oms = OMS()
    oms.place(_order())
    oms.on_event(OrderEvent(ts_ns=1, client_order_id="1", event="reject"))
    assert oms.get("1").status == "REJECTED"


def test_market_agent_returns_market_action() -> None:
    agent = MarketOrderAgent()
    state = ExecutionState(
        inventory_remaining=1.5, time_remaining_ns=1_000_000_000,
        mid_price=50_000.0, spread=1.0,
    )
    action = agent.act(state)
    assert action.order_type == "market"
    assert action.side == "sell"
    assert action.quantity == 1.5


def test_twap_splits_equally() -> None:
    agent = TWAPAgent(total_slices=5)
    state = ExecutionState(
        inventory_remaining=10.0, time_remaining_ns=1_000_000_000,
        mid_price=50_000.0, spread=1.0,
    )
    action = agent.act(state)
    assert action.quantity == pytest.approx(2.0)


def test_almgren_chriss_smoke() -> None:
    agent = AlmgrenChrissAgent(eta=1e-3, sigma=0.01, risk_aversion=1e-5)
    state = ExecutionState(
        inventory_remaining=10.0, time_remaining_ns=10 * 60 * 1_000_000_000,
        mid_price=50_000.0, spread=1.0,
    )
    action = agent.act(state)
    assert action.quantity > 0
    assert action.side == "sell"
