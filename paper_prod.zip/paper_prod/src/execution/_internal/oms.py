"""order Management System — state machine for orders."""

from __future__ import annotations

import structlog

from ..io_schemas import ChildOrder, OrderEvent, OrderState

log = structlog.get_logger(__name__)


class OMS:
    """in-memory OMS. Tracks order states and applies events."""

    def __init__(self) -> None:
        self._orders: dict[str, OrderState] = {}

    def place(self, order: ChildOrder) -> OrderState:
        if order.client_order_id in self._orders:
            return self._orders[order.client_order_id]
        state = OrderState(
            client_order_id=order.client_order_id,
            symbol=order.symbol,
            side=order.side,
            requested_quantity=order.quantity,
            status="PENDING",
        )
        self._orders[order.client_order_id] = state
        return state

    def on_event(self, event: OrderEvent) -> OrderState | None:
        st = self._orders.get(event.client_order_id)
        if st is None:
            log.warning("oms_unknown_order", coid=event.client_order_id)
            return None
        if event.event == "ack":
            st.status = "ACK"
        elif event.event == "partial_fill":
            fq = event.fill_quantity or 0.0
            new_filled = st.filled_quantity + fq
            if event.fill_price is not None:
                # weighted-avg fill price
                if st.avg_fill_price is None:
                    st.avg_fill_price = event.fill_price
                else:
                    total_qty = st.filled_quantity + fq
                    st.avg_fill_price = (
                        st.avg_fill_price * st.filled_quantity + event.fill_price * fq
                    ) / total_qty if total_qty > 0 else event.fill_price
            st.filled_quantity = new_filled
            st.status = "PARTIAL" if new_filled < st.requested_quantity else "FILLED"
        elif event.event == "fill":
            st.filled_quantity = event.fill_quantity or st.requested_quantity
            if event.fill_price is not None:
                st.avg_fill_price = event.fill_price
            st.status = "FILLED"
        elif event.event == "cancel":
            st.status = "CANCELED"
        elif event.event == "reject":
            st.status = "REJECTED"
        st.last_update_ns = event.ts_ns
        return st

    def get(self, client_order_id: str) -> OrderState | None:
        return self._orders.get(client_order_id)

    def open_orders(self) -> list[OrderState]:
        return [
            o for o in self._orders.values()
            if o.status in ("NEW", "PENDING", "ACK", "PARTIAL")
        ]

    def clear(self) -> None:
        self._orders.clear()
