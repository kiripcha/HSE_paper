"""execution agents: baselines (market, TWAP, Almgren-Chriss) + DRL placeholder."""

from __future__ import annotations

import math

import numpy as np

from ..io_schemas import ExecutionAction, ExecutionState


class MarketOrderAgent:
    """dumb baseline: dump remaining inventory as a market order."""

    name = "market"

    def act(self, state: ExecutionState) -> ExecutionAction:
        side = "sell" if state.inventory_remaining > 0 else "buy"
        return ExecutionAction(
            order_type="market",
            side=side,
            quantity=abs(state.inventory_remaining),
        )


class TWAPAgent:
    """equal slices across remaining steps."""

    name = "twap"

    def __init__(self, total_slices: int = 10) -> None:
        self.total_slices = total_slices

    def act(self, state: ExecutionState) -> ExecutionAction:
        if state.time_remaining_ns <= 0:
            qty = abs(state.inventory_remaining)
            side = "sell" if state.inventory_remaining > 0 else "buy"
            return ExecutionAction(order_type="market", side=side, quantity=qty)
        # split remaining inventory into equal pieces by remaining time slices
        # approximate: assume time_remaining_ns covers N steps; we don't know N here,
        # so use a simple ratio with total_slices as expected total.
        qty = abs(state.inventory_remaining) / max(1, self.total_slices)
        side = "sell" if state.inventory_remaining > 0 else "buy"
        return ExecutionAction(order_type="limit", side=side, quantity=qty, price_offset_bps=0.0)


class AlmgrenChrissAgent:
    """closed-form Almgren-Chriss optimal execution (linear-impact, mean-vol risk)."""

    name = "almgren_chriss"

    def __init__(self, eta: float = 1e-4, gamma: float = 0.0, sigma: float = 0.01,
                 risk_aversion: float = 1e-6, total_steps: int = 10) -> None:
        self.eta = eta              # temporary impact coefficient
        self.gamma = gamma          # permanent impact coefficient
        self.sigma = sigma
        self.risk_aversion = risk_aversion
        self.total_steps = total_steps

    def _kappa(self) -> float:
        # AC discrete: kappa = arccosh(1 + sigma^2 * lambda / (2*eta)) per step
        num = self.sigma**2 * self.risk_aversion
        denom = 2 * max(self.eta, 1e-12)
        return math.acosh(1 + num / denom) if num > 0 else 0.0

    def act(self, state: ExecutionState) -> ExecutionAction:
        steps_left = max(1, int(state.time_remaining_ns / max(1, state.time_remaining_ns // self.total_steps)))
        # approximate: split inventory by sinh/sinh schedule
        kappa = self._kappa()
        if kappa == 0:
            qty = abs(state.inventory_remaining) / steps_left
        else:
            qty = abs(state.inventory_remaining) * math.sinh(kappa) / math.sinh(kappa * steps_left)
        side = "sell" if state.inventory_remaining > 0 else "buy"
        return ExecutionAction(order_type="limit", side=side, quantity=qty, price_offset_bps=0.0)


class RandomAgent:
    """stochastic baseline for sanity checks."""

    name = "random"

    def __init__(self, seed: int = 0) -> None:
        self.rng = np.random.default_rng(seed)

    def act(self, state: ExecutionState) -> ExecutionAction:
        side = "sell" if state.inventory_remaining > 0 else "buy"
        qty = abs(state.inventory_remaining) * self.rng.random()
        return ExecutionAction(order_type="limit", side=side, quantity=qty, price_offset_bps=0.0)
