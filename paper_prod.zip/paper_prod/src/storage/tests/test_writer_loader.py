"""roundtrip and partitioning tests for the storage layer."""

from __future__ import annotations

from pathlib import Path

import pytest

from src.market_data import random_walk_deltas, synthetic_snapshot
from src.storage import (
    ParquetHistoricalLoader,
    ParquetTickWriter,
    StorageConfig,
    event_to_row,
    row_to_event,
)


@pytest.fixture
def tmp_storage(tmp_path: Path) -> StorageConfig:
    return StorageConfig(
        root_path=tmp_path / "ticks",
        compression="snappy",
        flush_interval_sec=999,
        flush_max_events=10**9,  # never auto-flush
    )


def test_event_row_round_trip() -> None:
    ev = synthetic_snapshot()
    row = event_to_row(ev)
    back = row_to_event(row)
    assert back == ev


@pytest.mark.asyncio
async def test_writer_persists_events_partitioned(tmp_storage: StorageConfig) -> None:
    writer = ParquetTickWriter(tmp_storage)
    events = list(random_walk_deltas(seed=1, n=200))
    for ev in events:
        writer.write(ev)
    await writer.close()

    # walk created partitions
    paths = list(tmp_storage.root_path.rglob("*.parquet"))
    assert len(paths) >= 1
    # ensure expected partition keys
    assert any("exchange=binance" in str(p) for p in paths)
    assert any("symbol=BTCUSDT" in str(p) for p in paths)


@pytest.mark.asyncio
async def test_loader_returns_what_writer_wrote(tmp_storage: StorageConfig) -> None:
    writer = ParquetTickWriter(tmp_storage)
    events = list(random_walk_deltas(seed=42, n=500))
    for ev in events:
        writer.write(ev)
    await writer.close()

    loader = ParquetHistoricalLoader(tmp_storage)
    from_ns = min(e.ts_exchange_ns for e in events)
    to_ns = max(e.ts_exchange_ns for e in events)
    loaded = list(loader.load("binance", "BTCUSDT", from_ns, to_ns))

    assert len(loaded) == len(events)
    # ordering inside partitions is by ts; ids should match modulo ordering
    loaded_ids = sorted([e.seq for e in loaded])
    original_ids = sorted([e.seq for e in events])
    assert loaded_ids == original_ids


@pytest.mark.asyncio
async def test_loader_filters_by_time_range(tmp_storage: StorageConfig) -> None:
    writer = ParquetTickWriter(tmp_storage)
    events = list(random_walk_deltas(seed=3, n=200))
    for ev in events:
        writer.write(ev)
    await writer.close()

    loader = ParquetHistoricalLoader(tmp_storage)
    # take only the middle third
    sorted_ts = sorted(e.ts_exchange_ns for e in events)
    lo = sorted_ts[len(sorted_ts) // 3]
    hi = sorted_ts[2 * len(sorted_ts) // 3]
    loaded = list(loader.load("binance", "BTCUSDT", lo, hi))
    assert all(lo <= e.ts_exchange_ns <= hi for e in loaded)
    assert 0 < len(loaded) < len(events)


@pytest.mark.asyncio
async def test_loader_filters_by_event_type(tmp_storage: StorageConfig) -> None:
    writer = ParquetTickWriter(tmp_storage)
    events = list(random_walk_deltas(seed=11, n=500))
    for ev in events:
        writer.write(ev)
    await writer.close()

    loader = ParquetHistoricalLoader(tmp_storage)
    lo = min(e.ts_exchange_ns for e in events)
    hi = max(e.ts_exchange_ns for e in events)
    only_trades = list(loader.load("binance", "BTCUSDT", lo, hi, event_types=["trade"]))
    assert all(e.event_type == "trade" for e in only_trades)
    expected_trades = sum(1 for e in events if e.event_type == "trade")
    assert len(only_trades) == expected_trades
