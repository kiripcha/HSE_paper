"""ReplayEngine — replay correctness and ordering tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from src.market_data import (
    SortedBook,
    random_walk_deltas,
)
from src.market_data.interface import ExchangeConnector
from src.storage import (
    ParquetTickWriter,
    ReplayConfig,
    ReplayEngine,
    StorageConfig,
)


@pytest.fixture
def tmp_storage(tmp_path: Path) -> StorageConfig:
    return StorageConfig(
        root_path=tmp_path / "ticks",
        compression="snappy",
        flush_interval_sec=999,
        flush_max_events=10**9,
    )


@pytest.mark.asyncio
async def test_replay_implements_exchange_connector_protocol(
    tmp_storage: StorageConfig,
) -> None:
    """the replay engine must be substitutable for a live connector."""
    engine = ReplayEngine(
        storage=tmp_storage,
        replay=ReplayConfig(),
        from_ns=0,
        to_ns=1,
        sources=[("binance", "BTCUSDT")],
    )
    assert isinstance(engine, ExchangeConnector)


@pytest.mark.asyncio
async def test_replay_yields_events_in_ts_order(tmp_storage: StorageConfig) -> None:
    writer = ParquetTickWriter(tmp_storage)
    events = list(random_walk_deltas(seed=1, n=300))
    for ev in events:
        writer.write(ev)
    await writer.close()

    engine = ReplayEngine(
        storage=tmp_storage,
        replay=ReplayConfig(speed="max"),
        from_ns=min(e.ts_exchange_ns for e in events),
        to_ns=max(e.ts_exchange_ns for e in events),
        sources=[("binance", "BTCUSDT")],
    )
    await engine.connect()
    seen: list[int] = []
    async for ev in engine.stream():
        seen.append(ev.ts_exchange_ns)
    await engine.close()
    assert seen == sorted(seen)
    assert len(seen) == len(events)


@pytest.mark.asyncio
async def test_replay_reconstructs_same_book_as_live(
    tmp_storage: StorageConfig,
) -> None:
    """apply same events live vs through replay; final books must match."""
    events = list(random_walk_deltas(seed=7, n=500))

    # live application
    live_book = SortedBook("BTCUSDT")
    for ev in events:
        live_book.apply(ev)
    live_snap = live_book.snapshot(50)

    # persist + replay
    writer = ParquetTickWriter(tmp_storage)
    for ev in events:
        writer.write(ev)
    await writer.close()

    engine = ReplayEngine(
        storage=tmp_storage,
        replay=ReplayConfig(speed="max"),
        from_ns=min(e.ts_exchange_ns for e in events),
        to_ns=max(e.ts_exchange_ns for e in events),
        sources=[("binance", "BTCUSDT")],
    )
    await engine.connect()
    replay_book = SortedBook("BTCUSDT")
    async for ev in engine.stream():
        replay_book.apply(ev)
    await engine.close()
    replay_snap = replay_book.snapshot(50)

    live_bids = [(round(b.price, 4), round(b.quantity, 6)) for b in live_snap.bids]
    replay_bids = [(round(b.price, 4), round(b.quantity, 6)) for b in replay_snap.bids]
    assert live_bids == replay_bids
    live_asks = [(round(a.price, 4), round(a.quantity, 6)) for a in live_snap.asks]
    replay_asks = [(round(a.price, 4), round(a.quantity, 6)) for a in replay_snap.asks]
    assert live_asks == replay_asks


@pytest.mark.asyncio
async def test_replay_deterministic_tie_break(tmp_storage: StorageConfig) -> None:
    """two events at identical ts -> deterministic order across runs."""
    # hand-craft two events with the same timestamp
    from src.market_data.io_schemas import MarketEvent, Trade

    ev_a = MarketEvent(
        exchange="binance",
        symbol="BTCUSDT",
        ts_exchange_ns=1000,
        ts_local_ns=1000,
        event_type="trade",
        seq=1,
        payload=Trade(price=100.0, quantity=1.0, side="buy", trade_id=1),
    )
    ev_b = MarketEvent(
        exchange="okx",
        symbol="BTCUSDT",
        ts_exchange_ns=1000,
        ts_local_ns=1000,
        event_type="trade",
        seq=1,
        payload=Trade(price=100.0, quantity=1.0, side="buy", trade_id=1),
    )
    writer = ParquetTickWriter(tmp_storage)
    writer.write(ev_a)
    writer.write(ev_b)
    await writer.close()

    # two runs — order must be the same and follow exchange_priority binance < okx
    orderings = []
    for _ in range(2):
        engine = ReplayEngine(
            storage=tmp_storage,
            replay=ReplayConfig(speed="max"),
            from_ns=0,
            to_ns=10_000,
            sources=[("binance", "BTCUSDT"), ("okx", "BTCUSDT")],
        )
        await engine.connect()
        seen = []
        async for ev in engine.stream():
            seen.append(ev.exchange)
        await engine.close()
        orderings.append(seen)
    assert orderings[0] == orderings[1]
    assert orderings[0] == ["binance", "okx"]
