"""batched Parquet writer for MarketEvent.
"""

from __future__ import annotations

import asyncio
import datetime as dt
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq
import structlog

from src.market_data.io_schemas import MarketEvent

from ..config import StorageConfig
from ..io_schemas import event_to_row

log = structlog.get_logger(__name__)


_ARROW_SCHEMA = pa.schema(
    [
        ("exchange", pa.string()),
        ("symbol", pa.string()),
        ("ts_exchange_ns", pa.int64()),
        ("ts_local_ns", pa.int64()),
        ("event_type", pa.string()),
        ("seq", pa.int64()),
        ("payload_json", pa.string()),
    ]
)


def _partition_dir(
    root: Path, exchange: str, symbol: str, event_type: str, ts_ns: int
) -> Path:
    d = dt.datetime.fromtimestamp(ts_ns / 1e9, tz=dt.UTC)
    return (
        root
        / f"exchange={exchange}"
        / f"symbol={symbol}"
        / f"event_type={event_type}"
        / f"year={d.year:04d}"
        / f"month={d.month:02d}"
        / f"day={d.day:02d}"
    )


class ParquetTickWriter:
    """buffered writer that flushes to date-partitioned Parquet files."""

    def __init__(self, config: StorageConfig) -> None:
        self.config = config
        self._buffers: dict[Path, list[dict]] = {}
        self._last_flush: float = asyncio.get_event_loop().time() if asyncio._get_running_loop() else 0.0
        self._total_events = 0

    def write(self, event: MarketEvent) -> None:
        partition = _partition_dir(
            self.config.root_path,
            event.exchange,
            event.symbol,
            event.event_type,
            event.ts_exchange_ns,
        )
        self._buffers.setdefault(partition, []).append(event_to_row(event))
        self._total_events += 1
        if self._total_events >= self.config.flush_max_events:
            self._flush_sync()

    async def flush(self) -> None:
        self._flush_sync()

    async def close(self) -> None:
        self._flush_sync()

    def _flush_sync(self) -> None:
        if not self._buffers:
            return
        for partition, rows in self._buffers.items():
            partition.mkdir(parents=True, exist_ok=True)
            table = pa.Table.from_pylist(rows, schema=_ARROW_SCHEMA)
            # sort within file by ts_exchange_ns ascending
            table = table.sort_by([("ts_exchange_ns", "ascending")])
            ts_min = int(table.column("ts_exchange_ns")[0].as_py())
            ts_max = int(table.column("ts_exchange_ns")[-1].as_py())
            file_name = f"part-{ts_min:020d}-{ts_max:020d}.parquet"
            out = partition / file_name
            pq.write_table(
                table,
                out,
                compression=(
                    None if self.config.compression == "none" else self.config.compression
                ),
                row_group_size=max(
                    1, (self.config.row_group_size_mb * 1024 * 1024) // 256
                ),
            )
            log.info("flush_partition", path=str(out), rows=table.num_rows)
        self._buffers.clear()
        self._total_events = 0
