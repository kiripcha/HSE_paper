"""ReplayEngine — drop-in replacement for a live ExchangeConnector.
"""

from __future__ import annotations

import asyncio
import heapq
from collections.abc import AsyncIterator, Iterator

import structlog

from src.market_data.io_schemas import MarketEvent

from ..config import ReplayConfig, StorageConfig
from .loader import ParquetHistoricalLoader

log = structlog.get_logger(__name__)


def _tie_key(
    ev: MarketEvent,
    exchange_priority: dict[str, int],
    event_type_priority: dict[str, int],
) -> tuple[int, int, int, str, int]:
    """strict total order on events used as the heap key."""
    return (
        ev.ts_exchange_ns,
        exchange_priority.get(ev.exchange, 9999),
        event_type_priority.get(ev.event_type, 9999),
        ev.symbol,
        ev.seq if ev.seq is not None else 0,
    )


class ReplayEngine:
    """replays historical events with a stable ordering and configurable speed."""

    exchange = "replay"

    def __init__(
        self,
        storage: StorageConfig,
        replay: ReplayConfig,
        from_ns: int,
        to_ns: int,
        sources: list[tuple[str, str]],  # [(exchange, symbol)]
        event_types: list[str] | None = None,
    ) -> None:
        self.storage = storage
        self.replay = replay
        self.from_ns = from_ns
        self.to_ns = to_ns
        self.sources = sources
        self.event_types = event_types
        self._loader = ParquetHistoricalLoader(storage)
        self._exchange_prio = {e: i for i, e in enumerate(replay.exchange_priority)}
        self._event_type_prio = {t: i for i, t in enumerate(replay.event_type_priority)}
        self._closed = False

    async def connect(self) -> None:
        # nothing to do; iterator is created lazily on stream()
        return None

    async def subscribe(self, symbols: list[str], channels: list[str]) -> None:
        # subscriptions are configured at construction time; this is a no-op
        return None

    async def close(self) -> None:
        self._closed = True

    def _iter_merged(self) -> Iterator[MarketEvent]:
        """heap-merge per-source iterators into a single ordered stream."""
        per_source: list[Iterator[MarketEvent]] = [
            self._loader.load(ex, sym, self.from_ns, self.to_ns, self.event_types)
            for ex, sym in self.sources
        ]
        heap: list[tuple[tuple[int, int, int, str, int], int, MarketEvent]] = []
        for idx, it in enumerate(per_source):
            try:
                ev = next(it)
            except StopIteration:
                continue
            heapq.heappush(
                heap, (_tie_key(ev, self._exchange_prio, self._event_type_prio), idx, ev)
            )
        while heap:
            _, idx, ev = heapq.heappop(heap)
            yield ev
            try:
                nxt = next(per_source[idx])
            except StopIteration:
                continue
            heapq.heappush(
                heap, (_tie_key(nxt, self._exchange_prio, self._event_type_prio), idx, nxt)
            )

    async def stream(self) -> AsyncIterator[MarketEvent]:  # type: ignore[override]
        merged = self._iter_merged()
        last_ts: int | None = None
        speed = self.replay.speed
        for ev in merged:
            if self._closed:
                return
            if speed != "max" and last_ts is not None:
                dt_ns = ev.ts_exchange_ns - last_ts
                if dt_ns > 0:
                    if speed == "realtime":
                        await asyncio.sleep(dt_ns / 1e9)
                    else:
                        await asyncio.sleep(dt_ns / 1e9 / float(speed))
            last_ts = ev.ts_exchange_ns
            yield ev
