"""historical loader: reads Parquet partitions lazily and yields MarketEvents."""

from __future__ import annotations

import heapq
from collections.abc import Iterator

import pyarrow.parquet as pq
import structlog

from src.market_data.io_schemas import MarketEvent

from ..config import StorageConfig
from ..io_schemas import row_to_event

log = structlog.get_logger(__name__)


def _iter_event_type(
    root, exchange: str, symbol: str, evt_type: str, from_ns: int, to_ns: int
) -> Iterator[MarketEvent]:
    base = root / f"exchange={exchange}" / f"symbol={symbol}" / f"event_type={evt_type}"
    if not base.exists():
        return
    for path in sorted(base.rglob("*.parquet")):
        rng = _parse_range(path.name)
        if rng is None:
            continue
        ts_min, ts_max = rng
        if ts_max < from_ns or ts_min > to_ns:
            continue
        # parquetFile.read() avoids dataset-level Hive partition inference.
        tbl = pq.ParquetFile(path).read()
        for row in tbl.to_pylist():
            if row["ts_exchange_ns"] < from_ns or row["ts_exchange_ns"] > to_ns:
                continue
            yield row_to_event(row)


class ParquetHistoricalLoader:
    """lazy iterator over historical events."""

    def __init__(self, config: StorageConfig) -> None:
        self.config = config

    def load(
        self,
        exchange: str,
        symbol: str,
        from_ns: int,
        to_ns: int,
        event_types: list[str] | None = None,
    ) -> Iterator[MarketEvent]:
        types = event_types or ["book_snapshot", "book_delta", "trade", "bbo"]
        per_type: list[Iterator[MarketEvent]] = [
            _iter_event_type(self.config.root_path, exchange, symbol, t, from_ns, to_ns)
            for t in types
        ]
        heap: list[tuple[int, int, MarketEvent]] = []
        for idx, it in enumerate(per_type):
            try:
                ev = next(it)
            except StopIteration:
                continue
            heapq.heappush(heap, (ev.ts_exchange_ns, idx, ev))
        while heap:
            _, idx, ev = heapq.heappop(heap)
            yield ev
            try:
                nxt = next(per_type[idx])
            except StopIteration:
                continue
            heapq.heappush(heap, (nxt.ts_exchange_ns, idx, nxt))


def _parse_range(name: str) -> tuple[int, int] | None:
    # "part-{ts_min}-{ts_max}.parquet"
    if not name.startswith("part-") or not name.endswith(".parquet"):
        return None
    parts = name[len("part-"): -len(".parquet")].split("-")
    if len(parts) != 2:
        return None
    try:
        return int(parts[0]), int(parts[1])
    except ValueError:
        return None
