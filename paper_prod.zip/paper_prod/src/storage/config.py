"""pydantic configs for the storage module."""

from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

CompressionCodec = Literal["snappy", "zstd", "gzip", "lz4", "none"]
ReplaySpeed = Literal["max", "realtime"] | float


class StorageConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    root_path: Path = Field(default=Path("./data/ticks"))
    compression: CompressionCodec = "zstd"
    row_group_size_mb: int = 64
    max_file_size_mb: int = 256
    # flush triggers — whichever fires first.
    flush_interval_sec: float = 60.0
    flush_max_events: int = 100_000


class ReplayConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    speed: ReplaySpeed = "max"
    snapshot_resync_on_start: bool = True
    # order in which ties are broken: (exchange_priority, event_type_priority).
    exchange_priority: tuple[str, ...] = ("binance", "okx")
    event_type_priority: tuple[str, ...] = (
        "book_snapshot",
        "book_delta",
        "trade",
        "bbo",
    )
