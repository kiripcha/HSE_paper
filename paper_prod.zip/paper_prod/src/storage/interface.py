"""public protocols for storage layer."""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator
from typing import Protocol, runtime_checkable

from src.market_data.io_schemas import MarketEvent


@runtime_checkable
class TickWriter(Protocol):
    def write(self, event: MarketEvent) -> None: ...
    async def flush(self) -> None: ...
    async def close(self) -> None: ...


@runtime_checkable
class HistoricalLoader(Protocol):
    def load(
        self,
        exchange: str,
        symbol: str,
        from_ns: int,
        to_ns: int,
        event_types: list[str] | None = None,
    ) -> Iterator[MarketEvent]: ...


@runtime_checkable
class ReplayEngineProtocol(Protocol):
    """drop-in replacement for ExchangeConnector (module 01)."""

    exchange: str

    async def connect(self) -> None: ...
    async def subscribe(self, symbols: list[str], channels: list[str]) -> None: ...
    def stream(self) -> AsyncIterator[MarketEvent]: ...
    async def close(self) -> None: ...
