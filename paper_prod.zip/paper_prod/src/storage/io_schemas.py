"""schemas used by the storage layer. Mostly re-exports + serialization helpers.
"""

from __future__ import annotations

from typing import Any

from src.market_data.io_schemas import (
    BBO,
    BookDelta,
    BookLevel,
    BookSnapshot,
    MarketEvent,
    Trade,
)


# column order is the on-disk schema — DO NOT REORDER without a migration.
TICK_COLUMNS: tuple[str, ...] = (
    "exchange",
    "symbol",
    "ts_exchange_ns",
    "ts_local_ns",
    "event_type",
    "seq",
    # serialized payload as a tagged dict — we keep it simple with JSON-encoded payload
    "payload_json",
)


def event_to_row(ev: MarketEvent) -> dict[str, Any]:
    """flatten a MarketEvent into a row suitable for columnar storage."""
    return {
        "exchange": ev.exchange,
        "symbol": ev.symbol,
        "ts_exchange_ns": ev.ts_exchange_ns,
        "ts_local_ns": ev.ts_local_ns,
        "event_type": ev.event_type,
        "seq": ev.seq,
        "payload_json": ev.payload.model_dump_json(),
    }


def row_to_event(row: dict[str, Any]) -> MarketEvent:
    """inverse of event_to_row."""
    payload_json: str = row["payload_json"]
    event_type: str = row["event_type"]
    cls_map = {
        "book_snapshot": BookSnapshot,
        "book_delta": BookDelta,
        "trade": Trade,
        "bbo": BBO,
    }
    payload = cls_map[event_type].model_validate_json(payload_json)
    return MarketEvent(
        exchange=row["exchange"],
        symbol=row["symbol"],
        ts_exchange_ns=int(row["ts_exchange_ns"]),
        ts_local_ns=int(row["ts_local_ns"]),
        event_type=event_type,  # type: ignore[arg-type]
        seq=None if row.get("seq") is None else int(row["seq"]),
        payload=payload,
    )


__all__ = [
    "BBO",
    "BookDelta",
    "BookLevel",
    "BookSnapshot",
    "MarketEvent",
    "TICK_COLUMNS",
    "Trade",
    "event_to_row",
    "row_to_event",
]
