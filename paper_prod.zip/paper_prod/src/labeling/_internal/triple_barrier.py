"""triple-barrier labeling (Lopez de Prado, AFML Ch.3).
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class TripleBarrierConfig:
    pt: float = 2.0          # take-profit barrier multiplier of vol
    sl: float = 1.0          # stop-loss barrier multiplier of vol
    max_holding_steps: int = 60
    vol_window: int = 100    # rolling vol window (returns)
    vol_floor: float = 1e-6


def ewma_vol(returns: np.ndarray, span: int) -> np.ndarray:
    """exponential-weighted std of returns with given span."""
    alpha = 2.0 / (span + 1.0)
    var = np.zeros_like(returns, dtype=np.float64)
    mean = 0.0
    s2 = 0.0
    for i, r in enumerate(returns):
        mean = alpha * r + (1 - alpha) * mean
        s2 = alpha * (r - mean) ** 2 + (1 - alpha) * s2
        var[i] = s2
    return np.sqrt(var)


def triple_barrier_labels(
    prices: np.ndarray,
    ts_ns: np.ndarray,
    config: TripleBarrierConfig,
    event_indices: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """compute triple-barrier labels."""
    n = len(prices)
    if event_indices is None:
        event_indices = np.arange(n - config.max_holding_steps)
    rets = np.zeros(n)
    rets[1:] = np.log(prices[1:] / prices[:-1])
    vol = np.maximum(ewma_vol(rets, config.vol_window), config.vol_floor)

    labels = np.zeros(len(event_indices), dtype=np.int8)
    t0_arr = np.zeros(len(event_indices), dtype=np.int64)
    t1_arr = np.zeros(len(event_indices), dtype=np.int64)
    sample_rets = np.zeros(len(event_indices), dtype=np.float64)

    for k, i in enumerate(event_indices):
        p0 = prices[i]
        v = vol[i]
        upper = p0 * (1.0 + config.pt * v)
        lower = p0 * (1.0 - config.sl * v)
        end = min(i + config.max_holding_steps, n - 1)
        label = 0
        for j in range(i + 1, end + 1):
            if prices[j] >= upper:
                label = +1
                break
            if prices[j] <= lower:
                label = -1
                break
        t0_arr[k] = ts_ns[i]
        t1_arr[k] = ts_ns[j]
        labels[k] = label
        sample_rets[k] = np.log(prices[j] / p0)

    return labels, t0_arr, t1_arr, sample_rets


def sample_uniqueness_weights(t0: np.ndarray, t1: np.ndarray) -> np.ndarray:
    """lopez de Prado AFML Ch.4: weight = mean over event lifetime of 1/c_t,
    where c_t is the number of concurrent labels active at time t."""
    n = len(t0)
    if n == 0:
        return np.zeros(0)
    # collect all unique event boundaries
    events = sorted(set(t0.tolist()) | set(t1.tolist()))
    # concurrent count at each segment (events[k], events[k+1])
    # iterate samples and contribute to segments they cover
    weights = np.zeros(n)
    # build O(n) sweep
    order = np.argsort(t0)
    for k_idx, k in enumerate(order):  # noqa: PLR1704
        del k_idx
        a, b = t0[k], t1[k]
        # concurrent labels at time of k = number of other (t0_j, t1_j) overlapping [a, b]
        # use vectorized count for simplicity (O(n^2) worst case, fine for sizes < 100k)
        overlap = ((t0 <= b) & (t1 >= a)).sum()
        # average of 1 / concurrent across event lifetime
        weights[k] = 1.0 / float(max(1, overlap))
    s = weights.sum()
    if s > 0:
        weights = weights * n / s  # normalize so mean = 1
    return weights
