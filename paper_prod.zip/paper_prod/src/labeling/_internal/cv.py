"""purged k-fold and Combinatorial Purged CV (Lopez de Prado).
"""

from __future__ import annotations

from collections.abc import Iterator
from itertools import combinations

import numpy as np

from ..io_schemas import LabeledDataset


def _purge_train_against_test(
    t0: np.ndarray, t1: np.ndarray, test_idx: np.ndarray, embargo_ns: int
) -> np.ndarray:
    """return boolean mask of train candidates that should be PURGED (excluded)."""
    if test_idx.size == 0:
        return np.zeros_like(t0, dtype=bool)
    test_t0_min = t0[test_idx].min() - embargo_ns
    test_t1_max = t1[test_idx].max() + embargo_ns
    overlap = (t1 >= test_t0_min) & (t0 <= test_t1_max)
    return overlap


class PurgedKFold:
    """k-fold CV with purging and embargo (AFML Ch.7)."""

    def __init__(self, n_splits: int = 5, embargo_pct: float = 0.01) -> None:
        self.n_splits = n_splits
        self.embargo_pct = embargo_pct

    def split(self, dataset: LabeledDataset) -> Iterator[tuple[np.ndarray, np.ndarray]]:
        n = dataset.n_samples
        # order by event start time to make folds contiguous in time
        order = np.argsort(dataset.t0)
        fold_size = n // self.n_splits
        embargo_ns = int(
            (dataset.t1.max() - dataset.t0.min()) * self.embargo_pct
        )
        for k in range(self.n_splits):
            start = k * fold_size
            end = (k + 1) * fold_size if k < self.n_splits - 1 else n
            test_positions = order[start:end]
            train_mask = np.ones(n, dtype=bool)
            train_mask[test_positions] = False
            # purge
            purged = _purge_train_against_test(
                dataset.t0, dataset.t1, test_positions, embargo_ns
            )
            train_mask &= ~purged
            train_idx = np.where(train_mask)[0]
            yield train_idx, test_positions


class CombinatorialPurgedCV:
    """CPCV: choose n_test_splits of n_splits groups to be test in each path."""

    def __init__(
        self, n_splits: int = 6, n_test_splits: int = 2, embargo_pct: float = 0.01
    ) -> None:
        self.n_splits = n_splits
        self.n_test_splits = n_test_splits
        self.embargo_pct = embargo_pct

    def split(self, dataset: LabeledDataset) -> Iterator[tuple[np.ndarray, np.ndarray]]:
        n = dataset.n_samples
        order = np.argsort(dataset.t0)
        group_size = n // self.n_splits
        groups: list[np.ndarray] = []
        for k in range(self.n_splits):
            start = k * group_size
            end = (k + 1) * group_size if k < self.n_splits - 1 else n
            groups.append(order[start:end])
        embargo_ns = int(
            (dataset.t1.max() - dataset.t0.min()) * self.embargo_pct
        )
        for combo in combinations(range(self.n_splits), self.n_test_splits):
            test_idx = np.concatenate([groups[k] for k in combo])
            train_mask = np.ones(n, dtype=bool)
            train_mask[test_idx] = False
            purged = _purge_train_against_test(
                dataset.t0, dataset.t1, test_idx, embargo_ns
            )
            train_mask &= ~purged
            yield np.where(train_mask)[0], test_idx

    def n_paths(self) -> int:
        from math import comb

        return comb(self.n_splits, self.n_test_splits)
