"""statistically-honest performance metrics (Bailey-Lopez de Prado)."""

from __future__ import annotations

import numpy as np
from scipy import stats


def sharpe_ratio(returns: np.ndarray, periods_per_year: float = 252) -> float:
    """annualized Sharpe."""
    r = np.asarray(returns, dtype=np.float64)
    if r.size < 2:
        return 0.0
    mean = r.mean()
    sd = r.std(ddof=1)
    if sd == 0:
        return 0.0
    return float(mean / sd * np.sqrt(periods_per_year))


def probabilistic_sharpe(
    sharpe_obs: float,
    sharpe_benchmark: float,
    n: int,
    skew: float,
    kurt: float,
) -> float:
    """PSR — probability that a strategy's true Sharpe > benchmark, given finite n."""
    if n < 2:
        return 0.0
    denom = 1.0 - skew * sharpe_obs + (kurt / 4.0) * sharpe_obs**2
    if denom <= 0:
        # extreme skew/kurtosis vs SR combination — clamp to a safe value.
        return float(stats.norm.cdf(np.sign(sharpe_obs - sharpe_benchmark) * 10))
    z = (sharpe_obs - sharpe_benchmark) * np.sqrt(n - 1) / np.sqrt(denom)
    return float(stats.norm.cdf(z))


def deflated_sharpe(
    sharpe_obs: float,
    sharpe_std_estimate: float,
    n_trials: int,
    n_obs: int,
    skew: float,
    kurt: float,
) -> float:
    """DSR — PSR adjusted for multiple-testing (n_trials)."""
    # benchmark = E[max SR] under H0 with sharpe_std_estimate spread, n_trials tries
    gamma = np.euler_gamma
    z1 = stats.norm.ppf(1.0 - 1.0 / max(1, n_trials))
    z2 = stats.norm.ppf(1.0 - 1.0 / (max(1, n_trials) * np.e))
    sharpe_benchmark = sharpe_std_estimate * ((1.0 - gamma) * z1 + gamma * z2)
    return probabilistic_sharpe(sharpe_obs, sharpe_benchmark, n_obs, skew, kurt)


def sample_stats(returns: np.ndarray) -> tuple[float, float]:
    """return (skew, excess_kurt) of the sample."""
    r = np.asarray(returns, dtype=np.float64)
    if r.size < 4:
        return 0.0, 0.0
    return float(stats.skew(r)), float(stats.kurtosis(r))  # excess kurt by default
