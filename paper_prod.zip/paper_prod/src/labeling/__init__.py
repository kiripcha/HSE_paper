"""labeling — triple-barrier labels, purged CV, deflated Sharpe.
"""

from ._internal.cv import CombinatorialPurgedCV, PurgedKFold
from ._internal.metrics import (
    deflated_sharpe,
    probabilistic_sharpe,
    sample_stats,
    sharpe_ratio,
)
from ._internal.triple_barrier import (
    TripleBarrierConfig,
    ewma_vol,
    sample_uniqueness_weights,
    triple_barrier_labels,
)
from .io_schemas import LabeledDataset

__all__ = [
    "LabeledDataset",
    "TripleBarrierConfig",
    "triple_barrier_labels",
    "sample_uniqueness_weights",
    "ewma_vol",
    "PurgedKFold",
    "CombinatorialPurgedCV",
    "sharpe_ratio",
    "probabilistic_sharpe",
    "deflated_sharpe",
    "sample_stats",
]
