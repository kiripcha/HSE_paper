"""tests for triple-barrier, purged CV, and statistical metrics."""

from __future__ import annotations

import numpy as np
import pytest

from src.labeling import (
    CombinatorialPurgedCV,
    LabeledDataset,
    PurgedKFold,
    TripleBarrierConfig,
    deflated_sharpe,
    probabilistic_sharpe,
    sample_stats,
    sample_uniqueness_weights,
    sharpe_ratio,
    triple_barrier_labels,
)


def _trending_prices(n: int = 500, drift: float = 0.001, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    rets = rng.normal(drift, 0.01, n)
    return 100.0 * np.exp(np.cumsum(rets))


def _ts(n: int) -> np.ndarray:
    return np.arange(n, dtype=np.int64) * 60_000_000_000


def test_triple_barrier_uptrend_yields_more_plus_labels() -> None:
    prices = _trending_prices(500, drift=0.002)
    ts = _ts(len(prices))
    cfg = TripleBarrierConfig(pt=2.0, sl=1.0, max_holding_steps=30, vol_window=50)
    labels, t0, t1, rets = triple_barrier_labels(prices, ts, cfg)
    n_plus = (labels == 1).sum()
    n_minus = (labels == -1).sum()
    n_zero = (labels == 0).sum()
    assert n_plus + n_minus + n_zero == len(labels)
    assert n_plus > n_minus  # uptrend should hit upper barrier more


def test_triple_barrier_lifetimes_are_after_event_start() -> None:
    prices = _trending_prices(300)
    ts = _ts(len(prices))
    cfg = TripleBarrierConfig()
    _, t0, t1, _ = triple_barrier_labels(prices, ts, cfg)
    assert np.all(t1 >= t0)


def test_sample_uniqueness_weights_normalized() -> None:
    # synthetic non-overlapping events → all weights should be ~1
    t0 = np.array([0, 100, 200, 300, 400], dtype=np.int64)
    t1 = np.array([50, 150, 250, 350, 450], dtype=np.int64)
    w = sample_uniqueness_weights(t0, t1)
    assert w.shape == (5,)
    assert abs(w.mean() - 1.0) < 1e-9


def _make_dataset(n: int = 100, seed: int = 1) -> LabeledDataset:
    rng = np.random.default_rng(seed)
    t0 = np.cumsum(rng.integers(10, 30, size=n)).astype(np.int64)
    t1 = t0 + rng.integers(5, 15, size=n).astype(np.int64)
    X = rng.normal(size=(n, 4))
    y = rng.integers(-1, 2, size=n)
    return LabeledDataset(
        X=X,
        y=y,
        sample_weights=np.ones(n),
        t0=t0,
        t1=t1,
        feature_names=("a", "b", "c", "d"),
    )


def test_purged_kfold_no_train_test_overlap_in_time() -> None:
    ds = _make_dataset(200)
    cv = PurgedKFold(n_splits=5, embargo_pct=0.01)
    for train_idx, test_idx in cv.split(ds):
        assert len(np.intersect1d(train_idx, test_idx)) == 0
        # train labels should not overlap test window in time
        test_t0_min = ds.t0[test_idx].min()
        test_t1_max = ds.t1[test_idx].max()
        train_overlap = (
            (ds.t1[train_idx] >= test_t0_min) & (ds.t0[train_idx] <= test_t1_max)
        )
        assert not train_overlap.any()


def test_purged_kfold_covers_all_test_samples_exactly_once() -> None:
    ds = _make_dataset(200)
    cv = PurgedKFold(n_splits=5)
    test_collected: list[int] = []
    for _, test_idx in cv.split(ds):
        test_collected.extend(test_idx.tolist())
    test_collected.sort()
    assert test_collected == list(range(ds.n_samples))


def test_cpcv_produces_n_choose_k_paths() -> None:
    ds = _make_dataset(120)
    cv = CombinatorialPurgedCV(n_splits=6, n_test_splits=2)
    splits = list(cv.split(ds))
    assert len(splits) == cv.n_paths() == 15


def test_sharpe_ratio_positive_for_drifting_returns() -> None:
    rets = np.full(252, 0.001) + np.random.default_rng(0).normal(0, 0.0001, 252)
    assert sharpe_ratio(rets) > 5


def test_probabilistic_sharpe_high_for_strong_signal() -> None:
    rets = np.full(252, 0.001) + np.random.default_rng(0).normal(0, 0.005, 252)
    sr_per_period = rets.mean() / rets.std(ddof=1)
    skew, kurt = sample_stats(rets)
    psr = probabilistic_sharpe(
        sr_per_period, sharpe_benchmark=0.0, n=len(rets), skew=skew, kurt=kurt
    )
    assert psr > 0.95


def test_deflated_sharpe_punishes_multiple_testing() -> None:
    # modest signal: SR_per_period ≈ 0.1; multiple-testing should matter
    rets = np.full(252, 0.001) + np.random.default_rng(1).normal(0, 0.01, 252)
    sr_per_period = rets.mean() / rets.std(ddof=1)
    skew, kurt = sample_stats(rets)
    dsr_1 = deflated_sharpe(
        sr_per_period, sharpe_std_estimate=0.1, n_trials=1, n_obs=len(rets),
        skew=skew, kurt=kurt,
    )
    dsr_1000 = deflated_sharpe(
        sr_per_period, sharpe_std_estimate=0.1, n_trials=1000, n_obs=len(rets),
        skew=skew, kurt=kurt,
    )
    assert dsr_1 > dsr_1000


@pytest.mark.parametrize("seed", [0, 1, 7, 100, 999])
def test_no_leakage_on_random_walk(seed: int) -> None:
    """random walk has no alpha; OOS accuracy via PurgedKFold ~ chance."""
    rng = np.random.default_rng(seed)
    prices = 100.0 * np.exp(np.cumsum(rng.normal(0, 0.01, 1000)))
    ts = _ts(len(prices))
    cfg = TripleBarrierConfig(pt=2.0, sl=2.0, max_holding_steps=10, vol_window=30)
    labels, t0, t1, _ = triple_barrier_labels(prices, ts, cfg)
    # use random features (no real signal)
    X = rng.normal(size=(len(labels), 4))
    ds = LabeledDataset(
        X=X, y=labels, sample_weights=np.ones(len(labels)),
        t0=t0, t1=t1, feature_names=("a","b","c","d"),
    )
    cv = PurgedKFold(n_splits=5)
    accs = []
    for tr, te in cv.split(ds):
        # majority baseline
        pred = np.full(len(te), np.sign(np.mean(labels[tr])) if len(tr) else 0)
        accs.append((pred == labels[te]).mean())
    # accuracy should NOT be wildly above the majority-class baseline
    # we just ensure < 0.7 to avoid blatant leakage
    assert max(accs) < 0.85
