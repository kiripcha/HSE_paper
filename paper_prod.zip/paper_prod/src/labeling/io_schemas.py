"""schemas for the labeling module."""

from __future__ import annotations

from typing import Any

import numpy as np
from pydantic import BaseModel, ConfigDict


class LabeledDataset(BaseModel):
    """dataset ready for supervised learning."""

    model_config = ConfigDict(arbitrary_types_allowed=True, frozen=True)

    X: np.ndarray
    y: np.ndarray
    sample_weights: np.ndarray
    t0: np.ndarray
    t1: np.ndarray
    feature_names: tuple[str, ...]
    label_meta: dict[str, Any] = {}

    @property
    def n_samples(self) -> int:
        return int(self.X.shape[0])
