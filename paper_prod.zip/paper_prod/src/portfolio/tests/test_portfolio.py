"""tests for portfolio optimizers."""

from __future__ import annotations

import numpy as np
import pytest

from src.portfolio import (
    HRPOptimizer,
    LedoitWolfCovariance,
    MarkowitzOptimizer,
    PortfolioConstraints,
    RiskParityOptimizer,
)


def _sample_cov_mu(n: int = 5, seed: int = 0) -> tuple[np.ndarray, np.ndarray, list[str]]:
    rng = np.random.default_rng(seed)
    A = rng.normal(size=(n, n))
    cov = A @ A.T / n + np.eye(n) * 0.01
    mu = rng.normal(0.01, 0.005, size=n)
    return cov, mu, [f"A{i}" for i in range(n)]


@pytest.mark.parametrize(
    "opt_cls", [MarkowitzOptimizer, RiskParityOptimizer, HRPOptimizer]
)
def test_optimizer_returns_valid_weights(opt_cls) -> None:
    cov, mu, syms = _sample_cov_mu()
    opt = opt_cls() if opt_cls is not MarkowitzOptimizer else MarkowitzOptimizer(risk_aversion=5.0)
    c = PortfolioConstraints(max_weight_per_asset=0.5, min_weight_per_asset=0.0)
    tw = opt.optimize(syms, mu, cov, c)
    w = np.array([tw.weights[s] for s in syms])
    assert np.all(w >= 0)
    assert np.all(w <= 0.5 + 1e-9)
    assert abs(w.sum() - c.leverage_cap) < 1e-6


def test_risk_parity_equal_contributions() -> None:
    cov, mu, syms = _sample_cov_mu(n=4, seed=1)
    opt = RiskParityOptimizer(max_iter=2000)
    c = PortfolioConstraints(max_weight_per_asset=1.0)
    tw = opt.optimize(syms, mu, cov, c)
    w = np.array([tw.weights[s] for s in syms])
    sigma_w = cov @ w
    rc = w * sigma_w
    rc_norm = rc / rc.sum()
    # contributions should be roughly equal
    assert rc_norm.std() < 0.1


def test_hrp_handles_block_correlation() -> None:
    # two clusters: assets 0-2 highly correlated, 3-5 highly correlated, blocks ~ uncorrelated
    n = 6
    block = np.eye(3) * 0.01 + (1 - np.eye(3)) * 0.008
    cov = np.zeros((n, n))
    cov[:3, :3] = block
    cov[3:, 3:] = block
    cov += np.eye(n) * 0.002
    mu = np.zeros(n)
    syms = [f"A{i}" for i in range(n)]
    opt = HRPOptimizer()
    c = PortfolioConstraints(max_weight_per_asset=1.0)
    tw = opt.optimize(syms, mu, cov, c)
    w = np.array([tw.weights[s] for s in syms])
    # group sums should be ~ equal (clusters get balanced)
    g1 = w[:3].sum()
    g2 = w[3:].sum()
    assert abs(g1 - g2) < 0.15


def test_ledoit_wolf_psd() -> None:
    rng = np.random.default_rng(0)
    rets = rng.normal(0, 0.01, size=(500, 5))
    cov = LedoitWolfCovariance().estimate(rets)
    eigvals = np.linalg.eigvalsh(cov)
    assert eigvals.min() >= -1e-10
