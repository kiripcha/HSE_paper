"""portfolio optimizers: Markowitz, HRP, Risk Parity."""

from __future__ import annotations

import numpy as np
from scipy.cluster.hierarchy import linkage
from scipy.spatial.distance import squareform

from ..io_schemas import PortfolioConstraints, TargetWeights


def _clip_to_constraints(
    w: np.ndarray, c: PortfolioConstraints
) -> np.ndarray:
    """project to satisfy min/max-per-asset and sum = leverage_cap."""
    w = np.asarray(w, dtype=np.float64)
    for _ in range(50):
        w = np.clip(w, c.min_weight_per_asset, c.max_weight_per_asset)
        s = w.sum()
        if s <= 0:
            return np.full_like(w, c.leverage_cap / len(w))
        w = w / s * c.leverage_cap
        # stop if everything is within bounds
        if (w <= c.max_weight_per_asset + 1e-12).all() and (
            w >= c.min_weight_per_asset - 1e-12
        ).all():
            break
    return w


class MarkowitzOptimizer:
    """mean-variance with shrinkage. Long-only by default."""

    def __init__(self, risk_aversion: float = 5.0, shrinkage: float = 0.1) -> None:
        self.risk_aversion = risk_aversion
        self.shrinkage = shrinkage

    @property
    def optimizer_id(self) -> str:
        return f"markowitz_ra{self.risk_aversion}"

    def optimize(
        self,
        symbols: list[str],
        mu: np.ndarray,
        cov: np.ndarray,
        constraints: PortfolioConstraints,
        ts_ns: int = 0,
    ) -> TargetWeights:
        n = len(symbols)
        # ledoit-Wolf-like shrinkage to diagonal
        avg_var = float(np.mean(np.diag(cov)))
        target = np.eye(n) * avg_var
        cov_s = (1 - self.shrinkage) * cov + self.shrinkage * target
        # closed-form unconstrained MV: w* ∝ cov^{-1} mu / risk_aversion
        try:
            inv_cov = np.linalg.solve(cov_s, np.eye(n))
            w_raw = inv_cov @ mu / self.risk_aversion
        except np.linalg.LinAlgError:
            w_raw = np.ones(n) / n
        # project to simplex if min_weight_per_asset >= 0
        w = _clip_to_constraints(w_raw, constraints)
        if w.sum() <= 0:
            w = np.ones(n) / n * constraints.leverage_cap
        exp_ret = float(w @ mu)
        exp_var = float(w @ cov_s @ w)
        return TargetWeights(
            ts_ns=ts_ns,
            weights={s: float(w[i]) for i, s in enumerate(symbols)},
            expected_return=exp_ret,
            expected_vol=float(np.sqrt(max(0.0, exp_var))),
            optimizer_id=self.optimizer_id,
        )


class RiskParityOptimizer:
    """equal risk contribution via iterative algorithm."""

    optimizer_id = "risk_parity"

    def __init__(self, max_iter: int = 200, tol: float = 1e-7) -> None:
        self.max_iter = max_iter
        self.tol = tol

    def optimize(
        self,
        symbols: list[str],
        mu: np.ndarray,
        cov: np.ndarray,
        constraints: PortfolioConstraints,
        ts_ns: int = 0,
    ) -> TargetWeights:
        del mu  # ERC doesn't use expected returns
        n = len(symbols)
        w = np.ones(n) / n
        for _ in range(self.max_iter):
            sigma_w = cov @ w
            rc = w * sigma_w
            total = rc.sum()
            target_rc = total / n
            grad = rc - target_rc
            step = 1e-2 * grad / (np.abs(sigma_w) + 1e-12)
            w_new = np.clip(w - step, 1e-6, None)
            w_new = w_new / w_new.sum()
            if np.linalg.norm(w_new - w) < self.tol:
                w = w_new
                break
            w = w_new
        w = _clip_to_constraints(w, constraints)
        return TargetWeights(
            ts_ns=ts_ns,
            weights={s: float(w[i]) for i, s in enumerate(symbols)},
            expected_vol=float(np.sqrt(w @ cov @ w)),
            optimizer_id=self.optimizer_id,
        )


class HRPOptimizer:
    """hierarchical Risk Parity (Lopez de Prado 2016)."""

    optimizer_id = "hrp"

    def __init__(self) -> None:
        pass

    def _quasi_diag(self, link: np.ndarray) -> list[int]:
        link = link.astype(int)
        n_clusters = link.shape[0] + 1
        sort_ix = [link[-1, 0], link[-1, 1]]
        num_items = n_clusters
        while max(sort_ix) >= num_items:
            new = []
            for i in sort_ix:
                if i < num_items:
                    new.append(i)
                else:
                    cluster_idx = i - num_items
                    new.append(link[cluster_idx, 0])
                    new.append(link[cluster_idx, 1])
            sort_ix = new
        return sort_ix

    def _recursive_bisect(self, cov: np.ndarray, sort_ix: list[int]) -> np.ndarray:
        w = np.ones(len(sort_ix))
        clusters = [sort_ix]
        while clusters:
            new_clusters = []
            for cluster in clusters:
                if len(cluster) <= 1:
                    continue
                half = len(cluster) // 2
                left = cluster[:half]
                right = cluster[half:]
                cov_l = cov[np.ix_(left, left)]
                cov_r = cov[np.ix_(right, right)]
                var_l = float(self._cluster_var(cov_l))
                var_r = float(self._cluster_var(cov_r))
                alpha = 1.0 - var_l / (var_l + var_r) if (var_l + var_r) > 0 else 0.5
                for li in left:
                    w[sort_ix.index(li)] *= alpha
                for ri in right:
                    w[sort_ix.index(ri)] *= 1 - alpha
                new_clusters += [left, right]
            clusters = new_clusters
        return w

    @staticmethod
    def _cluster_var(cov: np.ndarray) -> float:
        ivp = 1.0 / np.diag(cov)
        ivp = ivp / ivp.sum()
        return float(ivp @ cov @ ivp)

    def optimize(
        self,
        symbols: list[str],
        mu: np.ndarray,
        cov: np.ndarray,
        constraints: PortfolioConstraints,
        ts_ns: int = 0,
    ) -> TargetWeights:
        del mu
        n = len(symbols)
        # correlation matrix from cov
        std = np.sqrt(np.diag(cov))
        corr = cov / np.outer(std, std)
        corr = np.clip(corr, -1.0, 1.0)
        dist = np.sqrt(0.5 * (1.0 - corr))
        np.fill_diagonal(dist, 0.0)
        condensed = squareform(dist, checks=False)
        link = linkage(condensed, method="single")
        sort_ix = self._quasi_diag(link)
        # reorder cov for bisection
        w_in_sorted_order = self._recursive_bisect(cov, sort_ix)
        # map back to original order
        w = np.zeros(n)
        for sorted_pos, orig_idx in enumerate(sort_ix):
            w[orig_idx] = w_in_sorted_order[sorted_pos]
        w = w / w.sum()
        w = _clip_to_constraints(w, constraints)
        return TargetWeights(
            ts_ns=ts_ns,
            weights={s: float(w[i]) for i, s in enumerate(symbols)},
            expected_vol=float(np.sqrt(w @ cov @ w)),
            optimizer_id=self.optimizer_id,
        )


class LedoitWolfCovariance:
    """ledoit-Wolf shrinkage covariance estimator."""

    def __init__(self) -> None:
        from sklearn.covariance import LedoitWolf

        self._impl = LedoitWolf

    def estimate(self, returns: np.ndarray) -> np.ndarray:
        est = self._impl().fit(returns)
        return est.covariance_
