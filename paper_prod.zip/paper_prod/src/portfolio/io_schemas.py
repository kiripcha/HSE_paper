"""schemas for portfolio optimization."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict


class PortfolioConstraints(BaseModel):
    model_config = ConfigDict(frozen=True)

    max_weight_per_asset: float = 0.3
    min_weight_per_asset: float = 0.0
    leverage_cap: float = 1.0
    turnover_cap: float | None = None
    transaction_cost_bps: float = 5.0


class TargetWeights(BaseModel):
    model_config = ConfigDict(frozen=True)

    ts_ns: int
    weights: dict[str, float]
    expected_return: float = 0.0
    expected_vol: float = 0.0
    optimizer_id: str = ""
    solver_status: Literal["optimal", "suboptimal", "infeasible"] = "optimal"
