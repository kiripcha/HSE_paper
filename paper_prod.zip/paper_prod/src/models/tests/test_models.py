"""smoke + determinism tests for predictive models."""

from __future__ import annotations

import numpy as np
import pytest

from src.labeling import LabeledDataset
from src.models import LightGBMModel, MLPModel, RidgeModel, TCNModel


def _make_dataset(n: int = 500, n_features: int = 8, seed: int = 0) -> LabeledDataset:
    rng = np.random.default_rng(seed)
    X = rng.normal(size=(n, n_features)).astype(np.float64)
    # weak linear relationship + noise
    w = rng.normal(size=n_features)
    y = (X @ w + rng.normal(0, 0.5, size=n)).astype(np.float64)
    return LabeledDataset(
        X=X,
        y=y,
        sample_weights=np.ones(n),
        t0=np.arange(n, dtype=np.int64),
        t1=np.arange(n, dtype=np.int64) + 10,
        feature_names=tuple(f"f{i}" for i in range(n_features)),
    )


@pytest.mark.parametrize("model_cls", [RidgeModel, LightGBMModel, MLPModel, TCNModel])
def test_fit_predict_smoke(model_cls) -> None:
    ds = _make_dataset()
    model = model_cls(model_id=model_cls.__name__.lower(), max_epochs=3) if model_cls in (MLPModel, TCNModel) else model_cls(model_id=model_cls.__name__.lower())
    report = model.fit(ds)
    assert report.n_train > 0
    # batch predict
    preds = model.predict_batch(ds.X[:10])
    assert preds.shape == (10,)
    # single predict
    p = model.predict_one(ds.X[0])
    assert p.mu == pytest.approx(preds[0], rel=1e-3)
    assert hasattr(p, "sigma")


def test_torch_seed_determinism() -> None:
    """two fits with same seed → identical predictions."""
    ds = _make_dataset()
    m1 = MLPModel(model_id="m1", max_epochs=3, seed=123)
    m2 = MLPModel(model_id="m2", max_epochs=3, seed=123)
    m1.fit(ds)
    m2.fit(ds)
    p1 = m1.predict_batch(ds.X[:50])
    p2 = m2.predict_batch(ds.X[:50])
    assert np.allclose(p1, p2, atol=1e-6)


def test_mc_dropout_returns_nonzero_sigma() -> None:
    """MLP has dropout — uncertainty estimate should be > 0 after fit."""
    ds = _make_dataset()
    m = MLPModel(model_id="mlp", max_epochs=3, dropout=0.3)
    m.fit(ds)
    p = m.predict_one(ds.X[0])
    assert p.sigma >= 0.0  # may be zero if MC variance happens to be zero


def test_ridge_recovers_linear_signal() -> None:
    """ridge should give low MSE on a linear-truth dataset."""
    ds = _make_dataset(n=2000, n_features=5)
    m = RidgeModel(model_id="ridge", alpha=0.01)
    rep = m.fit(ds)
    # train_loss MSE should be << variance of y
    assert rep.train_loss < ds.y.var()
