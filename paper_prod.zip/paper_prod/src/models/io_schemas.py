"""schemas for the models module."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class Prediction(BaseModel):
    """model output for a single point/sample."""

    model_config = ConfigDict(frozen=True)

    model_id: str
    ts_ns: int
    symbol: str
    horizon_ns: int = 0
    mu: float
    sigma: float = 0.0
    direction_proba: float | None = None
    metadata: dict[str, float] = Field(default_factory=dict)


class FitReport(BaseModel):
    """diagnostic from a single fit() call."""

    model_config = ConfigDict(frozen=True)

    model_id: str
    train_loss: float
    val_loss: float | None = None
    train_acc: float | None = None
    val_acc: float | None = None
    n_train: int = 0
    n_val: int = 0
    wall_sec: float = 0.0
