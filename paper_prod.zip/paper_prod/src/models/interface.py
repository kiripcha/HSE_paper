"""public protocols for the models module."""

from __future__ import annotations

from pathlib import Path
from typing import Protocol, runtime_checkable

import numpy as np

from src.features.io_schemas import FeatureVector
from src.labeling.io_schemas import LabeledDataset

from .io_schemas import FitReport, Prediction


@runtime_checkable
class PredictiveModel(Protocol):
    """common interface for alpha models."""

    name: str
    version: str
    target_horizon_ns: int

    def fit(self, dataset: LabeledDataset) -> FitReport: ...

    def predict_one(self, x: FeatureVector | np.ndarray) -> Prediction: ...

    def predict_batch(self, X: np.ndarray) -> np.ndarray: ...

    def save(self, path: Path) -> None: ...
