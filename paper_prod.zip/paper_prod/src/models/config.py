"""pydantic configs for the models module."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

ModelType = Literal["Ridge", "LightGBM", "TCN", "LSTM", "MLP"]


class ModelSpec(BaseModel):
    model_config = ConfigDict(frozen=True, extra="allow")

    id: str
    type: ModelType


class TrainingConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    batch_size: int = 256
    max_epochs: int = 20
    patience: int = 5
    learning_rate: float = 1e-3
    device: Literal["cpu", "cuda", "auto"] = "auto"


class ModelsConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    models: list[ModelSpec] = Field(default_factory=list)
    training: TrainingConfig = TrainingConfig()
