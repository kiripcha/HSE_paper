"""PyTorch-based predictive models: MLP, TCN, LSTM.
"""

from __future__ import annotations

import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

from src.features.io_schemas import FeatureVector
from src.labeling.io_schemas import LabeledDataset

from ..io_schemas import FitReport, Prediction


def _set_seed(seed: int) -> None:
    torch.manual_seed(seed)
    np.random.seed(seed)


class _TorchModelBase:
    """common training loop. Subclasses build the network."""

    name = "TorchBase"

    def __init__(
        self,
        model_id: str,
        learning_rate: float = 1e-3,
        max_epochs: int = 20,
        batch_size: int = 256,
        patience: int = 5,
        device: str = "auto",
        seed: int = 42,
    ) -> None:
        self.model_id = model_id
        self.version = "1.0"
        self.target_horizon_ns = 0
        self.learning_rate = learning_rate
        self.max_epochs = max_epochs
        self.batch_size = batch_size
        self.patience = patience
        self.seed = seed
        self.device = (
            "cuda" if (device == "auto" and torch.cuda.is_available()) else (
                "cpu" if device == "auto" else device
            )
        )
        self.net: nn.Module | None = None
        self.n_features: int | None = None

    def _build(self, n_features: int) -> nn.Module:
        raise NotImplementedError

    def fit(self, dataset: LabeledDataset) -> FitReport:
        _set_seed(self.seed)
        t0 = time.perf_counter()
        self.n_features = dataset.X.shape[1]
        self.net = self._build(self.n_features).to(self.device)
        opt = torch.optim.Adam(self.net.parameters(), lr=self.learning_rate)
        loss_fn = nn.MSELoss(reduction="none")

        X = torch.tensor(dataset.X, dtype=torch.float32, device=self.device)
        y = torch.tensor(dataset.y.astype(np.float32), dtype=torch.float32, device=self.device)
        w = torch.tensor(
            dataset.sample_weights.astype(np.float32), dtype=torch.float32, device=self.device
        )
        n = len(y)
        n_train = int(0.8 * n)
        perm = torch.randperm(n)
        train_idx, val_idx = perm[:n_train], perm[n_train:]
        train_loader = DataLoader(
            TensorDataset(X[train_idx], y[train_idx], w[train_idx]),
            batch_size=self.batch_size,
            shuffle=True,
        )

        best_val = float("inf")
        bad_epochs = 0
        final_train_loss = float("nan")
        final_val_loss = float("nan")
        for epoch in range(self.max_epochs):
            self.net.train()
            losses = []
            for xb, yb, wb in train_loader:
                opt.zero_grad()
                pred = self.net(xb).squeeze(-1)
                loss = (loss_fn(pred, yb) * wb).mean()
                loss.backward()
                opt.step()
                losses.append(loss.item())
            final_train_loss = float(np.mean(losses))

            self.net.eval()
            with torch.no_grad():
                val_pred = self.net(X[val_idx]).squeeze(-1)
                val_loss = float(((val_pred - y[val_idx]) ** 2).mean().item())
            final_val_loss = val_loss
            if val_loss < best_val - 1e-6:
                best_val = val_loss
                bad_epochs = 0
            else:
                bad_epochs += 1
                if bad_epochs >= self.patience:
                    break

        return FitReport(
            model_id=self.model_id,
            train_loss=final_train_loss,
            val_loss=final_val_loss,
            n_train=int(n_train),
            n_val=int(n - n_train),
            wall_sec=time.perf_counter() - t0,
        )

    def predict_batch(self, X: np.ndarray) -> np.ndarray:
        assert self.net is not None
        self.net.eval()
        with torch.no_grad():
            x = torch.tensor(X, dtype=torch.float32, device=self.device)
            return self.net(x).squeeze(-1).cpu().numpy()

    def predict_one(self, x: FeatureVector | np.ndarray) -> Prediction:
        assert self.net is not None
        arr = x if isinstance(x, np.ndarray) else x.values
        ts = 0 if isinstance(x, np.ndarray) else x.ts_ns
        sym = "?" if isinstance(x, np.ndarray) else x.symbol
        self.net.eval()
        with torch.no_grad():
            t = torch.tensor(arr.reshape(1, -1), dtype=torch.float32, device=self.device)
            mu = float(self.net(t).squeeze().cpu().item())
        # MC-dropout sigma estimate (5 stochastic passes if dropout layers are present)
        sigma = self._mc_dropout_sigma(arr) if self._has_dropout() else 0.0
        return Prediction(model_id=self.model_id, ts_ns=ts, symbol=sym, mu=mu, sigma=sigma)

    def _has_dropout(self) -> bool:
        if self.net is None:
            return False
        return any(isinstance(m, nn.Dropout) for m in self.net.modules())

    def _mc_dropout_sigma(self, arr: np.ndarray, n_passes: int = 5) -> float:
        assert self.net is not None
        self.net.train()  # enable dropout
        with torch.no_grad():
            t = torch.tensor(arr.reshape(1, -1), dtype=torch.float32, device=self.device)
            preds = [float(self.net(t).squeeze().cpu().item()) for _ in range(n_passes)]
        self.net.eval()
        return float(np.std(preds, ddof=1)) if len(preds) > 1 else 0.0

    def save(self, path: Path) -> None:
        assert self.net is not None
        torch.save({"state_dict": self.net.state_dict(), "n_features": self.n_features}, path)


class MLPModel(_TorchModelBase):
    name = "MLP"

    def __init__(
        self,
        model_id: str = "mlp",
        hidden: tuple[int, ...] = (64, 64),
        dropout: float = 0.1,
        **kwargs,
    ) -> None:
        super().__init__(model_id=model_id, **kwargs)
        self.hidden = hidden
        self.dropout = dropout

    def _build(self, n_features: int) -> nn.Module:
        layers: list[nn.Module] = []
        prev = n_features
        for h in self.hidden:
            layers += [nn.Linear(prev, h), nn.ReLU(), nn.Dropout(self.dropout)]
            prev = h
        layers.append(nn.Linear(prev, 1))
        return nn.Sequential(*layers)


class _CausalConv1d(nn.Module):
    def __init__(self, in_ch: int, out_ch: int, kernel: int, dilation: int) -> None:
        super().__init__()
        pad = (kernel - 1) * dilation
        self.pad = pad
        self.conv = nn.Conv1d(in_ch, out_ch, kernel, dilation=dilation)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = nn.functional.pad(x, (self.pad, 0))
        return self.conv(x)


class TCNModel(_TorchModelBase):
    """

    for supervised tabular features we treat the feature axis as the time axis,
    which is a degenerate-but-fine smoke test. Real TCN usage would feed
    sequences of FeatureVector through time. We keep the tabular form here for
    a uniform fit/predict interface.
    """

    name = "TCN"

    def __init__(
        self,
        model_id: str = "tcn",
        channels: tuple[int, ...] = (32, 32),
        kernel: int = 3,
        dropout: float = 0.1,
        **kwargs,
    ) -> None:
        super().__init__(model_id=model_id, **kwargs)
        self.channels = channels
        self.kernel = kernel
        self.dropout = dropout

    def _build(self, n_features: int) -> nn.Module:
        layers: list[nn.Module] = []
        in_ch = 1
        for i, c in enumerate(self.channels):
            layers += [
                _CausalConv1d(in_ch, c, kernel=self.kernel, dilation=2**i),
                nn.ReLU(),
                nn.Dropout(self.dropout),
            ]
            in_ch = c
        last_channels = self.channels[-1]

        class Head(nn.Module):
            def __init__(self, feat_dim: int) -> None:
                super().__init__()
                self.linear = nn.Linear(last_channels * feat_dim, 1)

            def forward(self, x: torch.Tensor) -> torch.Tensor:
                # x: (B, 1, F) -> reshape after conv stack to (B, C*F)
                return self.linear(x.flatten(1))

        class TCNNet(nn.Module):
            def __init__(self, stack: nn.Sequential, head: nn.Module) -> None:
                super().__init__()
                self.stack = stack
                self.head = head

            def forward(self, x: torch.Tensor) -> torch.Tensor:
                # tabular x: (B, F) -> add channel dim -> (B, 1, F)
                x = x.unsqueeze(1)
                x = self.stack(x)
                return self.head(x)

        return TCNNet(nn.Sequential(*layers), Head(n_features))
