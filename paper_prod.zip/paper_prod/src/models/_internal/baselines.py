"""baseline non-DL models: Ridge and LightGBM."""

from __future__ import annotations

import pickle
import time
from pathlib import Path

import numpy as np
from sklearn.linear_model import Ridge

from src.features.io_schemas import FeatureVector
from src.labeling.io_schemas import LabeledDataset

from ..io_schemas import FitReport, Prediction


class RidgeModel:
    name = "Ridge"

    def __init__(self, model_id: str = "ridge", alpha: float = 1.0) -> None:
        self.model_id = model_id
        self.version = "1.0"
        self.target_horizon_ns = 0
        self.alpha = alpha
        self._impl: Ridge | None = None
        self._classes: np.ndarray | None = None

    def fit(self, dataset: LabeledDataset) -> FitReport:
        t0 = time.perf_counter()
        self._impl = Ridge(alpha=self.alpha)
        self._impl.fit(dataset.X, dataset.y.astype(float), sample_weight=dataset.sample_weights)
        train_pred = self._impl.predict(dataset.X)
        loss = float(np.mean((train_pred - dataset.y) ** 2))
        return FitReport(
            model_id=self.model_id,
            train_loss=loss,
            n_train=dataset.n_samples,
            wall_sec=time.perf_counter() - t0,
        )

    def predict_one(self, x: FeatureVector | np.ndarray) -> Prediction:
        assert self._impl is not None
        arr = x if isinstance(x, np.ndarray) else x.values
        mu = float(self._impl.predict(arr.reshape(1, -1))[0])
        ts = 0 if isinstance(x, np.ndarray) else x.ts_ns
        sym = "?" if isinstance(x, np.ndarray) else x.symbol
        return Prediction(model_id=self.model_id, ts_ns=ts, symbol=sym, mu=mu)

    def predict_batch(self, X: np.ndarray) -> np.ndarray:
        assert self._impl is not None
        return self._impl.predict(X)

    def save(self, path: Path) -> None:
        with path.open("wb") as f:
            pickle.dump(self._impl, f)


class LightGBMModel:
    name = "LightGBM"

    def __init__(
        self,
        model_id: str = "lgbm",
        num_leaves: int = 31,
        n_estimators: int = 200,
        learning_rate: float = 0.05,
        min_data_in_leaf: int = 50,
    ) -> None:
        self.model_id = model_id
        self.version = "1.0"
        self.target_horizon_ns = 0
        self.num_leaves = num_leaves
        self.n_estimators = n_estimators
        self.learning_rate = learning_rate
        self.min_data_in_leaf = min_data_in_leaf
        self._impl = None  # lazily imported to avoid mandatory dep at import time

    def fit(self, dataset: LabeledDataset) -> FitReport:
        import lightgbm as lgb

        t0 = time.perf_counter()
        ds = lgb.Dataset(
            dataset.X, label=dataset.y.astype(float), weight=dataset.sample_weights
        )
        self._impl = lgb.train(
            {
                "objective": "regression",
                "num_leaves": self.num_leaves,
                "learning_rate": self.learning_rate,
                "min_data_in_leaf": self.min_data_in_leaf,
                "verbose": -1,
            },
            ds,
            num_boost_round=self.n_estimators,
        )
        pred = self._impl.predict(dataset.X)
        loss = float(np.mean((pred - dataset.y) ** 2))
        return FitReport(
            model_id=self.model_id,
            train_loss=loss,
            n_train=dataset.n_samples,
            wall_sec=time.perf_counter() - t0,
        )

    def predict_one(self, x: FeatureVector | np.ndarray) -> Prediction:
        assert self._impl is not None
        arr = x if isinstance(x, np.ndarray) else x.values
        mu = float(self._impl.predict(arr.reshape(1, -1))[0])
        ts = 0 if isinstance(x, np.ndarray) else x.ts_ns
        sym = "?" if isinstance(x, np.ndarray) else x.symbol
        return Prediction(model_id=self.model_id, ts_ns=ts, symbol=sym, mu=mu)

    def predict_batch(self, X: np.ndarray) -> np.ndarray:
        assert self._impl is not None
        return self._impl.predict(X)

    def save(self, path: Path) -> None:
        assert self._impl is not None
        self._impl.save_model(str(path))
