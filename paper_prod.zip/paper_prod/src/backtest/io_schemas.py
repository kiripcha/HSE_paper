"""schemas for backtest reports."""

from __future__ import annotations

from typing import Any

import numpy as np
from pydantic import BaseModel, ConfigDict, Field


class BacktestMetrics(BaseModel):
    model_config = ConfigDict(frozen=True)

    total_return: float = 0.0
    annualized_return: float = 0.0
    annualized_vol: float = 0.0
    sharpe: float = 0.0
    sortino: float = 0.0
    calmar: float = 0.0
    max_drawdown: float = 0.0
    deflated_sharpe: float = 0.0
    turnover_annual: float = 0.0
    hit_rate: float = 0.0
    n_trades: int = 0


class BacktestReport(BaseModel):
    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    equity_curve: np.ndarray
    returns: np.ndarray
    timestamps_ns: np.ndarray
    fills: list[dict] = Field(default_factory=list)
    metrics: BacktestMetrics
    config_hash: str = ""
    seed: int = 0
