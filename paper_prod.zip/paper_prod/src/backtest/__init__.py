"""backtest — event-driven backtester. Module 11.
"""

from ._internal.engine import BacktestConfig, compute_metrics, run_simple_backtest
from ._internal.fill_sim import (
    QueueAwareFillSimulator,
    SimpleFillSimulator,
    square_root_impact_bps,
)
from .io_schemas import BacktestMetrics, BacktestReport
from .strategy import StrategyBacktest, StrategyConfig, StrategyReport, quick_strategy

__all__ = [
    "BacktestReport",
    "BacktestMetrics",
    "BacktestConfig",
    "compute_metrics",
    "run_simple_backtest",
    "SimpleFillSimulator",
    "QueueAwareFillSimulator",
    "square_root_impact_bps",
    "StrategyConfig",
    "StrategyBacktest",
    "StrategyReport",
    "quick_strategy",
]
