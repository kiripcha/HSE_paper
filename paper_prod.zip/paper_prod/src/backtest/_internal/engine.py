"""event-driven backtest engine.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
import structlog

from src.execution.io_schemas import ChildOrder
from src.labeling import sharpe_ratio
from src.market_data.io_schemas import BookSnapshot
from src.risk import PortfolioMonitor

from ..io_schemas import BacktestMetrics, BacktestReport
from .fill_sim import QueueAwareFillSimulator

log = structlog.get_logger(__name__)


@dataclass
class BacktestConfig:
    initial_capital: float = 100_000.0
    seed: int = 42
    rebalance_interval_ns: int = 60 * 1_000_000_000  # 1 min default
    use_queue_aware_fills: bool = True


def compute_metrics(returns: np.ndarray, equity: np.ndarray, n_fills: int) -> BacktestMetrics:
    if len(returns) < 2:
        return BacktestMetrics(n_trades=n_fills)
    total_return = float(equity[-1] / equity[0] - 1.0)
    # assume returns are per-bar; annualize by their step count (approximate)
    periods_per_year = 252 * 24 * 60  # treat each step as a minute
    ann_ret = float(returns.mean() * periods_per_year)
    ann_vol = float(returns.std(ddof=1) * math.sqrt(periods_per_year))
    sr = sharpe_ratio(returns, periods_per_year=periods_per_year)
    downside = returns[returns < 0]
    sortino = (
        float(returns.mean() / downside.std(ddof=1) * math.sqrt(periods_per_year))
        if len(downside) > 1 and downside.std(ddof=1) > 0 else 0.0
    )
    peak = np.maximum.accumulate(equity)
    dd = (peak - equity) / peak
    max_dd = float(dd.max())
    calmar = ann_ret / max_dd if max_dd > 0 else 0.0
    hit_rate = float((returns > 0).mean())
    return BacktestMetrics(
        total_return=total_return,
        annualized_return=ann_ret,
        annualized_vol=ann_vol,
        sharpe=sr,
        sortino=sortino,
        calmar=calmar,
        max_drawdown=max_dd,
        n_trades=n_fills,
        hit_rate=hit_rate,
    )


def run_simple_backtest(
    timestamps_ns: np.ndarray,
    prices: dict[str, np.ndarray],
    book_snapshots: dict[str, list[BookSnapshot]],
    target_weights_series: list[dict[str, float]],  # one per timestamp
    config: BacktestConfig | None = None,
) -> BacktestReport:
    """minimal but honest backtester."""
    cfg = config or BacktestConfig()
    pm = PortfolioMonitor(starting_cash=cfg.initial_capital)
    sim = QueueAwareFillSimulator()
    symbols = list(prices.keys())
    n_steps = len(timestamps_ns)
    equity_curve = np.zeros(n_steps)
    fills_log: list[dict] = []
    last_rebal_ts = timestamps_ns[0] - 10**18

    for t, ts in enumerate(timestamps_ns):
        # mark-to-market
        pm.on_market_data({s: prices[s][t] for s in symbols})
        snap = pm.snapshot(ts_ns=int(ts))
        equity_curve[t] = snap.equity

        if int(ts) - last_rebal_ts < cfg.rebalance_interval_ns:
            continue
        last_rebal_ts = int(ts)

        # generate fills to match target weights
        target = target_weights_series[t]
        for sym in symbols:
            target_notional = target.get(sym, 0.0) * snap.equity
            current_notional = pm.positions.get(sym, 0.0) * prices[sym][t]
            diff_notional = target_notional - current_notional
            if abs(diff_notional) < 1.0:
                continue
            side = "buy" if diff_notional > 0 else "sell"
            qty = abs(diff_notional) / prices[sym][t]
            book = book_snapshots[sym][t]
            order = ChildOrder(
                client_order_id=f"{sym}-{t}",
                exchange="sim",
                symbol=sym,
                side=side,
                order_type="market",
                quantity=qty,
            )
            fill = sim.fill(order, book, ts_ns=int(ts))
            if fill is not None:
                pm.on_fill(fill)
                fills_log.append(fill.model_dump())

    returns = np.zeros_like(equity_curve)
    returns[1:] = np.diff(equity_curve) / equity_curve[:-1]
    metrics = compute_metrics(returns[1:], equity_curve, len(fills_log))
    return BacktestReport(
        equity_curve=equity_curve,
        returns=returns,
        timestamps_ns=timestamps_ns,
        fills=fills_log,
        metrics=metrics,
        seed=cfg.seed,
    )
