"""simple fill simulator with slippage models.
"""

from __future__ import annotations

import math

from src.execution.io_schemas import ChildOrder, Fill
from src.market_data.io_schemas import BookSnapshot


def square_root_impact_bps(qty: float, ref_volume: float, c: float = 0.5) -> float:
    """"""
    if ref_volume <= 0:
        return 0.0
    return c * 100.0 * math.sqrt(qty / ref_volume)  # in bps


class SimpleFillSimulator:
    """naive — fills at mid instantly. Use only for sanity tests."""

    def fill(self, order: ChildOrder, book: BookSnapshot, ts_ns: int = 0) -> Fill | None:
        if not book.bids or not book.asks:
            return None
        mid = (book.bids[0].price + book.asks[0].price) / 2.0
        return Fill(
            ts_ns=ts_ns,
            symbol=order.symbol,
            side=order.side,
            quantity=order.quantity,
            price=mid,
        )


class QueueAwareFillSimulator:
    """realistic-ish simulator."""

    def __init__(self, latency_ns: int = 50_000_000, slippage_c: float = 0.3) -> None:
        self.latency_ns = latency_ns
        self.slippage_c = slippage_c

    def fill(self, order: ChildOrder, book: BookSnapshot, ts_ns: int = 0) -> Fill | None:
        if not book.bids or not book.asks:
            return None
        if order.order_type == "market":
            return self._fill_market(order, book, ts_ns)
        if order.order_type == "limit":
            return self._fill_limit(order, book, ts_ns)
        return None

    def _fill_market(self, order: ChildOrder, book: BookSnapshot, ts_ns: int) -> Fill:
        # walk the book
        levels = book.asks if order.side == "buy" else book.bids
        remaining = order.quantity
        total_cost = 0.0
        total_qty = 0.0
        for lvl in levels:
            consume = min(remaining, lvl.quantity)
            total_cost += consume * lvl.price
            total_qty += consume
            remaining -= consume
            if remaining <= 0:
                break
        if total_qty <= 0:
            return Fill(ts_ns=ts_ns, symbol=order.symbol, side=order.side, quantity=0.0, price=levels[0].price)
        avg_price = total_cost / total_qty
        # add a small additional slippage to reflect actual taker fees / hidden
        ref_vol = sum(lvl.quantity for lvl in levels[:10])
        bps = square_root_impact_bps(total_qty, ref_vol, self.slippage_c)
        adj = avg_price * (bps / 10_000) * (1 if order.side == "buy" else -1)
        return Fill(
            ts_ns=ts_ns + self.latency_ns,
            symbol=order.symbol,
            side=order.side,
            quantity=total_qty,
            price=avg_price + adj,
        )

    def _fill_limit(self, order: ChildOrder, book: BookSnapshot, ts_ns: int) -> Fill | None:
        if order.price is None:
            return None
        opp = book.asks[0] if order.side == "buy" else book.bids[0]
        # crosses?
        crosses = (order.side == "buy" and order.price >= opp.price) or (
            order.side == "sell" and order.price <= opp.price
        )
        if crosses:
            return Fill(
                ts_ns=ts_ns + self.latency_ns,
                symbol=order.symbol,
                side=order.side,
                quantity=min(order.quantity, opp.quantity),
                price=opp.price,
            )
        # else assume no fill in single tick — backtester should re-attempt or cancel
        return None
