"""end-to-end strategy backtest that wires up modules 03–10.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Literal

import numpy as np
import pandas as pd

from src.execution.io_schemas import ChildOrder, Fill
from src.labeling import (
    LabeledDataset,
    deflated_sharpe,
    probabilistic_sharpe,
    sample_stats,
    sharpe_ratio,
)
from src.market_data.io_schemas import BookLevel, BookSnapshot
from src.meta_allocator import (
    AllocatorContext,
    EpsilonGreedyAllocator,
    LinUCBAllocator,
    ThompsonSamplingAllocator,
    UCB1Allocator,
)
from src.models import LightGBMModel, MLPModel, ModelSpec, RidgeModel, TCNModel
from src.models.io_schemas import Prediction
from src.portfolio import (
    HRPOptimizer,
    MarkowitzOptimizer,
    PortfolioConstraints,
    RiskParityOptimizer,
)
from src.regime import BOCPDDetector, HMMDetector, RegimeDetector, VolClusterDetector
from src.regime.io_schemas import RegimeState
from src.risk import (
    CryptoRiskAdapter,
    KillSwitch,
    PortfolioMonitor,
    RiskGate,
    RiskLimits,
)

from ._internal.fill_sim import QueueAwareFillSimulator
from .io_schemas import BacktestMetrics


def _make_book(mid: float, spread_bps: float = 5.0, depth: int = 5, qty: float = 50.0) -> BookSnapshot:
    """lightweight synthetic book centered on `mid` (used when only daily prices are available)."""
    half = max(0.01, mid * spread_bps / 1e4 / 2)
    bids = tuple(BookLevel(price=mid - half - i * half * 0.2, quantity=qty) for i in range(depth))
    asks = tuple(BookLevel(price=mid + half + i * half * 0.2, quantity=qty) for i in range(depth))
    return BookSnapshot(bids=bids, asks=asks)


def _features_from_prices(
    prices: pd.DataFrame, lookback: int
) -> tuple[pd.DataFrame, list[str]]:
    """compute a small fixed set of daily features per asset."""
    rets = np.log(prices / prices.shift(1))
    feats: dict[str, pd.DataFrame] = {}
    feats["ret_1"] = rets
    feats["ret_5"] = rets.rolling(5).sum()
    feats["ret_20"] = rets.rolling(20).sum()
    feats["vol_20"] = rets.rolling(20).std()
    feats["vol_60"] = rets.rolling(60).std()
    feats["mom_20"] = rets.rolling(20).mean() / rets.rolling(20).std()
    market = rets.mean(axis=1)
    feats["corr_mkt_30"] = pd.DataFrame(
        {c: rets[c].rolling(30).corr(market) for c in rets.columns},
        index=rets.index,
    )
    cols: list[str] = []
    blocks: list[pd.DataFrame] = []
    for fname, df in feats.items():
        df = df.copy()
        df.columns = [f"{a}_{fname}" for a in df.columns]
        cols.extend(df.columns)
        blocks.append(df)
    X = pd.concat(blocks, axis=1)
    return X, list(X.columns)


def _build_model(spec: ModelSpec, training: dict[str, Any]) -> Any:
    common = dict(training)
    if spec.type == "Ridge":
        return RidgeModel(
            model_id=spec.id,
            alpha=getattr(spec, "alpha", 1.0),
        )
    if spec.type == "LightGBM":
        return LightGBMModel(
            model_id=spec.id,
            num_leaves=getattr(spec, "num_leaves", 31),
            n_estimators=getattr(spec, "n_estimators", 200),
            learning_rate=getattr(spec, "learning_rate", 0.05),
            min_data_in_leaf=getattr(spec, "min_data_in_leaf", 50),
        )
    if spec.type == "MLP":
        return MLPModel(
            model_id=spec.id,
            hidden=tuple(getattr(spec, "hidden", (32, 32))),
            dropout=getattr(spec, "dropout", 0.1),
            max_epochs=common.get("max_epochs", 10),
            seed=common.get("seed", 42),
        )
    if spec.type == "TCN":
        return TCNModel(
            model_id=spec.id,
            channels=tuple(getattr(spec, "channels", (16, 16))),
            kernel=getattr(spec, "kernel", 3),
            dropout=getattr(spec, "dropout", 0.1),
            max_epochs=common.get("max_epochs", 10),
            seed=common.get("seed", 42),
        )
    raise ValueError(f"unknown model type: {spec.type}")


def _build_regime_detector(kind: str) -> RegimeDetector:
    if kind == "vol_cluster":
        return VolClusterDetector(n_regimes=3, window=30, history=300)
    if kind == "hmm":
        return HMMDetector(n_regimes=3, learning_rate=0.02)
    if kind == "bocpd":
        return BOCPDDetector(hazard=0.02)
    raise ValueError(f"unknown regime detector: {kind}")


def _build_allocator(kind: str, arms: list[str]):
    if kind == "eps_greedy":
        return EpsilonGreedyAllocator(arms, eps=0.1, discount=0.95, seed=42)
    if kind == "ucb1":
        return UCB1Allocator(arms)
    if kind == "thompson":
        return ThompsonSamplingAllocator(arms, prior_sigma=1.0, noise_sigma=1.0, seed=42)
    if kind == "linucb":
        return LinUCBAllocator(arms, context_dim=3, alpha=0.5)
    raise ValueError(f"unknown allocator: {kind}")


def _build_optimizer(kind: str):
    if kind == "hrp":
        return HRPOptimizer()
    if kind == "risk_parity":
        return RiskParityOptimizer(max_iter=200)
    if kind == "markowitz":
        return MarkowitzOptimizer(risk_aversion=10.0, shrinkage=0.1)
    raise ValueError(f"unknown optimizer: {kind}")


@dataclass
class StrategyConfig:
    """end-to-end strategy backtest config."""

    symbols: tuple[str, ...]
    # data
    lookback_days: int = 60
    train_fraction: float = 0.4  # fraction of timeline used for model training
    rebalance_every_days: int = 5
    # model pool
    model_specs: tuple[ModelSpec, ...] = (
        ModelSpec(id="ridge", type="Ridge"),
        ModelSpec(id="lgbm", type="LightGBM"),
        ModelSpec(id="mlp", type="MLP"),
    )
    training: dict[str, Any] = field(
        default_factory=lambda: {"max_epochs": 10, "seed": 42}
    )
    target_horizon_days: int = 5
    # composition
    regime_detector: Literal["vol_cluster", "hmm", "bocpd"] = "vol_cluster"
    allocator: Literal["eps_greedy", "ucb1", "thompson", "linucb"] = "thompson"
    optimizer: Literal["hrp", "risk_parity", "markowitz"] = "hrp"
    # constraints
    constraints: PortfolioConstraints = field(
        default_factory=lambda: PortfolioConstraints(
            max_weight_per_asset=0.35,
            min_weight_per_asset=0.0,
            leverage_cap=1.0,
            turnover_cap=None,
            transaction_cost_bps=5.0,
        )
    )
    risk_limits: RiskLimits = field(
        default_factory=lambda: RiskLimits(
            max_leverage=1.0, max_concentration_pct=0.40, max_drawdown_pct=0.30
        )
    )
    use_crypto_risk_adapter: bool = True
    # execution
    initial_capital: float = 100_000.0
    fill_latency_ns: int = 50_000_000
    fill_slippage_c: float = 0.3
    spread_bps: float = 5.0


@dataclass
class StrategyReport:
    """per-rebalance trace + final metrics produced by `StrategyBacktest.run()`."""

    equity_curve: pd.Series
    weights_history: pd.DataFrame
    predictions_history: pd.DataFrame
    regime_history: pd.Series
    arm_history: pd.Series
    fills: list[Fill]
    rejections: list[str]
    drawdown_history: pd.Series
    metrics: BacktestMetrics
    deflated_sharpe: float
    crypto_risk_report: dict | None = None
    config: StrategyConfig | None = None


class StrategyBacktest:
    """end-to-end strategy backtester combining modules 03-10."""

    def __init__(self, config: StrategyConfig) -> None:
        self.cfg = config
        self.symbols = list(config.symbols)
        self.fill_sim = QueueAwareFillSimulator(
            latency_ns=config.fill_latency_ns,
            slippage_c=config.fill_slippage_c,
        )
        self.portfolio_monitor = PortfolioMonitor(
            starting_cash=config.initial_capital, var_window=120
        )
        self.risk_gate = RiskGate(limits=config.risk_limits)
        self.kill_switch = KillSwitch()
        self.regime_detector = _build_regime_detector(config.regime_detector)
        arm_ids = [s.id for s in config.model_specs]
        self.allocator = _build_allocator(config.allocator, arm_ids)
        self.optimizer = _build_optimizer(config.optimizer)
        self.models: dict[str, Any] = {}
        self.crypto_risk_adapter: CryptoRiskAdapter | None = None
        self._target_index = 0  # which target asset this iteration of the pool predicts for

    # training
    def fit(self, prices: pd.DataFrame) -> "StrategyBacktest":
        """train the model pool on the first `train_fraction` of the timeline."""
        rets = np.log(prices / prices.shift(1))
        T = len(prices)
        train_end = int(T * self.cfg.train_fraction)

        # feature matrix aligned to prices.index (NaN rows kept; predict() masks)
        X_df, names = _features_from_prices(prices, self.cfg.lookback_days)
        y_series = (
            rets.rolling(self.cfg.target_horizon_days)
            .sum()
            .shift(-self.cfg.target_horizon_days)
            .mean(axis=1)
        )

        # build training set: only rows where both X and y are fully defined,
        # within the first train_end of the timeline.
        train_mask = np.arange(T) < train_end
        X_arr = X_df.to_numpy(dtype=np.float64)
        y_arr = y_series.to_numpy(dtype=np.float64)
        valid_train = (
            train_mask & ~np.isnan(X_arr).any(axis=1) & ~np.isnan(y_arr)
        )
        X_tr = X_arr[valid_train]
        y_tr = y_arr[valid_train]
        if len(X_tr) < 50:
            raise RuntimeError(
                f"only {len(X_tr)} valid training rows — increase data, "
                "lower lookback_days, or shrink target_horizon_days"
            )
        t_tr = np.arange(len(X_tr), dtype=np.int64) * 86_400_000_000_000
        ds = LabeledDataset(
            X=X_tr,
            y=y_tr,
            sample_weights=np.ones(len(y_tr)),
            t0=t_tr,
            t1=t_tr + 1,
            feature_names=tuple(names),
        )
        for spec in self.cfg.model_specs:
            model = _build_model(spec, self.cfg.training)
            model.fit(ds)
            self.models[spec.id] = model
        self._feature_df = X_df            # full-length, NaN-padded
        self._aligned_target = y_series
        self._train_end_idx = train_end
        return self

    def attach_crypto_risk(self, returns_history: pd.DataFrame) -> None:
        """optionally wire in crypto_risk for VaR-based pre-trade checks."""
        if not self.cfg.use_crypto_risk_adapter:
            return
        self.crypto_risk_adapter = CryptoRiskAdapter.from_returns(returns_history)

    # run
    def run(self, prices: pd.DataFrame) -> StrategyReport:
        if not self.models:
            raise RuntimeError("call fit(prices) before run(prices)")
        rets = np.log(prices / prices.shift(1)).fillna(0.0)
        cov_history = rets.cov().to_numpy()
        symbols = self.symbols
        T_total = len(prices)
        # start at the held-out portion right after training; lookback already
        # covered by the NaN mask on the feature DataFrame.
        start_idx = max(self._train_end_idx, self.cfg.lookback_days)
        equity_records: list[tuple[pd.Timestamp, float]] = []
        weights_records: list[dict[str, Any]] = []
        prediction_records: list[dict[str, Any]] = []
        regime_records: list[tuple[pd.Timestamp, int]] = []
        arm_records: list[tuple[pd.Timestamp, str]] = []
        fills: list[Fill] = []
        rejections: list[str] = []
        last_rebal = -10**9
        last_realized_arm_pnl: dict[str, float] = {s.id: 0.0 for s in self.cfg.model_specs}

        for t in range(start_idx, T_total - 1):
            ts = prices.index[t]
            row_prices = prices.iloc[t]
            # mark-to-market
            self.portfolio_monitor.on_market_data({s: float(row_prices[s]) for s in symbols})

            # regime update on portfolio return
            port_ret = float(rets.iloc[t].mean())
            ts_ns = int(ts.value)
            regime_state = self.regime_detector.update(port_ret, ts_ns=ts_ns, symbol="PORT")
            regime_records.append((ts, regime_state.regime_id))

            # rebalance every N days
            if t - last_rebal < self.cfg.rebalance_every_days:
                snap = self.portfolio_monitor.snapshot(ts_ns=ts_ns)
                equity_records.append((ts, snap.equity))
                continue
            last_rebal = t

            # 1) predict (mask NaN rows)
            X_row = self._feature_df.iloc[t].to_numpy(dtype=np.float64)
            if np.isnan(X_row).any():
                snap = self.portfolio_monitor.snapshot(ts_ns=ts_ns)
                equity_records.append((ts, snap.equity))
                continue
            predictions: list[Prediction] = []
            for spec in self.cfg.model_specs:
                m = self.models[spec.id]
                p = m.predict_one(X_row)
                predictions.append(p)
                prediction_records.append({"ts": ts, "model": spec.id, "mu": p.mu})

            # 2) allocate among models (bandit)
            context = AllocatorContext(ts_ns=ts_ns, regime_state=regime_state)
            sw = self.allocator.allocate(predictions, context=context)
            chosen_arm = max(sw.weights, key=lambda k: sw.weights[k])
            arm_records.append((ts, chosen_arm))

            # 3) portfolio optimization — direction from the winning model
            mu_signal = float(sw.aggregated_signal.mu)
            # synthesize per-asset expected returns: scale by recent vol per asset
            asset_vols = rets.iloc[max(0, t - 60) : t].std().to_numpy()
            asset_signals = np.full(len(symbols), mu_signal)
            # tilt towards momentum (rank-based) to disambiguate equal mu
            recent_mom = rets.iloc[max(0, t - 20) : t].sum().to_numpy()
            asset_signals = asset_signals + 0.5 * (
                recent_mom / (np.abs(recent_mom).max() + 1e-12)
            ) * np.abs(asset_signals if abs(mu_signal) > 0 else recent_mom)
            if not np.any(asset_signals > 0):
                # if model is bearish everywhere, hold cash
                tw_weights = {s: 0.0 for s in symbols}
                target_w_dict = tw_weights
            else:
                rolling_cov = (
                    rets.iloc[max(0, t - 120) : t].cov().to_numpy()
                    if t >= 120
                    else cov_history
                )
                # ensure PSD
                rolling_cov = (rolling_cov + rolling_cov.T) / 2 + 1e-6 * np.eye(len(symbols))
                target = self.optimizer.optimize(
                    symbols, asset_signals, rolling_cov, self.cfg.constraints, ts_ns=ts_ns
                )
                target_w_dict = target.weights

            from src.portfolio.io_schemas import TargetWeights

            target_obj = TargetWeights(ts_ns=ts_ns, weights=target_w_dict)
            # 4) risk validation
            snap = self.portfolio_monitor.snapshot(ts_ns=ts_ns)
            val = self.risk_gate.validate(target_obj, current_drawdown_pct=snap.drawdown_current)
            if (
                val.approved
                and self.crypto_risk_adapter is not None
                and t % 20 == 0  # occasional, not every rebalance
            ):
                extra = self.crypto_risk_adapter.validate_target(
                    target_obj, current_drawdown=snap.drawdown_current
                )
                if not extra.approved:
                    val = extra
            if not val.approved:
                rejections.append(f"{ts}: {[v.code for v in val.violations]}")
                equity_records.append((ts, snap.equity))
                weights_records.append({"ts": ts, **{s: 0.0 for s in symbols}})
                continue

            # 5) execute the diff between current positions and target
            equity = snap.equity
            for sym in symbols:
                target_notional = target_w_dict.get(sym, 0.0) * equity
                current_notional = self.portfolio_monitor.positions.get(sym, 0.0) * float(
                    row_prices[sym]
                )
                diff = target_notional - current_notional
                if abs(diff) < equity * 0.001:
                    continue
                side = "buy" if diff > 0 else "sell"
                qty = abs(diff) / float(row_prices[sym])
                book = _make_book(mid=float(row_prices[sym]), spread_bps=self.cfg.spread_bps)
                order_type = "market"
                order = ChildOrder(
                    client_order_id=f"{sym}-{t}",
                    exchange="sim",
                    symbol=sym,
                    side=side,
                    order_type=order_type,
                    quantity=qty,
                )
                fill = self.fill_sim.fill(order, book, ts_ns=ts_ns)
                if fill is not None:
                    self.portfolio_monitor.on_fill(fill)
                    fills.append(fill)
            weights_records.append({"ts": ts, **target_w_dict})

            # 6) bandit update with realized PnL since last rebalance.
            # reward proxy: predicted direction times realized cross-sectional return.
            forward_ret = float(rets.iloc[t + 1].mean())
            chosen_pred = next(p for p in predictions if p.model_id == chosen_arm)
            reward = math.copysign(abs(forward_ret), chosen_pred.mu)
            if hasattr(self.allocator, "update"):
                try:
                    self.allocator.update(chosen_arm, reward, context=context)
                except TypeError:
                    self.allocator.update(chosen_arm, reward)
            last_realized_arm_pnl[chosen_arm] = (
                last_realized_arm_pnl.get(chosen_arm, 0.0) * 0.9 + reward * 0.1
            )

            equity_records.append((ts, self.portfolio_monitor.snapshot(ts_ns=ts_ns).equity))

        equity = pd.Series(
            {ts: v for ts, v in equity_records}, name="equity"
        ).sort_index()
        wdf = pd.DataFrame(weights_records).set_index("ts") if weights_records else pd.DataFrame()
        pdf = pd.DataFrame(prediction_records) if prediction_records else pd.DataFrame()
        rdf = pd.Series({ts: v for ts, v in regime_records}, name="regime").sort_index()
        adf = pd.Series({ts: v for ts, v in arm_records}, name="arm").sort_index()
        # metrics
        rets_eq = equity.pct_change().dropna()
        # daily frequency, annualization with 365
        periods_per_year = 365
        if len(rets_eq) > 1:
            sr = sharpe_ratio(rets_eq.to_numpy(), periods_per_year=periods_per_year)
            ann_ret = float(rets_eq.mean() * periods_per_year)
            ann_vol = float(rets_eq.std(ddof=1) * math.sqrt(periods_per_year))
        else:
            sr, ann_ret, ann_vol = 0.0, 0.0, 0.0
        peak = equity.cummax()
        dd = (peak - equity) / peak
        max_dd = float(dd.max()) if len(dd) else 0.0
        skew, kurt = (sample_stats(rets_eq.to_numpy()) if len(rets_eq) > 4 else (0.0, 0.0))
        sr_per_period = (
            float(rets_eq.mean() / rets_eq.std(ddof=1)) if rets_eq.std(ddof=1) > 0 else 0.0
        )
        dsr = deflated_sharpe(
            sr_per_period,
            sharpe_std_estimate=0.1,
            n_trials=max(1, len(self.cfg.model_specs) * 4),
            n_obs=max(2, len(rets_eq)),
            skew=skew,
            kurt=kurt,
        )
        metrics = BacktestMetrics(
            total_return=float(equity.iloc[-1] / equity.iloc[0] - 1.0) if len(equity) else 0.0,
            annualized_return=ann_ret,
            annualized_vol=ann_vol,
            sharpe=sr,
            sortino=0.0,
            calmar=ann_ret / max_dd if max_dd > 0 else 0.0,
            max_drawdown=max_dd,
            deflated_sharpe=dsr,
            n_trades=len(fills),
            hit_rate=float((rets_eq > 0).mean()) if len(rets_eq) else 0.0,
        )
        crypto_rep: dict | None = None
        if self.crypto_risk_adapter is not None and wdf.shape[0] > 0:
            last_w = wdf.iloc[-1].to_dict()
            last_w = {k: float(v) for k, v in last_w.items() if k in symbols}
            if sum(last_w.values()) > 0.5:
                try:
                    crypto_rep = self.crypto_risk_adapter.portfolio_report(last_w)
                except Exception:
                    crypto_rep = None

        return StrategyReport(
            equity_curve=equity,
            weights_history=wdf,
            predictions_history=pdf,
            regime_history=rdf,
            arm_history=adf,
            fills=fills,
            rejections=rejections,
            drawdown_history=dd,
            metrics=metrics,
            deflated_sharpe=dsr,
            crypto_risk_report=crypto_rep,
            config=self.cfg,
        )


def quick_strategy(
    prices: pd.DataFrame,
    *,
    symbols: tuple[str, ...] | None = None,
    use_crypto_risk: bool = True,
    **overrides: Any,
) -> StrategyReport:
    """one-shot helper that fits and runs the strategy on `prices`."""
    syms = symbols or tuple(prices.columns)
    cfg = StrategyConfig(symbols=syms, use_crypto_risk_adapter=use_crypto_risk, **overrides)
    bt = StrategyBacktest(cfg)
    bt.fit(prices)
    if use_crypto_risk:
        rets = np.log(prices / prices.shift(1)).dropna()
        bt.attach_crypto_risk(rets)
    return bt.run(prices)
