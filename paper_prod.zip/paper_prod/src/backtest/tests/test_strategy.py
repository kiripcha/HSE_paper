"""end-to-end strategy backtest tests."""

from __future__ import annotations

import warnings

import numpy as np
import pandas as pd
import pytest

from src.backtest import (
    StrategyBacktest,
    StrategyConfig,
    quick_strategy,
)
from src.models import ModelSpec

warnings.filterwarnings("ignore")


def _synthetic_prices(n: int = 500, seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = pd.date_range("2022-01-01", periods=n, freq="D")
    return pd.DataFrame(
        {
            "BTC": 100 * np.exp(np.cumsum(rng.normal(0.001, 0.02, n))),
            "ETH": 100 * np.exp(np.cumsum(rng.normal(0.0005, 0.025, n))),
            "SOL": 100 * np.exp(np.cumsum(rng.normal(0.0002, 0.03, n))),
            "BNB": 100 * np.exp(np.cumsum(rng.normal(0.0003, 0.022, n))),
        },
        index=dates,
    )


@pytest.fixture(scope="module")
def prices() -> pd.DataFrame:
    return _synthetic_prices(n=500, seed=0)


def test_strategy_runs_end_to_end(prices: pd.DataFrame) -> None:
    cfg = StrategyConfig(
        symbols=tuple(prices.columns),
        rebalance_every_days=5,
        train_fraction=0.4,
        model_specs=(
            ModelSpec(id="ridge", type="Ridge"),
            ModelSpec(id="lgbm", type="LightGBM"),
        ),
        use_crypto_risk_adapter=False,
    )
    bt = StrategyBacktest(cfg)
    bt.fit(prices)
    rep = bt.run(prices)
    assert len(rep.equity_curve) > 0
    assert rep.metrics.n_trades > 0
    assert rep.equity_curve.iloc[0] > 0
    assert (rep.equity_curve > 0).all()  # equity never goes non-positive


def test_strategy_determinism(prices: pd.DataFrame) -> None:
    """same inputs + same config → identical equity curve (modulo bandit RNG)."""
    cfg = StrategyConfig(
        symbols=tuple(prices.columns),
        rebalance_every_days=5,
        train_fraction=0.4,
        model_specs=(ModelSpec(id="ridge", type="Ridge"),),
        allocator="ucb1",  # deterministic given counts
        use_crypto_risk_adapter=False,
    )
    bt1 = StrategyBacktest(cfg)
    bt1.fit(prices)
    r1 = bt1.run(prices)
    bt2 = StrategyBacktest(cfg)
    bt2.fit(prices)
    r2 = bt2.run(prices)
    assert np.allclose(r1.equity_curve.values, r2.equity_curve.values, atol=1e-6)


@pytest.mark.parametrize("optimizer", ["hrp", "risk_parity", "markowitz"])
def test_optimizer_swap_does_not_break(prices: pd.DataFrame, optimizer: str) -> None:
    cfg = StrategyConfig(
        symbols=tuple(prices.columns),
        rebalance_every_days=10,
        train_fraction=0.4,
        model_specs=(ModelSpec(id="ridge", type="Ridge"),),
        optimizer=optimizer,  # type: ignore[arg-type]
        use_crypto_risk_adapter=False,
    )
    bt = StrategyBacktest(cfg)
    bt.fit(prices)
    rep = bt.run(prices)
    assert len(rep.equity_curve) > 0


@pytest.mark.parametrize("allocator", ["eps_greedy", "ucb1", "thompson", "linucb"])
def test_allocator_swap_does_not_break(prices: pd.DataFrame, allocator: str) -> None:
    cfg = StrategyConfig(
        symbols=tuple(prices.columns),
        rebalance_every_days=10,
        train_fraction=0.4,
        model_specs=(
            ModelSpec(id="ridge", type="Ridge"),
            ModelSpec(id="lgbm", type="LightGBM"),
        ),
        allocator=allocator,  # type: ignore[arg-type]
        use_crypto_risk_adapter=False,
    )
    bt = StrategyBacktest(cfg)
    bt.fit(prices)
    rep = bt.run(prices)
    assert len(rep.equity_curve) > 0
    assert rep.arm_history.shape[0] > 0


@pytest.mark.parametrize("detector", ["vol_cluster", "hmm", "bocpd"])
def test_regime_detector_swap_does_not_break(
    prices: pd.DataFrame, detector: str
) -> None:
    cfg = StrategyConfig(
        symbols=tuple(prices.columns),
        rebalance_every_days=10,
        train_fraction=0.4,
        model_specs=(ModelSpec(id="ridge", type="Ridge"),),
        regime_detector=detector,  # type: ignore[arg-type]
        use_crypto_risk_adapter=False,
    )
    bt = StrategyBacktest(cfg)
    bt.fit(prices)
    rep = bt.run(prices)
    assert len(rep.regime_history) > 0


def test_strategy_with_crypto_risk_adapter(prices: pd.DataFrame) -> None:
    """when the crypto_risk adapter is enabled, the report carries a portfolio_report."""
    cfg = StrategyConfig(
        symbols=tuple(prices.columns),
        rebalance_every_days=10,
        train_fraction=0.4,
        model_specs=(ModelSpec(id="ridge", type="Ridge"),),
        use_crypto_risk_adapter=True,
    )
    rep = quick_strategy(prices, use_crypto_risk=True, **{
        "rebalance_every_days": 10,
        "train_fraction": 0.4,
        "model_specs": cfg.model_specs,
    })
    assert len(rep.equity_curve) > 0


def test_quick_strategy_helper(prices: pd.DataFrame) -> None:
    rep = quick_strategy(
        prices,
        use_crypto_risk=False,
        rebalance_every_days=10,
        model_specs=(ModelSpec(id="ridge", type="Ridge"),),
    )
    assert rep.config is not None
    assert rep.config.symbols == tuple(prices.columns)


def test_too_short_data_raises(prices: pd.DataFrame) -> None:
    short = prices.iloc[:100]
    cfg = StrategyConfig(
        symbols=tuple(short.columns),
        lookback_days=60,
        target_horizon_days=20,
        train_fraction=0.5,
        model_specs=(ModelSpec(id="ridge", type="Ridge"),),
        use_crypto_risk_adapter=False,
    )
    bt = StrategyBacktest(cfg)
    with pytest.raises(RuntimeError):
        bt.fit(short)
