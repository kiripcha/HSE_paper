"""tests for backtest engine and fill simulators."""

from __future__ import annotations

import numpy as np
import pytest

from src.backtest import (
    BacktestConfig,
    QueueAwareFillSimulator,
    SimpleFillSimulator,
    compute_metrics,
    run_simple_backtest,
    square_root_impact_bps,
)
from src.execution.io_schemas import ChildOrder
from src.market_data.io_schemas import BookLevel, BookSnapshot


def _book(mid: float = 100.0, spread: float = 1.0, depth: int = 5, qty: float = 1.0) -> BookSnapshot:
    bids = tuple(BookLevel(price=mid - spread / 2 - i, quantity=qty) for i in range(depth))
    asks = tuple(BookLevel(price=mid + spread / 2 + i, quantity=qty) for i in range(depth))
    return BookSnapshot(bids=bids, asks=asks)


def test_simple_fill_simulator_mid_price() -> None:
    sim = SimpleFillSimulator()
    order = ChildOrder(
        client_order_id="1", exchange="X", symbol="A", side="buy",
        order_type="market", quantity=1.0,
    )
    fill = sim.fill(order, _book(mid=100.0))
    assert fill is not None
    assert fill.price == pytest.approx(100.0)


def test_queue_aware_market_walks_book() -> None:
    sim = QueueAwareFillSimulator(latency_ns=0, slippage_c=0.0)
    book = _book(mid=100.0, depth=5, qty=1.0)
    order = ChildOrder(
        client_order_id="1", exchange="X", symbol="A", side="buy",
        order_type="market", quantity=3.0,
    )
    fill = sim.fill(order, book)
    assert fill is not None
    # walked first 3 ask levels: prices 100.5, 101.5, 102.5; avg = 101.5
    assert fill.price == pytest.approx(101.5)
    assert fill.quantity == pytest.approx(3.0)


def test_queue_aware_limit_crosses() -> None:
    sim = QueueAwareFillSimulator(latency_ns=0)
    book = _book(mid=100.0)
    # aggressive buy limit at 105 should cross and fill at ask
    order = ChildOrder(
        client_order_id="1", exchange="X", symbol="A", side="buy",
        order_type="limit", quantity=0.5, price=105.0,
    )
    fill = sim.fill(order, book)
    assert fill is not None
    assert fill.price == pytest.approx(book.asks[0].price)


def test_queue_aware_limit_non_crossing_no_fill() -> None:
    sim = QueueAwareFillSimulator(latency_ns=0)
    book = _book(mid=100.0)
    order = ChildOrder(
        client_order_id="1", exchange="X", symbol="A", side="buy",
        order_type="limit", quantity=0.5, price=90.0,
    )
    assert sim.fill(order, book) is None


def test_square_root_impact_increasing_with_qty() -> None:
    a = square_root_impact_bps(1, 100)
    b = square_root_impact_bps(10, 100)
    assert b > a


def test_simple_backtest_smoke() -> None:
    n = 200
    ts = np.arange(n, dtype=np.int64) * 60_000_000_000
    rng = np.random.default_rng(0)
    prices = {
        "A": 100.0 * np.exp(np.cumsum(rng.normal(0.001, 0.01, n))),
        "B": 100.0 * np.exp(np.cumsum(rng.normal(0.0, 0.012, n))),
    }
    books = {
        s: [_book(mid=prices[s][t], spread=0.5, depth=5, qty=5.0) for t in range(n)]
        for s in prices
    }
    # constant weights
    weights_series = [{"A": 0.5, "B": 0.5} for _ in range(n)]
    report = run_simple_backtest(
        ts, prices, books, weights_series, BacktestConfig(initial_capital=10_000.0),
    )
    assert len(report.equity_curve) == n
    assert report.equity_curve[0] == pytest.approx(10_000.0, rel=1e-3)
    assert report.metrics.n_trades > 0


def test_compute_metrics_zero_returns() -> None:
    eq = np.full(100, 100.0)
    rets = np.zeros(99)
    m = compute_metrics(rets, eq, n_fills=0)
    assert m.max_drawdown == 0.0


def test_backtest_determinism() -> None:
    """same inputs + same seed → same equity curve."""
    n = 100
    ts = np.arange(n, dtype=np.int64) * 60_000_000_000
    rng = np.random.default_rng(0)
    prices = {"A": 100.0 * np.exp(np.cumsum(rng.normal(0.0, 0.01, n)))}
    books = {"A": [_book(mid=prices["A"][t], spread=0.5, depth=5, qty=5.0) for t in range(n)]}
    weights = [{"A": 1.0} for _ in range(n)]
    r1 = run_simple_backtest(ts, prices, books, weights, BacktestConfig(seed=42))
    r2 = run_simple_backtest(ts, prices, books, weights, BacktestConfig(seed=42))
    assert np.array_equal(r1.equity_curve, r2.equity_curve)
