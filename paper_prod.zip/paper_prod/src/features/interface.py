"""public protocols for the features module."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

import polars as pl

from src.market_data.interface import OrderBookProtocol
from src.market_data.io_schemas import MarketEvent

from .io_schemas import FeatureVector


@runtime_checkable
class Feature(Protocol):
    """a single online incremental feature."""

    name: str
    config_hash: str
    warmup_complete: bool

    def update(self, event: MarketEvent, book: OrderBookProtocol | None) -> None: ...
    def value(self) -> float: ...


@runtime_checkable
class FeaturePipelineProtocol(Protocol):
    """composition of features. Produces FeatureVector or None during warmup."""

    features: list[Feature]
    names: tuple[str, ...]
    config_hash: str

    def update(
        self, event: MarketEvent, book: OrderBookProtocol | None
    ) -> FeatureVector | None: ...

    def batch_compute(self, events: list[MarketEvent]) -> pl.DataFrame: ...
