"""features — incremental feature engineering with train/serve parity.
"""

from ._internal.features import (
    MACD,
    OFI,
    RSI,
    BollingerWidth,
    Imbalance,
    LogReturn,
    MicroPrice,
    RealizedVol,
)
from ._internal.pipeline import FeaturePipeline
from .config import FeaturesConfig, FeatureSpec
from .interface import Feature, FeaturePipelineProtocol
from .io_schemas import FeatureVector, compute_config_hash

__all__ = [
    "FeatureVector",
    "FeaturePipeline",
    "FeaturePipelineProtocol",
    "Feature",
    "FeaturesConfig",
    "FeatureSpec",
    "compute_config_hash",
    "MicroPrice",
    "Imbalance",
    "OFI",
    "LogReturn",
    "RealizedVol",
    "RSI",
    "MACD",
    "BollingerWidth",
]
