"""incremental online feature implementations.
"""

from __future__ import annotations

import math
from collections import deque

from src.market_data.interface import OrderBookProtocol
from src.market_data.io_schemas import BBO, BookSnapshot, MarketEvent, Trade


def _book_top(book: OrderBookProtocol | None, event: MarketEvent) -> tuple[float, float, float, float] | None:
    """return (bid_price, bid_qty, ask_price, ask_qty) if known, else None."""
    if event.event_type == "bbo" and isinstance(event.payload, BBO):
        p = event.payload
        return p.bid_price, p.bid_qty, p.ask_price, p.ask_qty
    if book is not None and book.is_ready:
        snap = book.snapshot(1)
        if snap.bids and snap.asks:
            return (
                snap.bids[0].price,
                snap.bids[0].quantity,
                snap.asks[0].price,
                snap.asks[0].quantity,
            )
    return None


class MicroPrice:
    """stoikov micro-price: p_b * q_a / (q_a + q_b) + p_a * q_b / (q_a + q_b)."""

    def __init__(self) -> None:
        self.name = "micro_price"
        self.config_hash = "micro_price"
        self._value = math.nan
        self.warmup_complete = False

    def update(self, event: MarketEvent, book: OrderBookProtocol | None) -> None:
        top = _book_top(book, event)
        if top is None:
            return
        pb, qb, pa, qa = top
        total = qb + qa
        if total <= 0:
            return
        self._value = pb * qa / total + pa * qb / total
        self.warmup_complete = True

    def value(self) -> float:
        return self._value


class Imbalance:
    """top-N volume imbalance: (sum_bid - sum_ask) / (sum_bid + sum_ask)."""

    def __init__(self, levels: int = 1) -> None:
        self.levels = levels
        self.name = f"imb_{levels}"
        self.config_hash = f"imb_l{levels}"
        self._value = math.nan
        self.warmup_complete = False

    def update(self, event: MarketEvent, book: OrderBookProtocol | None) -> None:
        if book is None or not book.is_ready:
            return
        snap = book.snapshot(self.levels)
        if not snap.bids or not snap.asks:
            return
        bid_v = sum(b.quantity for b in snap.bids[: self.levels])
        ask_v = sum(a.quantity for a in snap.asks[: self.levels])
        total = bid_v + ask_v
        if total <= 0:
            return
        self._value = (bid_v - ask_v) / total
        self.warmup_complete = True

    def value(self) -> float:
        return self._value


class OFI:
    """order Flow Imbalance over a sliding window of book updates."""

    def __init__(self, window: int = 100) -> None:
        self.name = f"ofi_{window}"
        self.config_hash = f"ofi_w{window}"
        self.window = window
        self._buf: deque[float] = deque(maxlen=window)
        self._prev: tuple[float, float, float, float] | None = None
        self.warmup_complete = False

    def update(self, event: MarketEvent, book: OrderBookProtocol | None) -> None:
        top = _book_top(book, event)
        if top is None:
            return
        if self._prev is None:
            self._prev = top
            return
        pb, qb, pa, qa = top
        ppb, pqb, ppa, pqa = self._prev
        e_bid = 0.0
        if pb > ppb:
            e_bid = qb
        elif pb == ppb:
            e_bid = qb - pqb
        else:
            e_bid = -pqb
        e_ask = 0.0
        if pa < ppa:
            e_ask = qa
        elif pa == ppa:
            e_ask = qa - pqa
        else:
            e_ask = -pqa
        self._buf.append(e_bid - e_ask)
        self._prev = top
        if len(self._buf) >= self.window:
            self.warmup_complete = True

    def value(self) -> float:
        if not self._buf:
            return math.nan
        return float(sum(self._buf))


class LogReturn:
    """log return between consecutive mid-prices over `lag` events."""

    def __init__(self, lag: int = 1) -> None:
        self.name = f"logret_{lag}"
        self.config_hash = f"logret_l{lag}"
        self.lag = lag
        self._buf: deque[float] = deque(maxlen=lag + 1)
        self._value = math.nan
        self.warmup_complete = False

    def update(self, event: MarketEvent, book: OrderBookProtocol | None) -> None:
        top = _book_top(book, event)
        if top is None:
            return
        pb, _, pa, _ = top
        mid = (pb + pa) / 2.0
        self._buf.append(mid)
        if len(self._buf) >= self.lag + 1:
            old = self._buf[0]
            if old > 0 and mid > 0:
                self._value = math.log(mid / old)
                self.warmup_complete = True

    def value(self) -> float:
        return self._value


class RealizedVol:
    """rolling stdev of log returns over `window` updates."""

    def __init__(self, window: int = 60) -> None:
        self.name = f"rv_{window}"
        self.config_hash = f"rv_w{window}"
        self.window = window
        self._mids: deque[float] = deque(maxlen=window + 1)
        self._value = math.nan
        self.warmup_complete = False

    def update(self, event: MarketEvent, book: OrderBookProtocol | None) -> None:
        top = _book_top(book, event)
        if top is None:
            return
        pb, _, pa, _ = top
        mid = (pb + pa) / 2.0
        self._mids.append(mid)
        if len(self._mids) < 2:
            return
        # log returns over the buffer
        rets: list[float] = []
        prev = self._mids[0]
        for m in list(self._mids)[1:]:
            if prev > 0 and m > 0:
                rets.append(math.log(m / prev))
            prev = m
        if not rets:
            return
        mean = sum(rets) / len(rets)
        var = sum((r - mean) ** 2 for r in rets) / max(1, len(rets) - 1)
        self._value = math.sqrt(var)
        self.warmup_complete = len(self._mids) > self.window

    def value(self) -> float:
        return self._value


class RSI:
    """wilder's RSI computed incrementally on mid-price changes."""

    def __init__(self, period: int = 14) -> None:
        self.name = f"rsi_{period}"
        self.config_hash = f"rsi_p{period}"
        self.period = period
        self._prev_mid: float | None = None
        self._avg_gain: float | None = None
        self._avg_loss: float | None = None
        self._n_updates = 0
        self._gain_sum = 0.0
        self._loss_sum = 0.0
        self._value = math.nan
        self.warmup_complete = False

    def update(self, event: MarketEvent, book: OrderBookProtocol | None) -> None:
        top = _book_top(book, event)
        if top is None:
            return
        pb, _, pa, _ = top
        mid = (pb + pa) / 2.0
        if self._prev_mid is None:
            self._prev_mid = mid
            return
        change = mid - self._prev_mid
        gain = max(change, 0.0)
        loss = max(-change, 0.0)
        self._prev_mid = mid
        self._n_updates += 1
        if self._n_updates <= self.period:
            self._gain_sum += gain
            self._loss_sum += loss
            if self._n_updates == self.period:
                self._avg_gain = self._gain_sum / self.period
                self._avg_loss = self._loss_sum / self.period
                self._update_rsi()
                self.warmup_complete = True
        else:
            assert self._avg_gain is not None and self._avg_loss is not None
            self._avg_gain = (self._avg_gain * (self.period - 1) + gain) / self.period
            self._avg_loss = (self._avg_loss * (self.period - 1) + loss) / self.period
            self._update_rsi()

    def _update_rsi(self) -> None:
        assert self._avg_gain is not None and self._avg_loss is not None
        if self._avg_loss == 0:
            self._value = 100.0
        else:
            rs = self._avg_gain / self._avg_loss
            self._value = 100.0 - 100.0 / (1.0 + rs)

    def value(self) -> float:
        return self._value


class MACD:
    """MACD = EMA(fast) - EMA(slow). Output: the diff (not the signal line)."""

    def __init__(self, fast: int = 12, slow: int = 26) -> None:
        self.name = f"macd_{fast}_{slow}"
        self.config_hash = f"macd_f{fast}_s{slow}"
        self.fast = fast
        self.slow = slow
        self._k_fast = 2.0 / (fast + 1)
        self._k_slow = 2.0 / (slow + 1)
        self._ema_fast: float | None = None
        self._ema_slow: float | None = None
        self._n = 0
        self._value = math.nan
        self.warmup_complete = False

    def update(self, event: MarketEvent, book: OrderBookProtocol | None) -> None:
        top = _book_top(book, event)
        if top is None:
            return
        pb, _, pa, _ = top
        mid = (pb + pa) / 2.0
        if self._ema_fast is None:
            self._ema_fast = mid
            self._ema_slow = mid
        else:
            self._ema_fast = self._k_fast * mid + (1 - self._k_fast) * self._ema_fast
            assert self._ema_slow is not None
            self._ema_slow = self._k_slow * mid + (1 - self._k_slow) * self._ema_slow
        self._n += 1
        if self._n >= self.slow:
            self.warmup_complete = True
            assert self._ema_fast is not None and self._ema_slow is not None
            self._value = self._ema_fast - self._ema_slow

    def value(self) -> float:
        return self._value


class BollingerWidth:
    """bollinger band width: 2 * std / mean over a rolling window of mids."""

    def __init__(self, window: int = 20) -> None:
        self.name = f"bbw_{window}"
        self.config_hash = f"bbw_w{window}"
        self.window = window
        self._buf: deque[float] = deque(maxlen=window)
        self._value = math.nan
        self.warmup_complete = False

    def update(self, event: MarketEvent, book: OrderBookProtocol | None) -> None:
        top = _book_top(book, event)
        if top is None:
            return
        pb, _, pa, _ = top
        mid = (pb + pa) / 2.0
        self._buf.append(mid)
        if len(self._buf) < self.window:
            return
        mean = sum(self._buf) / len(self._buf)
        var = sum((x - mean) ** 2 for x in self._buf) / (len(self._buf) - 1)
        std = math.sqrt(var)
        self._value = 2 * std / mean if mean > 0 else math.nan
        self.warmup_complete = True

    def value(self) -> float:
        return self._value
