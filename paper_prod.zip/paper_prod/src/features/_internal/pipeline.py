"""FeaturePipeline — composition of incremental features with train/serve parity.
"""

from __future__ import annotations

import numpy as np
import polars as pl

from src.market_data import SortedBook
from src.market_data.interface import OrderBookProtocol
from src.market_data.io_schemas import MarketEvent

from ..config import FeatureSpec, FeaturesConfig
from ..io_schemas import FeatureVector, compute_config_hash
from .features import (
    MACD,
    OFI,
    RSI,
    BollingerWidth,
    Imbalance,
    LogReturn,
    MicroPrice,
    RealizedVol,
)


def _build_feature(spec: FeatureSpec):
    """construct a feature instance from a spec."""
    params = spec.model_dump(exclude={"type"})
    if spec.type == "MicroPrice":
        return MicroPrice()
    if spec.type == "Imbalance":
        return Imbalance(levels=params.get("levels", 1))
    if spec.type == "OFI":
        return OFI(window=params.get("window", 100))
    if spec.type == "LogReturn":
        return LogReturn(lag=params.get("lag", 1))
    if spec.type == "RealizedVol":
        return RealizedVol(window=params.get("window", 60))
    if spec.type == "RSI":
        return RSI(period=params.get("period", 14))
    if spec.type == "MACD":
        return MACD(fast=params.get("fast", 12), slow=params.get("slow", 26))
    if spec.type == "BollingerWidth":
        return BollingerWidth(window=params.get("window", 20))
    raise ValueError(f"unknown feature type: {spec.type}")


class FeaturePipeline:
    """composes multiple features. Updates them in fixed order on each event."""

    def __init__(self, config: FeaturesConfig) -> None:
        self.config = config
        self.features = [_build_feature(spec) for spec in config.features]
        self.names: tuple[str, ...] = tuple(f.name for f in self.features)
        self.config_hash = compute_config_hash(
            [spec.model_dump() for spec in config.features]
        )

    def update(
        self, event: MarketEvent, book: OrderBookProtocol | None
    ) -> FeatureVector | None:
        for f in self.features:
            f.update(event, book)
        if not all(f.warmup_complete for f in self.features):
            return None
        values = np.array([f.value() for f in self.features], dtype=np.float64)
        return FeatureVector(
            ts_ns=event.ts_exchange_ns,
            symbol=event.symbol,
            values=values,
            names=self.names,
            config_hash=self.config_hash,
        )

    def batch_compute(self, events: list[MarketEvent]) -> pl.DataFrame:
        """replay events sequentially through update(); materialize results."""
        # reset state so multiple batch_compute calls are independent.
        self.features = [_build_feature(spec) for spec in self.config.features]
        book = SortedBook(events[0].symbol if events else "?")
        rows: list[dict] = []
        for ev in events:
            book.apply(ev)
            fv = self.update(ev, book)
            if fv is None:
                continue
            row = {"ts_ns": fv.ts_ns, "symbol": fv.symbol}
            for n, v in zip(fv.names, fv.values.tolist(), strict=True):
                row[n] = v
            rows.append(row)
        return pl.DataFrame(rows) if rows else pl.DataFrame()
