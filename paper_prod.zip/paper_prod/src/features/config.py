"""pydantic configs for the features module."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

FeatureType = Literal[
    "MicroPrice",
    "Imbalance",
    "OFI",
    "RealizedVol",
    "RSI",
    "MACD",
    "LogReturn",
    "BollingerWidth",
]


class FeatureSpec(BaseModel):
    """single feature specification (type + params)."""

    model_config = ConfigDict(frozen=True, extra="allow")

    type: FeatureType
    # additional params live as extra fields (allowed by extra='allow')


class FeaturesConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    features: list[FeatureSpec] = Field(default_factory=list)
