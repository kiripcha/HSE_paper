"""train/serve parity: online (`update`) and batch (`batch_compute`) must agree."""

from __future__ import annotations

import numpy as np

from src.features import FeaturePipeline, FeaturesConfig, FeatureSpec
from src.market_data import SortedBook, random_walk_deltas


def _config() -> FeaturesConfig:
    return FeaturesConfig(
        features=[
            FeatureSpec(type="MicroPrice"),
            FeatureSpec(type="Imbalance", levels=1),
            FeatureSpec(type="LogReturn", lag=1),
            FeatureSpec(type="RealizedVol", window=20),
            FeatureSpec(type="RSI", period=14),
            FeatureSpec(type="MACD", fast=12, slow=26),
            FeatureSpec(type="BollingerWidth", window=20),
            FeatureSpec(type="OFI", window=30),
        ]
    )


def test_train_serve_parity() -> None:
    cfg = _config()
    events = list(random_walk_deltas(seed=42, n=500))

    # streaming
    pipe = FeaturePipeline(cfg)
    book = SortedBook("BTCUSDT")
    stream_rows: list[dict] = []
    for ev in events:
        book.apply(ev)
        fv = pipe.update(ev, book)
        if fv is None:
            continue
        stream_rows.append({"ts_ns": fv.ts_ns, **dict(zip(fv.names, fv.values.tolist()))})

    # batch (uses new pipeline instance — resets state)
    pipe2 = FeaturePipeline(cfg)
    batch_df = pipe2.batch_compute(events)

    assert len(stream_rows) == batch_df.height
    for i, row in enumerate(stream_rows):
        for name in pipe.names:
            stream_val = row[name]
            batch_val = batch_df[name][i]
            if np.isnan(stream_val) and np.isnan(batch_val):
                continue
            assert stream_val == batch_val, f"row {i} feature {name}: {stream_val} != {batch_val}"


def test_config_hash_changes_with_params() -> None:
    a = FeaturePipeline(FeaturesConfig(features=[FeatureSpec(type="RSI", period=14)]))
    b = FeaturePipeline(FeaturesConfig(features=[FeatureSpec(type="RSI", period=21)]))
    c = FeaturePipeline(FeaturesConfig(features=[FeatureSpec(type="RSI", period=14)]))
    assert a.config_hash != b.config_hash
    assert a.config_hash == c.config_hash


def test_pipeline_returns_none_during_warmup() -> None:
    cfg = FeaturesConfig(features=[FeatureSpec(type="RealizedVol", window=100)])
    pipe = FeaturePipeline(cfg)
    events = list(random_walk_deltas(seed=1, n=10))
    book = SortedBook("BTCUSDT")
    for ev in events:
        book.apply(ev)
        out = pipe.update(ev, book)
        assert out is None  # warmup not done with window=100 and n=10
