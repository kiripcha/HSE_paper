"""tests for individual incremental features."""

from __future__ import annotations

import math

import pytest

from src.features import (
    MACD,
    OFI,
    RSI,
    BollingerWidth,
    Imbalance,
    LogReturn,
    MicroPrice,
    RealizedVol,
)
from src.market_data import SortedBook, random_walk_deltas
from src.market_data.io_schemas import BBO, MarketEvent


def _walk_events(seed: int = 1, n: int = 500):
    return list(random_walk_deltas(seed=seed, n=n))


def _apply(book: SortedBook, feature, events):
    for ev in events:
        book.apply(ev)
        feature.update(ev, book)


def test_micro_price_in_spread() -> None:
    book = SortedBook("BTCUSDT")
    feat = MicroPrice()
    _apply(book, feat, _walk_events(n=100))
    assert feat.warmup_complete
    v = feat.value()
    bid, ask = book.best_bid_ask
    assert bid <= v <= ask


def test_imbalance_bounded() -> None:
    book = SortedBook("BTCUSDT")
    feat = Imbalance(levels=5)
    _apply(book, feat, _walk_events(n=200))
    if feat.warmup_complete:
        v = feat.value()
        assert -1.0 <= v <= 1.0


def test_ofi_emits_after_warmup() -> None:
    book = SortedBook("BTCUSDT")
    feat = OFI(window=50)
    _apply(book, feat, _walk_events(n=200))
    assert feat.warmup_complete
    assert math.isfinite(feat.value())


def test_log_return_lag() -> None:
    book = SortedBook("BTCUSDT")
    feat = LogReturn(lag=10)
    _apply(book, feat, _walk_events(n=200))
    assert feat.warmup_complete
    assert math.isfinite(feat.value())


def test_realized_vol_positive() -> None:
    book = SortedBook("BTCUSDT")
    feat = RealizedVol(window=50)
    _apply(book, feat, _walk_events(n=200))
    assert feat.warmup_complete
    assert feat.value() >= 0


def test_rsi_in_range() -> None:
    book = SortedBook("BTCUSDT")
    feat = RSI(period=14)
    _apply(book, feat, _walk_events(n=200))
    assert feat.warmup_complete
    v = feat.value()
    assert 0.0 <= v <= 100.0


def test_macd_finite() -> None:
    book = SortedBook("BTCUSDT")
    feat = MACD(fast=12, slow=26)
    _apply(book, feat, _walk_events(n=200))
    assert feat.warmup_complete
    assert math.isfinite(feat.value())


def test_bollinger_width_positive() -> None:
    book = SortedBook("BTCUSDT")
    feat = BollingerWidth(window=30)
    _apply(book, feat, _walk_events(n=200))
    assert feat.warmup_complete
    assert feat.value() >= 0


def test_bbo_event_drives_features_without_book() -> None:
    """MicroPrice should work directly off BBO without needing the book."""
    feat = MicroPrice()
    ev = MarketEvent(
        exchange="binance",
        symbol="BTCUSDT",
        ts_exchange_ns=1,
        ts_local_ns=1,
        event_type="bbo",
        seq=1,
        payload=BBO(bid_price=100.0, bid_qty=2.0, ask_price=101.0, ask_qty=1.0),
    )
    feat.update(ev, None)
    assert feat.warmup_complete
    # heavy bid side pulls micro-price toward ask
    v = feat.value()
    assert 100.0 < v < 101.0
    assert v > 100.5


@pytest.mark.parametrize("seed", [1, 7, 42, 100])
def test_deterministic(seed: int) -> None:
    """same events → same final value, by construction (no randomness in feature)."""
    e1 = _walk_events(seed=seed, n=300)
    b1, b2 = SortedBook("BTCUSDT"), SortedBook("BTCUSDT")
    f1, f2 = OFI(window=30), OFI(window=30)
    _apply(b1, f1, e1)
    _apply(b2, f2, e1)
    assert f1.value() == f2.value()
