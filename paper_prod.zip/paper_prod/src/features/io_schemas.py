"""schemas for the features module."""

from __future__ import annotations

import hashlib
from typing import Any

import numpy as np
from pydantic import BaseModel, ConfigDict, Field


class FeatureVector(BaseModel):
    """snapshot of feature values at a single point in time."""

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    ts_ns: int
    symbol: str
    values: np.ndarray = Field(...)
    names: tuple[str, ...]
    config_hash: str

    def as_dict(self) -> dict[str, float]:
        return dict(zip(self.names, self.values.tolist(), strict=True))


def compute_config_hash(feature_specs: list[dict[str, Any]]) -> str:
    """stable hash of the feature pipeline configuration."""
    h = hashlib.sha256()
    for spec in feature_specs:
        items = sorted(spec.items())
        h.update(repr(items).encode())
    return h.hexdigest()[:16]
