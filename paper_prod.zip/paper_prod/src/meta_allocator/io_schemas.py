"""schemas for meta-allocator: aggregated signals and strategy weights."""

from __future__ import annotations

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from src.regime.io_schemas import RegimeState


class AllocatorContext(BaseModel):
    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    ts_ns: int
    regime_state: RegimeState | None = None
    recent_features: np.ndarray | None = None
    metadata: dict[str, float] = Field(default_factory=dict)


class AggregatedSignal(BaseModel):
    model_config = ConfigDict(frozen=True)

    ts_ns: int
    symbol: str
    mu: float
    sigma: float = 0.0
    direction_proba: float | None = None
    contributing_models: tuple[str, ...] = ()


class StrategyWeights(BaseModel):
    model_config = ConfigDict(frozen=True)

    ts_ns: int
    weights: dict[str, float]
    aggregated_signal: AggregatedSignal
    exploration_active: bool = False
