"""meta_allocator — adaptive strategy selection via multi-armed bandits.
"""

from ._internal.allocators import (
    EpsilonGreedyAllocator,
    LinUCBAllocator,
    ThompsonSamplingAllocator,
    UCB1Allocator,
)
from .io_schemas import AggregatedSignal, AllocatorContext, StrategyWeights

__all__ = [
    "AggregatedSignal",
    "AllocatorContext",
    "StrategyWeights",
    "EpsilonGreedyAllocator",
    "UCB1Allocator",
    "ThompsonSamplingAllocator",
    "LinUCBAllocator",
]
