"""smoke + regret tests for bandit allocators."""

from __future__ import annotations

import numpy as np
import pytest

from src.meta_allocator import (
    AllocatorContext,
    EpsilonGreedyAllocator,
    LinUCBAllocator,
    ThompsonSamplingAllocator,
    UCB1Allocator,
)
from src.models.io_schemas import Prediction
from src.regime.io_schemas import RegimeState


def _preds(arms):
    return [Prediction(model_id=a, ts_ns=0, symbol="X", mu=0.0) for a in arms]


def test_weights_sum_to_one_and_nonneg() -> None:
    arms = ["a", "b", "c"]
    for cls in (
        lambda: EpsilonGreedyAllocator(arms, eps=0.0),
        lambda: UCB1Allocator(arms),
        lambda: ThompsonSamplingAllocator(arms),
    ):
        alloc = cls()
        sw = alloc.allocate(_preds(arms))
        s = sum(sw.weights.values())
        assert s == pytest.approx(1.0, abs=1e-9)
        assert all(v >= 0 for v in sw.weights.values())


def test_eps_greedy_converges_to_best_arm() -> None:
    """in a stationary 2-arm bandit, ε-greedy with discount picks the better arm."""
    arms = ["good", "bad"]
    alloc = EpsilonGreedyAllocator(arms, eps=0.05, discount=0.99, seed=42)
    rng = np.random.default_rng(0)
    chosen = []
    for _ in range(1000):
        sw = alloc.allocate(_preds(arms))
        chosen.append(max(sw.weights, key=sw.weights.get))
        # rewards: good arm mean 1.0, bad arm mean 0.0
        for a in arms:
            if sw.weights[a] > 0:
                r = rng.normal(1.0 if a == "good" else 0.0, 0.5)
                alloc.update(a, r)
    # last 200 plays should mostly pick "good"
    assert chosen[-200:].count("good") > 150


def test_ucb1_regret_sublinear() -> None:
    arms = ["good", "bad"]
    alloc = UCB1Allocator(arms)
    rng = np.random.default_rng(1)
    regret = 0.0
    for t in range(500):
        sw = alloc.allocate(_preds(arms))
        chosen = max(sw.weights, key=sw.weights.get)
        true_mean = 1.0 if chosen == "good" else 0.0
        r = rng.normal(true_mean, 0.3)
        alloc.update(chosen, r)
        regret += 1.0 - true_mean
    # regret growth should be sublinear; 500*1=500 would be worst-case
    assert regret < 100


def test_thompson_sampling_smoke() -> None:
    arms = ["a", "b", "c"]
    alloc = ThompsonSamplingAllocator(arms, seed=0)
    rng = np.random.default_rng(0)
    for _ in range(200):
        sw = alloc.allocate(_preds(arms))
        choice = max(sw.weights, key=sw.weights.get)
        # arm "a" is best
        r = rng.normal({"a": 1.0, "b": 0.0, "c": 0.0}[choice], 0.5)
        alloc.update(choice, r)
    # posterior_mu for "a" should be highest
    assert alloc.posterior_mu["a"] > alloc.posterior_mu["b"]


def test_linucb_uses_context() -> None:
    arms = ["a", "b"]
    alloc = LinUCBAllocator(arms, context_dim=3, alpha=0.5)
    rng = np.random.default_rng(0)

    def mk_ctx(regime_id: int) -> AllocatorContext:
        probs = np.zeros(3); probs[regime_id] = 1.0
        return AllocatorContext(
            ts_ns=0,
            regime_state=RegimeState(
                ts_ns=0, symbol="X", regime_id=regime_id, probabilities=probs,
            ),
        )

    # arm a is best in regime 0; arm b in regime 1
    for _ in range(500):
        regime = int(rng.integers(0, 2))
        ctx = mk_ctx(regime)
        sw = alloc.allocate(_preds(arms), context=ctx)
        chosen = max(sw.weights, key=sw.weights.get)
        if regime == 0:
            r = 1.0 if chosen == "a" else 0.0
        else:
            r = 1.0 if chosen == "b" else 0.0
        r += rng.normal(0, 0.1)
        alloc.update(chosen, r, context=ctx)
    # after training: in regime 0, allocator should pick "a"
    ctx0 = mk_ctx(0)
    sw0 = alloc.allocate(_preds(arms), context=ctx0)
    assert sw0.weights["a"] == 1.0
    ctx1 = mk_ctx(1)
    sw1 = alloc.allocate(_preds(arms), context=ctx1)
    assert sw1.weights["b"] == 1.0
