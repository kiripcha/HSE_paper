"""multi-armed bandit allocators for strategy/model selection."""

from __future__ import annotations

import math

import numpy as np

from src.models.io_schemas import Prediction

from ..io_schemas import AggregatedSignal, AllocatorContext, StrategyWeights


def _aggregate(
    predictions: list[Prediction], weights: dict[str, float]
) -> AggregatedSignal:
    if not predictions:
        return AggregatedSignal(ts_ns=0, symbol="?", mu=0.0)
    ts = predictions[0].ts_ns
    sym = predictions[0].symbol
    mus = np.array([p.mu for p in predictions])
    sigmas = np.array([p.sigma for p in predictions])
    w = np.array([weights.get(p.model_id, 0.0) for p in predictions])
    w_sum = w.sum()
    if w_sum > 0:
        w = w / w_sum
    mu = float((mus * w).sum())
    # variance ~ disagreement + per-model uncertainty
    disagreement = float(((mus - mu) ** 2 * w).sum())
    base_var = float((sigmas**2 * w).sum())
    sigma = math.sqrt(max(0.0, disagreement + base_var))
    return AggregatedSignal(
        ts_ns=ts,
        symbol=sym,
        mu=mu,
        sigma=sigma,
        contributing_models=tuple(p.model_id for p in predictions),
    )


class EpsilonGreedyAllocator:
    """ε-greedy with discounted rewards."""

    def __init__(
        self,
        arms: list[str],
        eps: float = 0.1,
        discount: float = 0.99,
        seed: int = 0,
    ) -> None:
        self.arms = arms
        self.n_arms = len(arms)
        self.eps = eps
        self.discount = discount
        self.rng = np.random.default_rng(seed)
        self.values = {a: 0.0 for a in arms}
        self.counts = {a: 0 for a in arms}

    def allocate(
        self,
        predictions: list[Prediction],
        context: AllocatorContext | None = None,
    ) -> StrategyWeights:
        exploration = False
        if self.rng.random() < self.eps:
            exploration = True
            choice = self.arms[self.rng.integers(0, self.n_arms)]
        else:
            choice = max(self.values, key=lambda k: self.values[k])
        weights = {a: 1.0 if a == choice else 0.0 for a in self.arms}
        return StrategyWeights(
            ts_ns=context.ts_ns if context else 0,
            weights=weights,
            aggregated_signal=_aggregate(predictions, weights),
            exploration_active=exploration,
        )

    def update(self, arm: str, reward: float, ts_ns: int = 0) -> None:
        self.values[arm] = self.discount * self.values[arm] + (1.0 - self.discount) * reward
        self.counts[arm] += 1

    def reset(self) -> None:
        self.values = {a: 0.0 for a in self.arms}
        self.counts = {a: 0 for a in self.arms}


class UCB1Allocator:
    """UCB1: A_t = argmax mu_a + sqrt(2 ln t / n_a)."""

    def __init__(self, arms: list[str]) -> None:
        self.arms = arms
        self.n_arms = len(arms)
        self.means = {a: 0.0 for a in arms}
        self.counts = {a: 0 for a in arms}
        self.t = 0

    def allocate(
        self,
        predictions: list[Prediction],
        context: AllocatorContext | None = None,
    ) -> StrategyWeights:
        self.t += 1
        # pull each arm at least once
        for a in self.arms:
            if self.counts[a] == 0:
                weights = {x: 1.0 if x == a else 0.0 for x in self.arms}
                return StrategyWeights(
                    ts_ns=context.ts_ns if context else 0,
                    weights=weights,
                    aggregated_signal=_aggregate(predictions, weights),
                    exploration_active=True,
                )
        ln_t = math.log(self.t)
        scores = {
            a: self.means[a] + math.sqrt(2 * ln_t / self.counts[a]) for a in self.arms
        }
        choice = max(scores, key=lambda k: scores[k])
        weights = {a: 1.0 if a == choice else 0.0 for a in self.arms}
        return StrategyWeights(
            ts_ns=context.ts_ns if context else 0,
            weights=weights,
            aggregated_signal=_aggregate(predictions, weights),
        )

    def update(self, arm: str, reward: float, ts_ns: int = 0) -> None:
        n = self.counts[arm]
        self.means[arm] = (self.means[arm] * n + reward) / (n + 1)
        self.counts[arm] += 1

    def reset(self) -> None:
        self.means = {a: 0.0 for a in self.arms}
        self.counts = {a: 0 for a in self.arms}
        self.t = 0


class ThompsonSamplingAllocator:
    """gaussian Thompson Sampling with sliding-window posterior."""

    def __init__(
        self,
        arms: list[str],
        prior_mu: float = 0.0,
        prior_sigma: float = 1.0,
        noise_sigma: float = 1.0,
        seed: int = 0,
    ) -> None:
        self.arms = arms
        self.n_arms = len(arms)
        self.prior_mu = prior_mu
        self.prior_sigma = prior_sigma
        self.noise_sigma = noise_sigma
        self.rng = np.random.default_rng(seed)
        self.posterior_mu = {a: prior_mu for a in arms}
        self.posterior_var = {a: prior_sigma**2 for a in arms}

    def allocate(
        self,
        predictions: list[Prediction],
        context: AllocatorContext | None = None,
    ) -> StrategyWeights:
        samples = {
            a: self.rng.normal(self.posterior_mu[a], math.sqrt(self.posterior_var[a]))
            for a in self.arms
        }
        choice = max(samples, key=lambda k: samples[k])
        weights = {a: 1.0 if a == choice else 0.0 for a in self.arms}
        return StrategyWeights(
            ts_ns=context.ts_ns if context else 0,
            weights=weights,
            aggregated_signal=_aggregate(predictions, weights),
            exploration_active=True,
        )

    def update(self, arm: str, reward: float, ts_ns: int = 0) -> None:
        # gaussian conjugate update
        prior_prec = 1.0 / max(1e-9, self.posterior_var[arm])
        noise_prec = 1.0 / max(1e-9, self.noise_sigma**2)
        post_prec = prior_prec + noise_prec
        post_var = 1.0 / post_prec
        post_mu = (prior_prec * self.posterior_mu[arm] + noise_prec * reward) / post_prec
        self.posterior_mu[arm] = post_mu
        self.posterior_var[arm] = post_var

    def reset(self) -> None:
        self.posterior_mu = {a: self.prior_mu for a in self.arms}
        self.posterior_var = {a: self.prior_sigma**2 for a in self.arms}


class LinUCBAllocator:
    """"""

    def __init__(self, arms: list[str], context_dim: int, alpha: float = 1.0) -> None:
        self.arms = arms
        self.n_arms = len(arms)
        self.alpha = alpha
        self.d = context_dim
        self.A = {a: np.eye(context_dim) for a in arms}
        self.b = {a: np.zeros(context_dim) for a in arms}

    def _make_ctx_vec(self, context: AllocatorContext | None) -> np.ndarray:
        if context is None or context.regime_state is None:
            return np.ones(self.d) / self.d
        probs = context.regime_state.probabilities
        if probs.size >= self.d:
            return probs[: self.d]
        v = np.zeros(self.d)
        v[: probs.size] = probs
        return v

    def allocate(
        self,
        predictions: list[Prediction],
        context: AllocatorContext | None = None,
    ) -> StrategyWeights:
        x = self._make_ctx_vec(context)
        scores: dict[str, float] = {}
        for a in self.arms:
            A_inv = np.linalg.inv(self.A[a])
            theta = A_inv @ self.b[a]
            ucb = float(x @ theta + self.alpha * math.sqrt(x @ A_inv @ x))
            scores[a] = ucb
        choice = max(scores, key=lambda k: scores[k])
        weights = {a: 1.0 if a == choice else 0.0 for a in self.arms}
        return StrategyWeights(
            ts_ns=context.ts_ns if context else 0,
            weights=weights,
            aggregated_signal=_aggregate(predictions, weights),
        )

    def update(
        self, arm: str, reward: float, context: AllocatorContext | None = None
    ) -> None:
        x = self._make_ctx_vec(context)
        self.A[arm] += np.outer(x, x)
        self.b[arm] += reward * x

    def reset(self) -> None:
        self.A = {a: np.eye(self.d) for a in self.arms}
        self.b = {a: np.zeros(self.d) for a in self.arms}
