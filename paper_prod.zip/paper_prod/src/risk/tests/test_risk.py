"""tests for risk gate, portfolio monitor, kill switch."""

from __future__ import annotations

import numpy as np

from src.execution.io_schemas import Fill
from src.portfolio.io_schemas import TargetWeights
from src.risk import (
    KillSwitch,
    PortfolioMonitor,
    RiskGate,
    RiskLimits,
    historical_cvar,
    historical_var,
    kupiec_pof_test,
    parametric_var,
)


def test_risk_gate_approves_within_limits() -> None:
    rg = RiskGate(RiskLimits(max_leverage=1.0, max_concentration_pct=0.5))
    tw = TargetWeights(ts_ns=1, weights={"A": 0.3, "B": 0.3, "C": 0.4})
    r = rg.validate(tw)
    assert r.approved


def test_risk_gate_rejects_over_leverage() -> None:
    rg = RiskGate(RiskLimits(max_leverage=1.0))
    tw = TargetWeights(ts_ns=1, weights={"A": 0.6, "B": 0.6})
    r = rg.validate(tw)
    assert not r.approved
    codes = [v.code for v in r.violations]
    assert "MAX_LEVERAGE" in codes


def test_risk_gate_rejects_concentration() -> None:
    rg = RiskGate(RiskLimits(max_concentration_pct=0.2))
    tw = TargetWeights(ts_ns=1, weights={"A": 0.5, "B": 0.5})
    r = rg.validate(tw)
    codes = [v.code for v in r.violations]
    assert "POSITION_CONCENTRATION" in codes


def test_kill_switch_blocks_validation() -> None:
    rg = RiskGate(kill_switch_active=True)
    tw = TargetWeights(ts_ns=1, weights={"A": 0.5})
    r = rg.validate(tw)
    assert not r.approved
    assert any(v.code == "KILL_SWITCH_ACTIVE" for v in r.violations)


def test_portfolio_monitor_realized_pnl() -> None:
    pm = PortfolioMonitor(starting_cash=10_000.0)
    # buy 1 @ 100, sell 1 @ 110 → realized pnl = 10
    pm.on_fill(Fill(ts_ns=1, symbol="A", side="buy", quantity=1.0, price=100.0))
    pm.on_fill(Fill(ts_ns=2, symbol="A", side="sell", quantity=1.0, price=110.0))
    assert pm.pnl_realized == 10.0


def test_portfolio_monitor_drawdown_tracking() -> None:
    pm = PortfolioMonitor(starting_cash=10_000.0)
    # take a loss
    pm.on_fill(Fill(ts_ns=1, symbol="A", side="buy", quantity=1.0, price=100.0))
    pm.on_market_data({"A": 90.0})  # price drops
    snap = pm.snapshot(ts_ns=2)
    assert snap.pnl_unrealized < 0


def test_historical_var_matches_quantile() -> None:
    rng = np.random.default_rng(0)
    rets = rng.normal(0, 0.02, 10_000)
    var = historical_var(rets, confidence=0.95)
    expected = -np.quantile(rets, 0.05)
    assert abs(var - expected) < 1e-9


def test_cvar_greater_than_var() -> None:
    rng = np.random.default_rng(0)
    rets = rng.normal(0, 0.02, 5000)
    v = historical_var(rets, 0.95)
    c = historical_cvar(rets, 0.95)
    assert c >= v  # tail expectation >= threshold


def test_kupiec_test_well_calibrated_var() -> None:
    """random normal returns + 5% VaR → ≈ 5% violations → high p-value."""
    rng = np.random.default_rng(0)
    n = 1000
    rets = rng.normal(0, 0.01, n)
    var = parametric_var(rets[:200], confidence=0.95)
    violations = int((rets[200:] < -var).sum())
    _, pval = kupiec_pof_test(violations, n - 200, confidence=0.95)
    assert pval > 0.05


def test_kill_switch_state() -> None:
    ks = KillSwitch()
    assert not ks.is_active()
    ks.trigger("drawdown limit")
    assert ks.is_active()
    assert ks.reason == "drawdown limit"
    ks.reset()
    assert not ks.is_active()
