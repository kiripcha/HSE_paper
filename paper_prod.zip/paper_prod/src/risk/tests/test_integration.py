"""integration tests for the bridge between src/risk and crypto_risk."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from src.portfolio.io_schemas import TargetWeights
from src.risk import (
    CryptoRiskAdapter,
    CryptoRiskAdapterConfig,
    TorchVolAdapter,
)


@pytest.fixture(scope="module")
def synthetic_returns() -> pd.DataFrame:
    """two years of daily returns for a small universe via crypto_risk's loader."""
    from crypto_risk.data import MultiSourceCryptoLoader

    universe = ("BTC", "ETH", "BNB", "SOL", "ADA")
    ld = MultiSourceCryptoLoader(universe, mode="synthetic")
    prices = ld.load_close_panel("2022-01-01", "2024-01-01")
    rets = np.log(prices / prices.shift(1)).dropna()
    return rets


def test_adapter_constructs_from_returns(synthetic_returns: pd.DataFrame) -> None:
    adapter = CryptoRiskAdapter.from_returns(synthetic_returns)
    assert adapter.engine.returns is not None
    assert adapter.engine.returns.shape[1] == synthetic_returns.shape[1]


def test_adapter_validate_target_approves_diversified(
    synthetic_returns: pd.DataFrame,
) -> None:
    adapter = CryptoRiskAdapter.from_returns(
        synthetic_returns,
        adapter_cfg=CryptoRiskAdapterConfig(max_var_budget_per_asset=0.30),
    )
    cols = list(synthetic_returns.columns)
    w = {c: 1.0 / len(cols) for c in cols}
    target = TargetWeights(ts_ns=1, weights=w)
    res = adapter.validate_target(target, current_drawdown=0.0)
    # with a generous budget (30%) the synthetic vol is below threshold
    assert isinstance(res.violations, tuple)


def test_adapter_portfolio_report_returns_serializable(
    synthetic_returns: pd.DataFrame,
) -> None:
    adapter = CryptoRiskAdapter.from_returns(synthetic_returns)
    cols = list(synthetic_returns.columns)
    w = {c: 1.0 / len(cols) for c in cols}
    rep = adapter.portfolio_report(w)
    assert "annualized_vol" in rep
    assert rep["annualized_vol"] > 0
    assert "portfolio_risk" in rep
    assert isinstance(rep["portfolio_risk"], list)
    # all VaR/ES values should be positive (crypto_risk convention)
    for row in rep["portfolio_risk"]:
        assert row["VaR_99"] >= 0
        assert row["ES_975"] >= 0


def test_adapter_tail_risk(synthetic_returns: pd.DataFrame) -> None:
    adapter = CryptoRiskAdapter.from_returns(synthetic_returns)
    cols = list(synthetic_returns.columns)
    w = {c: 1.0 / len(cols) for c in cols}
    tr = adapter.tail_risk(w, threshold_q=0.90, use_conditional=False)
    assert "pot" in tr
    if tr["pot"] is not None:
        assert tr["pot"]["var"] >= 0


def test_torch_vol_adapter_with_dummy_model() -> None:
    class _DummyModel:
        def predict_batch(self, X: np.ndarray) -> np.ndarray:
            return np.array([float(np.std(X[0]))])

    vol_adapter = TorchVolAdapter(_DummyModel(), lookback=30)
    rets = pd.Series(np.random.default_rng(0).normal(0, 0.01, 100))
    sigma = vol_adapter.predict(rets)
    assert sigma > 0


def test_adapter_skips_unknown_symbols(synthetic_returns: pd.DataFrame) -> None:
    """if TargetWeights references a symbol not in returns, it is skipped, not rejected."""
    adapter = CryptoRiskAdapter.from_returns(synthetic_returns)
    target = TargetWeights(ts_ns=1, weights={"BTC": 0.5, "UNKNOWN_COIN": 0.5})
    res = adapter.validate_target(target)
    # UNKNOWN_COIN doesn't trigger a hard violation by itself
    # — only known assets that fail the budget do
    assert isinstance(res.violations, tuple)


def test_dl_vol_hook_plumbing(synthetic_returns: pd.DataFrame) -> None:
    """attach_dl_vol_model wires through to crypto_risk's VolForecaster."""
    adapter = CryptoRiskAdapter.from_returns(synthetic_returns)
    captured: list[pd.Series] = []

    class _Capture:
        def predict(self, returns: pd.Series) -> float:
            captured.append(returns)
            return 0.0123

    adapter.attach_dl_vol_model(_Capture())
    forecast = adapter.engine.vol_forecaster.forecast(synthetic_returns["BTC"])
    assert forecast.source == "dl"
    assert abs(forecast.sigma_daily - 0.0123) < 1e-9
    assert len(captured) == 1
