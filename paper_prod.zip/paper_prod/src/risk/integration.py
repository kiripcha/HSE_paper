"""bridge between src/risk runtime layer and crypto_risk analytics package.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

import numpy as np
import pandas as pd

from src.portfolio.io_schemas import TargetWeights

from .io_schemas import RiskViolation, ValidationResult


class _VolModel(Protocol):
    """minimal interface for a DL volatility model that crypto_risk can call."""

    def predict(self, returns: pd.Series) -> float: ...


@dataclass
class CryptoRiskAdapterConfig:
    """adapter knobs (NOT a duplicate of crypto_risk's RiskConfig)."""

    use_for_pretrade: bool = True
    use_for_periodic_report: bool = True
    max_var_budget_per_asset: float = 0.10
    max_participation_in_adv: float = 0.10
    var_horizon_for_report: int = 1


class CryptoRiskAdapter:
    """thin shim around `crypto_risk.RiskEngine`."""

    def __init__(
        self,
        engine: Any,  # crypto_risk.RiskEngine, declared as Any to keep crypto_risk
                     # an optional dependency at import time
        adapter_cfg: CryptoRiskAdapterConfig | None = None,
    ) -> None:
        self.engine = engine
        self.cfg = adapter_cfg or CryptoRiskAdapterConfig()

    # construction helpers
    @classmethod
    def from_returns(
        cls,
        returns: pd.DataFrame,
        *,
        universe: tuple[str, ...] | None = None,
        adapter_cfg: CryptoRiskAdapterConfig | None = None,
        data_mode: str = "synthetic",
    ) -> "CryptoRiskAdapter":
        """build an adapter from an in-memory returns frame."""
        from crypto_risk import RiskConfig, RiskEngine

        uni = tuple(universe) if universe is not None else tuple(returns.columns)
        engine = RiskEngine(RiskConfig(universe=uni), data_mode=data_mode)
        engine.set_returns(returns)
        return cls(engine, adapter_cfg)

    # DL volatility hook
    def attach_dl_vol_model(self, model: _VolModel) -> None:
        """plug a DL volatility forecaster (e.g. wrapping an LSTM/TCN from src/models)."""
        self.engine.vol_forecaster.set_dl_model(model)

    # pre-trade validation
    def validate_target(
        self,
        target: TargetWeights,
        *,
        current_drawdown: float = 0.0,
        adv_usdt_by_symbol: dict[str, float] | None = None,
        capital: float = 1_000_000.0,
    ) -> ValidationResult:
        """run crypto_risk's `pre_trade_check` for each new/changed position and
        roll the per-asset decisions up into a single `ValidationResult`."""
        if not self.cfg.use_for_pretrade:
            return ValidationResult(approved=True)

        violations: list[RiskViolation] = []
        adjusted: dict[str, float] = dict(target.weights)
        for symbol, weight in target.weights.items():
            if abs(weight) < 1e-9:
                continue
            if symbol not in self.engine.returns.columns:
                # crypto_risk has no history for this symbol — skip pre-trade
                # rather than rejecting outright.
                continue
            adv = (adv_usdt_by_symbol or {}).get(symbol, 1e10)
            notional = abs(weight) * capital
            side = "buy" if weight > 0 else "sell"
            decision = self.engine.pre_trade_check(
                asset=symbol,
                notional=notional,
                side=side,
                adv_usdt=adv,
                current_drawdown=current_drawdown,
                max_var_budget=self.cfg.max_var_budget_per_asset,
                max_participation=self.cfg.max_participation_in_adv,
            )
            sized = decision.sized_notional
            if sized < notional - 1e-6:
                # downsize this leg in proportion to crypto_risk's allowance
                adjusted[symbol] = weight * (sized / notional) if notional > 0 else 0.0
            if not decision.approved:
                violations.append(
                    RiskViolation(
                        code="MAX_VAR",
                        message=f"crypto_risk rejected {symbol}: {decision.reasons}",
                        severity="hard",
                    )
                )
        approved = not violations
        return ValidationResult(
            approved=approved,
            adjusted_weights=adjusted if adjusted != target.weights else None,
            violations=tuple(violations),
        )

    # periodic full report
    def portfolio_report(self, weights: dict[str, float]) -> dict[str, Any]:
        """full risk picture for a target portfolio."""
        rep = self.engine.risk_report(weights=weights, use_copula=False)
        return {
            "annualized_vol": float(rep.annualized_vol),
            "diversification_ratio": float(rep.diversification_ratio),
            "weights": rep.weights,
            "horizons": list(rep.horizons),
            "lvar": rep.lvar,
            "portfolio_risk": rep.portfolio_risk.to_dict(orient="records"),
            "asset_risk": rep.asset_risk.reset_index().to_dict(orient="records"),
        }

    # tail risk (EVT) on demand
    def tail_risk(
        self,
        weights: dict[str, float],
        *,
        threshold_q: float = 0.90,
        use_conditional: bool = False,
    ) -> dict[str, Any]:
        """wrapper around `RiskEngine.tail_risk` with serializable output."""
        result = self.engine.tail_risk(
            weights=weights,
            threshold_q=threshold_q,
            use_conditional=use_conditional,
        )
        # crypto_risk's RiskEstimate is a dataclass — convert to dict
        out: dict[str, Any] = {}
        for k, v in result.items():
            if v is None:
                out[k] = None
            elif hasattr(v, "__dataclass_fields__"):
                out[k] = {
                    "var": float(v.var),
                    "es": float(v.es),
                    "method": v.method,
                    "horizon": v.horizon,
                    "var_alpha": v.var_alpha,
                    "es_alpha": v.es_alpha,
                }
            else:
                out[k] = v
        return out


class TorchVolAdapter:
    """wraps a torch-based predictive model from src/models so it conforms to
    crypto_risk's `set_dl_model()` contract (`predict(returns) -> float`)."""

    def __init__(self, model: Any, lookback: int = 60) -> None:
        self.model = model
        self.lookback = lookback

    def predict(self, returns: pd.Series) -> float:
        import numpy as np

        recent = returns.dropna().tail(self.lookback).to_numpy(dtype=np.float64)
        if len(recent) < 2:
            return float(np.nanstd(returns)) if len(returns) else 0.01
        x = recent.reshape(1, -1)
        # accept both predict_batch (our PredictiveModel interface) and predict_one
        if hasattr(self.model, "predict_batch"):
            pred = self.model.predict_batch(x)
            return float(np.asarray(pred).flatten()[0])
        if hasattr(self.model, "predict_one"):
            p = self.model.predict_one(recent)
            return float(p.mu) if hasattr(p, "mu") else float(p)
        raise AttributeError("torch model has no predict_batch / predict_one")
