"""risk — portfolio-level risk management. Module 10.
"""

from ._internal.monitor import KillSwitch, PortfolioMonitor
from ._internal.risk_gate import RiskGate, RiskLimits
from ._internal.var import (
    historical_cvar,
    historical_var,
    kupiec_pof_test,
    monte_carlo_var,
    parametric_var,
)
from .integration import CryptoRiskAdapter, CryptoRiskAdapterConfig, TorchVolAdapter
from .io_schemas import PortfolioState, RiskViolation, ValidationResult

__all__ = [
    "PortfolioState",
    "RiskViolation",
    "ValidationResult",
    "RiskGate",
    "RiskLimits",
    "PortfolioMonitor",
    "KillSwitch",
    "historical_var",
    "historical_cvar",
    "parametric_var",
    "monte_carlo_var",
    "kupiec_pof_test",
    "CryptoRiskAdapter",
    "CryptoRiskAdapterConfig",
    "TorchVolAdapter",
]
