"""VaR / CVaR estimators."""

from __future__ import annotations

import numpy as np
from scipy import stats


def historical_var(returns: np.ndarray, confidence: float = 0.95) -> float:
    """historical VaR: empirical quantile of losses."""
    if len(returns) == 0:
        return 0.0
    return float(-np.quantile(returns, 1.0 - confidence))


def historical_cvar(returns: np.ndarray, confidence: float = 0.95) -> float:
    """historical CVaR (expected shortfall)."""
    if len(returns) == 0:
        return 0.0
    threshold = -historical_var(returns, confidence)
    tail = returns[returns <= threshold]
    if len(tail) == 0:
        return float(-threshold)
    return float(-tail.mean())


def parametric_var(returns: np.ndarray, confidence: float = 0.95) -> float:
    """gaussian-parametric VaR."""
    if len(returns) < 2:
        return 0.0
    mu = float(returns.mean())
    sd = float(returns.std(ddof=1))
    z = stats.norm.ppf(1.0 - confidence)
    return float(-(mu + z * sd))


def monte_carlo_var(
    returns: np.ndarray, confidence: float = 0.95, n_sim: int = 10_000, seed: int = 0,
) -> float:
    """monte Carlo VaR by resampling with replacement."""
    if len(returns) == 0:
        return 0.0
    rng = np.random.default_rng(seed)
    sample = rng.choice(returns, size=n_sim, replace=True)
    return historical_var(sample, confidence)


def kupiec_pof_test(violations: int, n: int, confidence: float = 0.95) -> tuple[float, float]:
    """kupiec PoF likelihood-ratio test for VaR coverage."""
    p = 1.0 - confidence
    if n == 0 or violations == 0:
        return 0.0, 1.0
    pi_hat = violations / n
    if pi_hat in (0.0, 1.0):
        return 0.0, 1.0
    lr = -2.0 * (
        np.log((1 - p) ** (n - violations) * p**violations)
        - np.log((1 - pi_hat) ** (n - violations) * pi_hat**violations)
    )
    pval = 1.0 - stats.chi2.cdf(lr, df=1)
    return float(lr), float(pval)
