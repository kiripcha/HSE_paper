"""PortfolioMonitor — tracks positions, equity, drawdown from Fill events."""

from __future__ import annotations

import numpy as np

from src.execution.io_schemas import Fill

from ..io_schemas import PortfolioState
from .var import historical_cvar, historical_var


class PortfolioMonitor:
    def __init__(self, starting_cash: float = 100_000.0, var_window: int = 200) -> None:
        self.cash = starting_cash
        self.positions: dict[str, float] = {}
        self.avg_cost: dict[str, float] = {}
        self.last_prices: dict[str, float] = {}
        self.pnl_realized = 0.0
        self.equity_peak = starting_cash
        self.dd_max = 0.0
        self._returns_history: list[float] = []
        self.var_window = var_window
        self._last_equity = starting_cash

    def on_fill(self, fill: Fill) -> None:
        signed_qty = fill.quantity if fill.side == "buy" else -fill.quantity
        prev_qty = self.positions.get(fill.symbol, 0.0)
        prev_cost = self.avg_cost.get(fill.symbol, 0.0)
        new_qty = prev_qty + signed_qty
        # update avg cost / realized pnl
        if prev_qty == 0 or (prev_qty * signed_qty > 0):
            # extending position
            self.avg_cost[fill.symbol] = (
                (prev_cost * prev_qty + fill.price * signed_qty) / new_qty
                if new_qty != 0
                else 0.0
            )
        else:
            # reducing or flipping — realize pnl on closed quantity
            closed_qty = min(abs(prev_qty), abs(signed_qty))
            if prev_qty > 0:
                # closing long: pnl = (sell_price - avg_cost) * closed_qty
                self.pnl_realized += (fill.price - prev_cost) * closed_qty
            else:
                # closing short: pnl = (avg_cost - buy_price) * closed_qty
                self.pnl_realized += (prev_cost - fill.price) * closed_qty
            if abs(signed_qty) > abs(prev_qty):
                # flipped sign — new avg cost on remainder
                self.avg_cost[fill.symbol] = fill.price
            elif new_qty == 0:
                self.avg_cost[fill.symbol] = 0.0
            else:
                # avg cost unchanged on partial close
                self.avg_cost[fill.symbol] = prev_cost
        self.positions[fill.symbol] = new_qty
        self.cash -= fill.price * signed_qty + fill.fee
        self.last_prices[fill.symbol] = fill.price

    def on_market_data(self, prices: dict[str, float]) -> None:
        for sym, p in prices.items():
            self.last_prices[sym] = p

    def snapshot(self, ts_ns: int = 0) -> PortfolioState:
        unrealized = sum(
            (self.last_prices.get(s, self.avg_cost.get(s, 0.0)) - self.avg_cost.get(s, 0.0))
            * q
            for s, q in self.positions.items()
        )
        equity = self.cash + unrealized + sum(
            self.avg_cost.get(s, 0.0) * q for s, q in self.positions.items()
        )
        if equity > self.equity_peak:
            self.equity_peak = equity
        dd = (
            (self.equity_peak - equity) / self.equity_peak
            if self.equity_peak > 0 else 0.0
        )
        self.dd_max = max(self.dd_max, dd)
        # update returns history
        if self._last_equity > 0:
            self._returns_history.append((equity - self._last_equity) / self._last_equity)
            if len(self._returns_history) > self.var_window:
                self._returns_history.pop(0)
        self._last_equity = equity
        notional = {
            s: self.last_prices.get(s, self.avg_cost.get(s, 0.0)) * q
            for s, q in self.positions.items()
        }
        gross_notional = sum(abs(v) for v in notional.values())
        leverage = gross_notional / equity if equity > 0 else 0.0
        rets = np.array(self._returns_history)
        return PortfolioState(
            ts_ns=ts_ns,
            positions=dict(self.positions),
            notional=notional,
            cash=self.cash,
            equity=equity,
            leverage=leverage,
            pnl_realized_total=self.pnl_realized,
            pnl_unrealized=unrealized,
            drawdown_current=dd,
            drawdown_max=self.dd_max,
            var_95=historical_var(rets) if len(rets) > 10 else 0.0,
            cvar_95=historical_cvar(rets) if len(rets) > 10 else 0.0,
        )


class KillSwitch:
    """process-local kill switch state."""

    def __init__(self) -> None:
        self._active = False
        self._reason = ""

    def trigger(self, reason: str) -> None:
        self._active = True
        self._reason = reason

    def is_active(self) -> bool:
        return self._active

    @property
    def reason(self) -> str:
        return self._reason

    def reset(self) -> None:
        self._active = False
        self._reason = ""
