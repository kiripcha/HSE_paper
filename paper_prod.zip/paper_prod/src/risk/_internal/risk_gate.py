"""RiskGate — pre-trade validation of target weights."""

from __future__ import annotations

from dataclasses import dataclass, field

from src.portfolio.io_schemas import TargetWeights

from ..io_schemas import RiskViolation, ValidationResult


@dataclass
class RiskLimits:
    max_leverage: float = 1.0
    max_concentration_pct: float = 0.30
    max_drawdown_pct: float = 0.15


@dataclass
class RiskGate:
    limits: RiskLimits = field(default_factory=RiskLimits)
    kill_switch_active: bool = False

    def validate(
        self,
        target: TargetWeights,
        current_drawdown_pct: float = 0.0,
    ) -> ValidationResult:
        violations: list[RiskViolation] = []
        if self.kill_switch_active:
            violations.append(
                RiskViolation(
                    code="KILL_SWITCH_ACTIVE", message="kill switch is on", severity="hard"
                )
            )
            return ValidationResult(approved=False, violations=tuple(violations))
        # leverage
        leverage = sum(abs(w) for w in target.weights.values())
        if leverage > self.limits.max_leverage + 1e-9:
            violations.append(
                RiskViolation(
                    code="MAX_LEVERAGE",
                    message=f"leverage {leverage:.3f} > {self.limits.max_leverage}",
                    severity="hard",
                )
            )
        # concentration
        for sym, w in target.weights.items():
            if abs(w) > self.limits.max_concentration_pct + 1e-9:
                violations.append(
                    RiskViolation(
                        code="POSITION_CONCENTRATION",
                        message=f"{sym} w={w:.3f} > {self.limits.max_concentration_pct}",
                        severity="hard",
                    )
                )
        # drawdown
        if current_drawdown_pct > self.limits.max_drawdown_pct:
            violations.append(
                RiskViolation(
                    code="MAX_DD",
                    message=f"DD {current_drawdown_pct:.3f} > {self.limits.max_drawdown_pct}",
                    severity="hard",
                )
            )
        hard = any(v.severity == "hard" for v in violations)
        return ValidationResult(approved=not hard, violations=tuple(violations))
