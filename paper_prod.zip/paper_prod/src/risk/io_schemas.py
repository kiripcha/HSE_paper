"""schemas for the risk management module."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class PortfolioState(BaseModel):
    model_config = ConfigDict(frozen=True)

    ts_ns: int
    positions: dict[str, float] = Field(default_factory=dict)
    notional: dict[str, float] = Field(default_factory=dict)
    cash: float = 0.0
    equity: float = 0.0
    leverage: float = 0.0
    pnl_realized_total: float = 0.0
    pnl_unrealized: float = 0.0
    drawdown_current: float = 0.0
    drawdown_max: float = 0.0
    var_95: float = 0.0
    cvar_95: float = 0.0


class RiskViolation(BaseModel):
    model_config = ConfigDict(frozen=True)

    code: Literal[
        "MAX_LEVERAGE",
        "MAX_DD",
        "MAX_VAR",
        "POSITION_CONCENTRATION",
        "TURNOVER_CAP",
        "KILL_SWITCH_ACTIVE",
        "STALE_MARKET_DATA",
    ]
    message: str
    severity: Literal["hard", "soft"] = "hard"


class ValidationResult(BaseModel):
    model_config = ConfigDict(frozen=True)

    approved: bool
    adjusted_weights: dict[str, float] | None = None
    violations: tuple[RiskViolation, ...] = ()
