# Paper Prod

Production-ready сборка высокоскоростной торговой системы для криптовалютного портфеля.

Подробное описание проекта — в [README.project.md](README.project.md).

## Что внутри

- `src/` — двенадцать продуктовых модулей (market_data, storage, features, labeling, models, regime, meta_allocator, portfolio, execution, risk, backtest, live)
- `crypto_risk/` — аналитический пакет (VaR/ES девятью методами, GARCH, EVT, копулы)
- `configs/` — YAML-конфигурации для каждого модуля
- `scripts/` — точки входа: загрузка истории, smoke-тесты бирж
- `tests/` — интеграционные тесты
- `Dockerfile` — двухстадийная сборка
- `docker-compose.yaml` — оркестрация режимов (test/backtest/paper/live/fetch/smoke)

## Быстрый старт

```bash
# 1. Скопировать .env.example в .env и заполнить ключи (при необходимости)
cp .env.example .env

# 2. Собрать образ
make build
# или: docker compose build

# 3. Прогнать тесты внутри контейнера (валидация образа)
make test

# 4. Запустить backtest
make backtest

# 5. Бумажная торговля (live данные, симулированное исполнение)
make paper

# 6. Реальная торговля (требует API-ключей в .env)
make live
```

## Режимы работы

Все режимы используют один и тот же образ; переключение через первый аргумент команды:

| Команда | Описание |
|---|---|
| `test` | Запуск pytest по всему suite |
| `backtest --config <path>` | Сквозное обратное тестирование стратегии |
| `paper --config <path>` | Бумажная торговля: live-фид + симулированное исполнение |
| `live --config <path>` | Реальная торговля: live-фид + реальные приказы |
| `fetch <args>` | Загрузка исторических данных через CryptoCompare |
| `smoke binance` / `smoke okx` | Smoke-тест подключения к публичному потоку биржи |
| `shell` | Bash внутри контейнера |
| `python <args>` | Прямой вызов Python |

## Тома и состояние

Контейнер пишет в четыре каталога, монтируемых как тома (см. docker-compose.yaml):

- `./data_cache` — кэш исторических данных
- `./state` — состояние онлайн-объектов (для восстановления после перезапуска)
- `./logs` — журналы
- `./reports` — отчёты по backtest и risk

Тома создаются при первом запуске compose.

## Метрики

В режимах `paper` и `live` контейнер экспортирует Prometheus-метрики на порту 9090. Чтобы посмотреть текущее состояние:

```bash
curl http://localhost:9090/metrics
```

Метрики покрывают: число принятых событий, задержку обработки, число отклонённых проверкой лимитов сигналов, текущую стоимость портфеля, текущую просадку.

## Зависимости

Образ собран на `python:3.12-slim-bookworm`. Список зависимостей фиксирован в двух файлах:

- `requirements.txt` — минимальный набор runtime-зависимостей (соответствует `pyproject.toml`)
- `requirements.lock.txt` — полный заморозок `pip freeze` для побитовой воспроизводимости окружения

По умолчанию Dockerfile использует `requirements.txt`. Для строгой воспроизводимости можно заменить на lock:

```dockerfile
COPY requirements.lock.txt requirements.txt
```

## Конфигурация runtime

Параметры передаются через переменные окружения (см. `.env.example`) и YAML-конфигурации в `configs/`. Поддерживается переопределение параметров YAML-конфига через флаги командной строки (Hydra-стиль).

## Безопасность

- Контейнер работает от непривилегированного пользователя `paper` (uid 1000)
- API-ключи передаются только через переменные окружения, никогда не вшиваются в образ
- `.env` не попадает в образ (исключён `.dockerignore`)
- Конфигурация монтируется в read-only режиме (`/app/configs:ro`)

## Healthcheck

Образ содержит healthcheck по эндпоинту метрик. В compose файле healthcheck активен для режимов `paper` и `live` (где экспортёр действительно работает).

## Локальный запуск без Docker

Для разработки без Docker:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install -e .
pytest -q
```

Версия Python: 3.12 (минимум 3.11).
