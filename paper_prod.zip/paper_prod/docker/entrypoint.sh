#!/usr/bin/env bash
# Unified entrypoint for the trading system Docker image.
# Routes the first argument to the appropriate subcommand.
#
# Usage:
#   docker run paper_prod test                   -> run pytest
#   docker run paper_prod backtest <config>      -> run backtest
#   docker run paper_prod live                   -> live trading (needs API keys via env)
#   docker run paper_prod paper                  -> paper trading
#   docker run paper_prod fetch <ARGS>           -> fetch historical data
#   docker run paper_prod smoke binance          -> smoke test binance feed
#   docker run paper_prod smoke okx              -> smoke test okx feed
#   docker run paper_prod shell                  -> drop into bash
#   docker run paper_prod python ...             -> raw python passthrough

set -euo pipefail

cmd="${1:-test}"
shift || true

case "$cmd" in
    test)
        exec python -m pytest -q "$@"
        ;;
    backtest)
        exec python -m src.live "$@"
        ;;
    live)
        exec python -m src.live --mode live "$@"
        ;;
    paper)
        exec python -m src.live --mode paper "$@"
        ;;
    fetch)
        exec python scripts/fetch_historical_data.py "$@"
        ;;
    smoke)
        venue="${1:-binance}"
        shift || true
        case "$venue" in
            binance) exec python scripts/smoke_live_binance.py "$@" ;;
            okx)     exec python scripts/smoke_live_okx.py "$@" ;;
            *) echo "unknown venue: $venue" >&2; exit 2 ;;
        esac
        ;;
    shell)
        exec /bin/bash "$@"
        ;;
    python)
        exec python "$@"
        ;;
    *)
        # forward unknown commands directly
        exec "$cmd" "$@"
        ;;
esac
