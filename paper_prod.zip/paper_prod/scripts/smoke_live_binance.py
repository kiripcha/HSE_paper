"""live smoke test against Binance public WS.
"""

from __future__ import annotations

import asyncio
import socket
import sys
from collections import Counter

from src.market_data import BinanceConnector


async def _has_network() -> bool:
    try:
        socket.create_connection(("stream.binance.com", 9443), timeout=3).close()
        return True
    except OSError:
        return False


async def main(seconds: float = 10.0) -> int:
    if not await _has_network():
        print("SKIP: no network access to stream.binance.com:9443")
        return 0
    conn = BinanceConnector(
        ws_url="wss://stream.binance.com:9443/ws",
        symbols=["BTCUSDT"],
        channels=["depth", "trade", "bookTicker"],
    )
    counts: Counter[str] = Counter()
    await conn.connect()
    try:
        async def consume() -> None:
            async for ev in conn.stream():
                counts[ev.event_type] += 1
                if sum(counts.values()) % 50 == 0:
                    print(f"  received {sum(counts.values())} events: {dict(counts)}")

        try:
            await asyncio.wait_for(consume(), timeout=seconds)
        except asyncio.TimeoutError:
            pass
    finally:
        await conn.close()

    print("\n=== summary ===")
    print(f"total events     : {sum(counts.values())}")
    print(f"by event_type    : {dict(counts)}")
    if sum(counts.values()) == 0:
        print("FAIL: no events received")
        return 1
    if counts.get("book_delta", 0) == 0 and counts.get("bbo", 0) == 0 and counts.get("trade", 0) == 0:
        print("FAIL: no recognized event types parsed")
        return 1
    print("OK")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
