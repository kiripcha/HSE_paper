"""fetch daily historical OHLC for a configurable crypto universe.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", default="2022-01-01")
    ap.add_argument("--end", default="2024-12-31")
    ap.add_argument(
        "--universe",
        default="BTC,ETH,BNB,SOL,XRP,ADA,DOGE,LINK",
        help="comma-separated tickers (e.g. BTC,ETH,SOL)",
    )
    ap.add_argument(
        "--mode",
        choices=["auto", "synthetic"],
        default="auto",
        help="auto = try real sources then fallback; synthetic = deterministic offline",
    )
    ap.add_argument("--out_dir", default="data/historical")
    args = ap.parse_args()

    universe = tuple(s.strip() for s in args.universe.split(",") if s.strip())
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    from crypto_risk.data import MultiSourceCryptoLoader

    print(f"Fetching {universe} {args.start}..{args.end} ({args.mode}) ...")
    loader = MultiSourceCryptoLoader(universe, mode=args.mode)
    prices = loader.load_close_panel(args.start, args.end)
    print(f"  shape:  {prices.shape}")
    print(f"  origin: {loader.data_origin}")
    print(f"  source: {loader.source_used}")
    if args.mode != "synthetic":
        print(loader.coverage_report())

    name = f"{'-'.join(universe)}_{args.start}_{args.end}_{args.mode}.parquet"
    out = out_dir / name
    prices.to_parquet(out)
    print(f"  wrote   {out}  ({out.stat().st_size / 1024:.1f} KiB)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
